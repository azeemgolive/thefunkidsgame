/* jQuery tubular plugin
|* by Sean McCambridge
|* http://www.seanmccambridge.com/tubular
|* version: 1.0
|* updated: October 1, 2012
|* since 2010
|* licensed under the MIT License
|* Enjoy.
|* 
|* Thanks,
|* Sean */

/*
* Modified by artless
* support@artlesstheme.com
*/

;(function ($, window ) {

    // test for feature support and return if failure
    
    // defaults
    var defaults = {
        ratio: 16/9, // usually either 4/3 or 16/9 -- tweak as needed
        videoId: 'ZCAnLxRvNNc', // toy robot in space is a good default, no?
        mute: true,
        repeat: true,
        width: $(window).width(),
        wrapperZIndex: 99,
        playButtonClass: 'tubular-play',
        pauseButtonClass: 'tubular-pause',
        muteButtonClass: 'tubular-mute',
        volumeUpClass: 'tubular-volume-up',
        volumeDownClass: 'tubular-volume-down',
        increaseVolumeBy: 10,
        start: 0
    };

	var playerInfoList = [];

	function addVideo( node, options ) {
		var player = [{id:'player',height:'390',width:'640',videoId:'M7lc1UVf-VE'}];

		var playerInfoList = [{id:'player',height:'390',width:'640',videoId:'M7lc1UVf-VE'},{id:'player1',height:'390',width:'640',videoId:'M7lc1UVf-VE'}];

		function onYouTubeIframeAPIReady() {
			if(typeof playerInfoList === 'undefined')
				return;

			for(var i = 0; i < playerInfoList.length;i++) {
				var curplayer = createPlayer(playerInfoList[i]);
			}
		}
		function createPlayer(playerInfo) {
			return new YT.Player(playerInfo.id, {
				height: playerInfo.height,
				width: playerInfo.width,
				videoId: playerInfo.videoId
			});
		}
	}

    // methods
	var playerId = 0;
	var players = [];

    function runVideo( node, options) { // should be called on the wrapper div
		var options = $.extend({}, defaults, options),
			$body = $( node ); // cache body node

		playerId++;
		var thisPlayerId = playerId;

		// build container
		var tubularContainer = '<div class="al-tubular-container" id="tubular-container'+thisPlayerId+'" style="overflow: hidden; position: absolute; z-index: 1; width: 100%; height: 100%"><div id="tubular-player'+thisPlayerId+'" style="position: absolute;"></div></div><div id="tubular-shield'+playerId+'" style="width: 100%; height: 100%; z-index: 2; position: absolute; left: 0; top: 0;"></div>';

        // set up css prereq's, inject tubular container and set up wrapper defaults
        $body.prepend(tubularContainer);

        // set up iframe player, use global scope so YT api can talk
		var player = new YT.Player( 'tubular-player'+thisPlayerId, {
			width: options.width,
			height: Math.ceil(options.width / options.ratio),
			videoId: options.videoId,
			playerVars: {
				rel: 0,
				controls: 0,
				showinfo: 0,
				modestbranding: 1,
				autohide: 1,
				wmode: 'transparent'
			},
			events: {
				'onReady': onPlayerReady,
				'onStateChange': onPlayerStateChange
			}
		} );

		function onPlayerReady( e ) {
			resize();
			if (options.mute) e.target.mute();
			e.target.seekTo(options.start);
			e.target.playVideo();
		}

		function onPlayerStateChange( state ) {
			if (state.data === 0 && options.repeat) { // video ended and repeat option is set true
				player.seekTo(options.start); // restart
			}
		}

        // resize handler updates width, height and offset of player after resize/init
        var resize = function() {
            var width = $(window).width(),
                pWidth, // player width, to be defined
                height = $(window).height(),
                pHeight, // player height, tbd
                $tubularPlayer = $('#tubular-player'+thisPlayerId);
            // when screen aspect ratio differs from video, video must center and underlay one dimension

            if (width / options.ratio < height) { // if new video height < window height (gap underneath)
                pWidth = Math.ceil(height * options.ratio); // get new player width

                $tubularPlayer.width(pWidth).height(height).css({left: (width - pWidth) / 2, top: 0}); // player width is greater, offset left; reset top

            } else { // new video width < window width (gap to right)
                pHeight = Math.ceil(width / options.ratio); // get new player height
                $tubularPlayer.width(width).height(pHeight).css({left: 0, top: (height - pHeight) / 2}); // player height is greater, offset top; reset left
            }

        }

        // events
        $( window ).on('resize.tubular', function() {
            resize();
        } ) ;
    }
    // create plugin
    $.fn.tubular = function (options) {
			runVideo(this, options);
    }
})(jQuery, window);