/*!
 * @package    artless Flato
 * @author     Christian Glingener <glingener.christian@gmail.com>
 * @version    1.0.0
 * @copyright  2014 artlessthemes.com
 * @link       http://artlessthemes.com/
 */

// Defaul Blog / Portfolio Slider Settings
var alSliderSettingsDefault = {
	singleItem: true,
	navigation: true,
	navigationText: [
		'<a class="bx-prev al-slider-prev" href="javascript:void(0);"></a>',
		'<a class="bx-next al-slider-next" href="javascript:void(0);"></a>'
	],
	baseClass: 'bx-wrapper owl-carousel',
	beforeUpdate: function( e ) {
		e.find('div.owl-wrapper-outer' ).css('max-height', jQuery( window ).height() + 'px' );
	},
	afterInit: function( e ) {
		e.find('div.owl-wrapper-outer' ).css('max-height', jQuery( window ).height() + 'px' );
	}
};

// Check if alSliderSettingsUser is set
if (typeof alSliderSettingsUser === 'undefined') {
	var alSliderSettingsUser = {};
}

// Defaul Device Slider Settings
var alDeviceSliderSettingsDefault = {
    singleItem: true,
    navigation: false,
    baseClass: 'bx-wrapper owl-carousel'
};


// Check if alDeviceSliderSettingsUser is set
if (typeof alDeviceSliderSettingsUser === 'undefined') {
    var alDeviceSliderSettingsUser = {};
}

// Default Quote Slider Settings
var alQuoteSliderSettingsDefault = {
	singleItem: true,
	navigation: false
};

// Check if alQuoteSliderSettingsUser is set
if (typeof alQuoteSliderSettingsUser === 'undefined') {
	var alQuoteSliderSettingsUser = {};
}

// Home Container Min Offset Top
if (typeof alHomeMinOffsetTop === 'undefined') {
	var alHomeMinOffsetTop = 20;
}

// Toggle Close All
if (typeof alToggleCloseAll === 'undefined') {
	var alToggleCloseAll = false;
}

(function ( $ ) {

	'use strict';

	// Device Slider
	$.fn.alDeviceSlider = function() {
		if( this.length > 0 ) {

            var deviceSliderOptions = $.extend( {}, alDeviceSliderSettingsDefault, alDeviceSliderSettingsUser );

			this.owlCarousel( deviceSliderOptions );

			this.addClass( 'al-done' );
		}
	};

	// Quote Slider
	$.fn.alQuoteSlider = function() {
		if( this.length > 0 ) {

			var quoteSliderOptions = $.extend( {}, alQuoteSliderSettingsDefault, alQuoteSliderSettingsUser );

			this.owlCarousel( quoteSliderOptions );

			this.addClass( 'al-done' );
		}
	};

	$.fn.alClientSlider = function() {
		if( this.length > 0 ) {
			this.owlCarousel({
				items: 4,
				autoPlay: 3000,
				stopOnHover: true,
				pagination: false,
				navigation: false
			});

			this.addClass( 'al-done' );
		}
	};

	// BxSlider to Owl Carousel
	$.fn.bxSlider = function( options ){
		this.owlCarousel({
			singleItem: true,
			navigation: true,
			navigationText: [
				'<a class="bx-prev al-slider-prev" href="javascript:void(0);"></a>',
				'<a class="bx-next al-slider-next" href="javascript:void(0);"></a>'
			],
			// itemsScaleUp: true,
			baseClass: 'bx-wrapper owl-carousel',
			beforeUpdate: function( e ) {
				// MAX HEIGHT = WINDOW HEIGHT
				// e.find('img' ).css('max-height', $(window ).height() + 'px' );
				e.find('div.owl-wrapper-outer' ).css('max-height', $( window ).height() + 'px' );
			},
			beforeInit: function( e ) {
				// MAX HEIGHT = WINDOW HEIGHT
				//e.find('div.owl-carousel' ).css('max-height', $(window ).height() + 'px' );
			},
			afterInit: function( e ) {
				e.find('div.owl-wrapper-outer' ).css('max-height', $( window ).height() + 'px' );
			}
		});
	};

	// Preloader
	var preLoader = $( '#al-page-preloader' );

	if ( preLoader.length ) {
		$( window ).load( function () {
            al_load_iframe();

			// Delay, so js resize function also loaded
			preLoader.delay( 2000 ).show( function() {
				if( $( '#page-wrapper' ).height() == $(window ).height() ) {
					$( '.bottom-box' ).css( 'position', 'absolute');
				}

				preLoader.fadeOut( 300, function() {
					$( '.al-video-fullscreen' ).find( 'video' ).css('display','block');
				} );
            } );
		} );
	}

	function al_home_section_resize() {
		var homeSection = $( 'section.al-home-banner' );
		var homeHeight = $( window ).height();

		if( homeSection.length > 0 ) {

			var homeContainer = homeSection.find( 'div.al-home-container' );
			var homeContainerHeight = 0;

			if( homeContainer.length > 0 ) {
				var homeContainerLogo = homeContainer.find( 'a.al-logo' );

				// Height Container
				if( homeContainerLogo.length > 0 ) {
					homeContainerLogo.css( 'margin-top', 0 );
					homeContainerHeight = homeContainer.height();
					homeContainerLogo.css( 'margin-top', -100 );
				} else {
					homeContainerHeight = homeContainer.height();
				}

				// Height Container + Top Space
				homeContainer.css( 'top', '25%' );
				var homeContainerTop = parseInt( homeContainer.css( 'top' ), 10 );
				homeContainerHeight = homeContainerHeight + homeContainerTop;

				// If homeContainerHeight is higher than window.height
				if( homeContainerHeight > homeHeight ) {
					homeContainer.css( 'top', alHomeMinOffsetTop + 'px' );
					homeHeight = homeContainerHeight - homeContainerTop + alHomeMinOffsetTop + 40;

					if( homeContainerLogo.length > 0 ) {
						homeContainerLogo.css( 'margin-top', 0 );
					}

					// Home Slider
					var homeSectionSlider = $( '#al-home-slider' );

					if( homeSectionSlider.length > 0 ) {
						homeSectionSlider.css( 'height', homeHeight + 'px' );

						homeSectionSlider.find( 'div.mc-image' ).css( 'height', homeHeight + 'px' );
					}
				}
 			}

			if( $( window ).height() > homeHeight ) {
				homeHeight = $( window ).height();
			}

			homeSection.find( 'div.al-video-fullscreen' ).css( 'height', homeHeight + 'px' );

			$( '#home-parallax' ).css( 'min-height', homeHeight + 'px' );
			homeSection.css( 'min-height', homeHeight + 'px' );
		}
	} al_home_section_resize();

	function al_load_iframe() {
		$( '[data-after-preload-src]' ).delay( 500 ).each( function () {
			var src = $( this ).data( 'after-preload-src' );

			$( this ).attr( 'src', src ).removeAttr( 'data-after-preload-src' );
		} );

		$( '[data-sc-after-preload-src]' ).each( function () {
			var src = $( this ).data( 'sc-after-preload-src' );

			$( this ).attr( 'src', src ).removeAttr( 'data-sc-after-preload-src' );
		} );
	}

	/* --------------------------------------------------------------------- */
	/* 1. HEADER
	 /* --------------------------------------------------------------------- */

	var navi = $( '#header' );
	var pageWrapper = $( '#page-wrapper' );
	var navistatus = 0;
    var naviToggle = $( "#open-nav" );

	function openNavigation() {
		navi.clearQueue().animate( {
			left: '0'
		}, 500, 'swing' );
		pageWrapper.clearQueue().animate( {
			left: '260px'
		}, 500, 'swing' );

		navistatus = 1;
	}

	function closeNavigation() {
		navi.clearQueue().animate( {
			left: '-260px'
		}, 600, 'easeOutBounce' );
		pageWrapper.clearQueue().animate( {
			left: '0'
		}, 600, 'easeOutBounce' );

		navistatus = 0;
	}

	$( '#open-nav-mousenter ').on( 'mouseenter', function() {
		if ( navistatus == 0 ) {
			openNavigation();
		}

		navi.on( 'mouseleave', function() {
			closeNavigation();
		} );
	});

    naviToggle.click( function (e) {

		e.preventDefault();

		if ( navistatus == 0 ) {
			openNavigation();
		} else {
			closeNavigation();
		}
	} );


	$( ".scrollto" ).click( function ( e ) {

		e.preventDefault();
		var topoffset = 0;
		var href = $( this ).attr( 'href' );
		var scrollToSection;

		// If href set, scroll to section
		if ( href ) {
			scrollToSection = $( href );

			// else scroll to next section
		} else {
			scrollToSection = $( this ).closest( 'section' ).parent().next( 'section' );

			if( !scrollToSection.length ) {
				scrollToSection = $( this ).closest( 'section' ).next( 'section' );
			}
		}

		// if element found

		if ( scrollToSection.offset() ) {

			$( 'html,body' ).clearQueue().animate( {
				scrollTop: scrollToSection.offset().top - topoffset
			}, 1800, 'swing' );
		}

		return false;

	} );


	/* --------------------------------------------------------------------- */
	/* 2. NAVIGATION
	 /* --------------------------------------------------------------------- */
	var mainNav = $( '#main-navigation' ),
		mainItems = mainNav.find( 'a.al-scrollto-anchor' );


	// Position Navigation
	function al_nav_position() {
		var diffHeight = ( $( '#header' ).height() - mainNav.height() );
		var navTop = 10;

		if ( diffHeight > 0 ) {
			navTop = diffHeight / 2 - 10;

			if ( navTop < 10 ) {
				navTop = 10;
			}
		}
		mainNav.css( 'top', navTop + 'px' );
	}

	$( window ).load( function () {
		al_nav_position();
        naviToggle.css('right', '-' + naviToggle.outerWidth() + 'px' );
	} );

	mainItems.click( function ( e ) {

		e.preventDefault();

		var topoffset = 0;
		var sectionToScroll = $( $.attr( this, 'href' ) );

		if ( sectionToScroll.length ) {
			$( 'html,body' ).clearQueue().animate( {
				scrollTop: sectionToScroll.offset().top - topoffset
			}, 1800, 'swing' );
		}
		return false;
	} );


	var scrollTo = mainItems.map( function () {
		return $( $( this ).attr( "href" ) );
	} );

	function al_active_item() {
		var mainHeight = mainNav.height();
		var offsetTop = $( window ).scrollTop() + mainHeight + 50;


		var current = scrollTo.map( function () {
			if ( $( this ).length ) {
				var sectionTop = $( this ).offset().top;
				var sectionBottom = $( this ).position().top + $( this ).outerHeight( true );

				if ( sectionTop < offsetTop && sectionBottom > offsetTop ) {
					return this;
				}
			}
		} );

		if ( current.length ) {
			current = current[ current.length - 1 ];
			var id = current.attr( "id" );

		} else {
			var id = "";
		}

		mainItems
			.removeClass( "active" )
			.filter( "[href=#" + id + "]" )
			.addClass( "active" );
	}

	$( window ).scroll( function () {
		al_active_item();
	} );


	/* --------------------------------------------------------------------- */
	/* 5. BLOG
	 /* --------------------------------------------------------------------- */

	var minWidth = 965;
	var windowWidth = $( window ).width();
	var blogWrapper = $( '#al-blog-wrapper' );
	var blogPreview = $( '#al-blog-preview' );
	var blogPreviewLayer = blogPreview.find( 'div.layer' );
	var blogContent = $( '#al-blog-load-content' );
	var blogLoader = $( '#al-blog-loader' );

	function al_blog_preview_layers() {
		blogPreviewLayer = blogPreview.find( 'div.layer' );
		windowWidth = $( window ).width();

		if ( windowWidth < minWidth ) {
			blogPreviewLayer.css( {
				top  : '25%',
				left : '0',
				width: '100%',
				opacity: '1'
			} );
		} else {
			blogPreviewLayer.css( {
				top    : '40%',
				left   : '-50%',
				width  : '50%',
				opacity: '0'
			} );
		}

		// adjust height of empty previews
		$( '.al-blog-empty-preview' ).each( function() {
			if( $( this ).parent().width() > 700 ) {
				$( this ).css( 'min-height', $( this ).parent().height() + 10 + 'px' );
			} else {
				$( this ).css( 'min-height', 0 );
			}
		});
	}

	blogPreview.on( 'mouseenter', 'li', function () {
		if( windowWidth > minWidth ) {
			$( this ).children( ".layer" ).clearQueue().animate( {
				left   : '0',
				opacity: '1'
			}, 400 );
		}
	} );

	blogPreview.on( 'mouseleave', 'li', function () {
		if( windowWidth > minWidth ) {
			$( this ).children( ".layer" ).clearQueue().animate( {
				left   : '-50%',
				opacity: '0'
			}, 400 );
		}
	} );

	/* === LOAD BLOG DETAILS === */

	$( '#close-blog-wrapper' ).click( function ( e ) {
		e.preventDefault();
		blogWrapper.css( 'height', blogWrapper.height() + 'px' );
		blogWrapper.css( 'min-height', 0 );
		blogWrapper.slideUp( 1000 );
		$( '.al-blog-article' ).fadeOut( 800, function () {
			$( this ).remove();
		} );
	} );

	function al_blog_do_after_load_article() {

		blogLoader.css( 'display', 'none' );
		blogWrapper.find( 'div.close' ).fadeIn( 800 );
		$( '.al-blog-article' ).fadeIn( 1000 );
		blogWrapper.css( 'height', 'auto' );

		var blogSlider = $( '.blog-slider' );
		if( blogSlider.length > 0 ) {
			var blogSliderOptions = $.extend( {}, alSliderSettingsDefault, alSliderSettingsUser );
			blogSlider.owlCarousel( blogSliderOptions );
		}

		al_load_iframe();
		al_tab_content();

		if ( $.isFunction( $.fn.alResizeIcon ) ) {
			$( 'body' ).alResizeIcon();
		}
	}

	al_blog_do_after_load_article();

	blogPreview.on( 'click', 'a.button', function ( e ) {
		e.preventDefault();

		var load = $( this ).data( 'load' );
		var windowheight = $( window ).height();

		if ( blogWrapper.is( ':hidden' ) ) {

			blogWrapper.css( 'min-height', 0 );
			blogWrapper.find( '.close' ).hide();
			blogLoader.css( 'display', 'block' );
			blogContent.html( '' );
			blogWrapper.css( 'height', windowheight + 'px' );

			blogWrapper.slideDown( 1000, function () {
				blogWrapper.css( 'min-height', windowheight + 'px' );
			} );

			$( 'html, body' ).clearQueue().animate( {
				scrollTop: blogWrapper.offset().top
			}, 1400 );

			setTimeout( function() {
				blogContent.load( load, { ajax: true }, function () {
					$( 'div.device-slider:not(.al-done)' ).alDeviceSlider();
					$( 'div.quote-slider:not(.al-done)' ).alQuoteSlider();
					$( 'div.al-client-carousel:not(.al-done)' ).alClientSlider();

					al_blog_do_after_load_article();
				} );
			}, 1600 );

		} else {

			blogWrapper.find( '.close' ).fadeOut( 800 );
			blogLoader.delay( 850 ).fadeIn();
			blogWrapper.css( 'height', blogWrapper.height() + 'px' );
			$( ".al-blog-article" ).fadeOut( 800 );

			$( 'html, body' ).clearQueue().animate( {
				scrollTop: blogWrapper.offset().top
			}, 1400 );

			setTimeout( function() {

				blogContent.load( load, { ajax: true }, function () {
					$( 'div.device-slider:not(.al-done)' ).alDeviceSlider();
					$( 'div.quote-slider:not(.al-done)' ).alQuoteSlider();
					$( 'div.al-client-carousel:not(.al-done)' ).alClientSlider();

					al_blog_do_after_load_article();
				} );
			}, 1600 );
		}
	} );

	/* ----------------------------------------- */
	/* 5.1 BLOG - LOAD MORE
	 /* ----------------------------------------- */
	var blogTabs = $( '#al-blog-tabs' );
	var blogLoadMoreLinks = $( '#al-blog-load-more-links' );
	var blogButtonLoadMore = $( '#al-blog-button-load-more' );
	var blogLoadMoreLoader = $( '#al-blog-load-more-loader' );
	var blogLoadMoreUrls = blogButtonLoadMore.data('post-paged');
    var blogLoadMoreFilter = ( blogButtonLoadMore.data('post-filter') ) ? blogButtonLoadMore.data('post-filter') : '';
    var blogLoadMoreFilterValue = ( blogButtonLoadMore.data('post-filter-value') ) ? blogButtonLoadMore.data('post-filter-value') : '';
	var blogLoadMoreUrl = '';
	var blogItemsPerLoad = al_blog_count_active_items();
	var itemsBefore = 0;
	var blogMixed = 0;

	// mixitup function
	function al_blog_mixitup() {

		if ( blogTabs.length > 0 ) {

			var active = blogTabs.find( 'li.active' ).data( 'filter' );

			if( blogMixed == 0) {
				blogMixed = 1;
				blogPreview.mixitup( {
					targetSelector: '.al-blog-mix',
					filterSelector: '.al-blog-filter',
					showOnLoad    : active
				} );

			} else {
				blogPreview.mixitup( 'remix', active );
			}
		} else {
            blogPreview.find( 'li' ).css( 'display', 'block' );
        }

		al_blog_preview_layers();
	}

    $( window ).load( function() {
        al_blog_mixitup();
    } );

	// get length of items in active category
	function al_blog_count_active_items() {

		var category = blogTabs.find( 'li.active' ).data( 'filter' );

		if ( category == 'all' ) {
			category = 'al-blog-mix';
		}

		return blogPreview.find( 'li.' + category ).length;
	}

	/* ----------------------------------------- */
	/* 5.1 BLOG - LOAD MORE FUNCTION
	 /* ----------------------------------------- */
	// function for load more
	function al_blog_load_more() {
		$.ajax( {
			type: 'POST',
			url: alAdmin.ajaxurl,
			data: {
				action: 'al_blog_load_more_posts',
				'post-paged': blogLoadMoreUrl,
                'post-filter': blogLoadMoreFilter,
                'post-filter-value': blogLoadMoreFilterValue
			},
			success: function ( articles ) {
				// check if there is more to load
				if ( $.isEmptyObject( blogLoadMoreUrls ) == false ) {
					if ( itemsBefore == 0 ) {
						itemsBefore = al_blog_count_active_items();
					}

					blogPreview.append( articles );

					// Falls weniger als die vom Admin eingestellten
					// Items pro Seite ausgegeben werden: nochmal laden
					if ( al_blog_count_active_items() < ( itemsBefore + blogItemsPerLoad ) ) {
						blogLoadMoreUrl = blogLoadMoreUrls.shift();
						al_blog_load_more( blogLoadMoreUrl );
					} else {
						itemsBefore = 0;
						al_blog_mixitup();

						blogLoadMoreLoader.fadeOut( 800, function () {
							blogButtonLoadMore.show();
						} );
					}

				} else {
					blogLoadMoreLoader.hide();
					blogLoadMoreLoader.closest( 'section' ).addClass( 'margin-bottom' );
					blogLoadMoreLoader.parent().slideUp( 1200 );
					blogPreview.append( articles );
					al_blog_mixitup();
				}
				al_vertical_mid_to_parent();
				al_load_iframe();
			},
			error: function( MLHttpRequest, textStatus, errorThrown ) {
				// alert( errorThrown );
			}
		} );
	}

	blogButtonLoadMore.on( 'click', function ( e ) {

		e.preventDefault();

		$( this ).hide();

		blogLoadMoreLoader.fadeIn( 800, function () {
			// Load More to blogPreview
			blogLoadMoreUrl = blogLoadMoreUrls.shift();
			al_blog_load_more();
		} );

	} );

	if( blogTabs.length > 0 ) {
		blogTabs.on( 'click', 'li.al-blog-filter > a', function() {
			if ( al_blog_count_active_items() == 0 ) {

				blogButtonLoadMore.hide();

				blogLoadMoreLoader.fadeIn( 800, function () {
					// Load More to blogPreview
					blogLoadMoreUrl = blogLoadMoreUrls.shift();
					al_blog_load_more( blogLoadMoreUrl );
				} );


			}
			al_vertical_mid_to_parent();
		});
	}


	/* --------------------------------------------------------------------- */
	/* 6. TOGGLE BOX (SHORTCODES)
	 /* --------------------------------------------------------------------- */


	$.fn.alToggleBox = function() {

		var elem = this;

		if( alToggleCloseAll ) {
			$('.toggle .header' ).each( function() {
				var item = $( this );

				item.removeClass( "active" );
				item.parent( ".toggle" ).children( ".content" ).slideUp();
				item.parent( ".toggle" ).children( ".header" ).children( ".plus" ).css( { display: 'inline-block' } );
				item.parent( ".toggle" ).children( ".header" ).children( ".minus" ).css( { display: 'none' } );
			} );
		}
		if ( elem.parent( ".toggle" ).children( ".content" ).is( ":hidden" ) ) {
			elem.addClass( "active" );
			elem.parent( ".toggle" ).children( ".content" ).slideDown();
			elem.parent( ".toggle" ).children( ".header" ).children( ".plus" ).css( { display: 'none' } );
			elem.parent( ".toggle" ).children( ".header" ).children( ".minus" ).css( { display: 'inline-block' } );
		} else {
			elem.removeClass( "active" );
			elem.parent( ".toggle" ).children( ".content" ).slideUp();
			elem.parent( ".toggle" ).children( ".header" ).children( ".plus" ).css( { display: 'inline-block' } );
			elem.parent( ".toggle" ).children( ".header" ).children( ".minus" ).css( { display: 'none' } );
		}

	};

	$( 'body' ).on( 'click', '.toggle .header', function() {
		$( this ).alToggleBox();
	} );


	/* --------------------------------------------------------------------- */
	/* 8. TAB CONTENT (SHORTCODES)
	 /* --------------------------------------------------------------------- */

	function al_tab_content() {
		$( ".tab-content-navi" ).each( function () {
			var link = $( this ).children( "li:first-child" ).children( "a" );
			var contentId = link.attr( "open-content" );
			$( "#" + contentId ).css( "display", "block" );
			link.addClass( "active" );
		} );

		$( ".tab-content-navi li a" ).click( function (e) {

			e.preventDefault();

			var contentId = $( this ).attr( "open-content" );

			if ( $( "#" + contentId ).is( ":hidden" ) ) {
				var list = $( this ).parent( "li" ).parent( "ul" );
				list.children( "li" ).each( function () {
					$( this ).children( "a" ).removeClass( "active" );
					var contentId = $( this ).children( "a" ).attr( "open-content" );
					$( "#" + contentId ).css( "display", "none" );
				} );
				$( "#" + contentId ).fadeIn( 400 );
				$( this ).addClass( "active" );
			}
		} );
	}

	al_tab_content();



	/* --------------------------------------------------------------------- */
	/* 9. ALERT BOX
	 /* --------------------------------------------------------------------- */

	$( 'body' ).on( 'click', '.alert-box .close', function ( e ) {
		e.preventDefault();
		$( this ).parent( '.alert-box' ).fadeOut( 350 );
	} );


	/* --------------------------------------------------------------------- */
	/* 10. CLEAR INPUNT
	 /* --------------------------------------------------------------------- */

	var defaultvalue;
	$( ".cleartext" ).focusin(function () {
		defaultvalue = this.defaultValue;
		if ( this.value == this.defaultValue ) {
			this.value = '';
		}
	} ).focusout( function () {
		if ( $( this ).val() == '' ) {
			this.value = defaultvalue;
		}
	} );

    /* --------------------------------------------------------------------- */
    /* 11. RESIZE
    /* --------------------------------------------------------------------- */

    var resizeEnd = 0;
    $( window ).resize( function () {
        if ( resizeEnd ) { clearTimeout( resizeEnd ); }
        resizeEnd = setTimeout( al_resize_end, 500 );
    } );

    function al_resize_end() {
		al_home_section_resize();
        al_blog_preview_layers();
        al_nav_position();
        al_vertical_mid_to_parent();
		al_video_fullscreen_resize();
    }

	// Positioning: Vertical Middle to Parent
	function al_vertical_mid_to_parent() {
		if( $( window ).width() > 979 ) {
			var elements = $( '.al-vertical-mid-to-parent' );

			elements.each( function() {
				var element = $( this );
				var parent = element.parent();
				var parentImg = parent.find( 'img' );

				if( parentImg.length > 0 ) {

					adjust_padding( element );

					parentImg.load( function() {
						adjust_padding( element );
					});

				} else {
					adjust_padding( element );
				}

				function adjust_padding( element ) {
					var diffHeight = element.parent().height() - element.height();
					var elementTop = 10;

					if( diffHeight > 0 ) {
						elementTop = diffHeight / 2 - 10;

						if ( elementTop < 10 ) {
							elementTop = 10;
						}
					}

					element.css( 'padding-top', Math.round( elementTop ) + 'px' );
				}
			} );
		}
	}

	/* ----------------------------------------- */
	/* RUN... PARALLAX BACKGROUNDS
	 /* ----------------------------------------- */

	$( 'section.al-home-banner' ).parallax( {
		speed: 0.25
	} );
	$( '.parallax-content' ).parallax( {
		speed: 0.25
	} );

	/* ----------------------------------------- */
	/* RUN... SLIDER
	 /* ----------------------------------------- */



	$( window ).load( function() {
		al_vertical_mid_to_parent();
		al_video_fullscreen_resize();

		/* ==== DEVICE SLIDER  ==== */
		$( 'div.device-slider' ).alDeviceSlider();

		/* ==== COMMENT SLIDER  ==== */
		$( 'div.quote-slider' ).alQuoteSlider();

		/* ==== CLIENT SLIDER  ==== */
		$( 'div.al-client-carousel' ).alClientSlider();

	} );

	/* --------------------------------------------------------------------- */
	/* Video
	 /* --------------------------------------------------------------------- */
	var videoFullscreen = $( '.al-video-fullscreen' );

	function al_video_fullscreen_resize() {
		if( videoFullscreen.length > 0 ) {
			videoFullscreen.css( 'min-height', $( window ).height() + 'px' );
		}
	}

	/* --------------------------------------------------------------------- */
	/* Home Slider Links
	 /* --------------------------------------------------------------------- */
	$( window ).load( function() {
		var dataHrefLinks = $( '[data-href!=""][data-href]' );
		dataHrefLinks.css( 'cursor', 'pointer' );

		dataHrefLinks.on( 'click', function () {
			window.open( $( this ).data('href'), '_self' );
		} );
	});

})( jQuery );

