/*!
 * @package    artless Flato
 * @author     Christian Glingener <glingener.christian@gmail.com>
 * @version    1.0.0
 * @copyright  2014 artlessthemes.com
 * @link       http://artlessthemes.com/
 */

(function ( $ ) {

	'use strict';

	$( window ).load( function() {
		$( '#al-home-slider' ).maximage( {
			cycleOptions: al_home_slider,
			onImagesLoaded: function() {
				var slider = $( '#al-home-slider' );
				var homeHeight = $('#home-parallax' ).height();
				if( homeHeight > slider.height() ) {
					slider.css( 'height', homeHeight + 'px' );
					slider.find( 'div.mc-image' ).css( 'height', homeHeight + 'px' );
				}
			}
		} );
	});

})( jQuery );