/*!
 * @package    artless Maps
 * @author     Christian Glingener <glingener.christian@gmail.com>
 * @version    1.0.0
 * @copyright  2014 artlessthemes.com
 * @link       http://artlessthemes.com/
 */
( function( $ ) {

    var alBody = $( 'body' );
	var pageType = $( '#al_page_type' );

	// Show Meta Boxes by selected Type
	function showPostMetaBox() {

		$( '[id^=al_content]:not([id^=al_blog_og],[id^=al_page_og]).postbox'  ).hide();

		var postType = $( '#post-formats-select' ).find( 'input:checked' ).val();

		$( '#al_content_' + postType + '').show();

	} showPostMetaBox();

	// On Type Change, call showPostMetaBox()
	$( '#post-formats-select' ).on( 'change.post-format', function() {
		showPostMetaBox();
	} );

	// Info Box
	alBody.on( 'click', '.alert-box .close, .alert-box .al-gmaps-close-button', function(){
		$(this).parent( '.alert-box' ).slideUp();
	} );

	// Home Section, Slide Content Code Examples
	function homeContentExample( code, top, left ) {

		var popup = $( '#home-content-example' );

		if( popup.length == 0 ) {
			var html = '<div id="home-content-example" class="alert-box notice" style="display: none; width: 700px; position: absolute; top:' + ( top + 20 ) + 'px; left: ' + left + 'px; z-index: 1000;" ><a class="close">x</a> Copy this code to your slide content.</div>';
			alBody.append( html );
			popup = $( '#home-content-example' );
		} else {
			popup.css( 'left', left );
			popup.css( 'top', top+20 );
		}

		var rows = code.split(/\n/ ).length;
		popup.find( 'textarea' ).remove();
		popup.prepend( '<textarea rows="' + rows + '">' + code + '</textarea>' );
		popup.slideDown();
	}

	$( '#al-home-slide-example1' ).on( 'click', function( e ) {
		e.preventDefault();

		var offset = $( this ).offset();
		var code = '<div class="al-home-container">\n\n    <h1>Welcome</h1>\n    <span class="subheadline">to artless 100% responsive <b>flat[highlighted]o[/highlighted]</b> theme</span>\n\n    <div class="al-home-content">\n        [button link="#" inline]View Portfolio[/button][button link="#" border inline]Purchase Now[/button]\n    </div>\n</div>';


		homeContentExample( code, offset.top, offset.left );
	});

	/**
	 * Standalone Page Options
	 */

	var standalone = $( '#al_standalone' );
	var sidebar = $( '#al_sidebar' ).parents( '.rwmb-field' ).first();;

	function show_hide_sidebar() {
		if( standalone.is(':checked') &&
			( pageType.val() == 'default' ||
			  pageType.val() == 'blog' ) ) {
			sidebar.show();
		} else {
			sidebar.hide();
		}
	}

	show_hide_sidebar();

	standalone.change( function() {
		show_hide_sidebar();
	} );

	/**
	 * Page Options Google Map
	 * @type {*|HTMLElement}
	 */
    var googleMap = $( '#al_google_map' );
    var googleMapField = googleMap.parents( '.rwmb-field' ).first();

    var googleMapIframeField = $( '#al_google_map_iframe' ).parents( '.rwmb-field' ).first();

	var googleMapElements = [
		$( '#al_google_map_height' ).parents( '.rwmb-field' ).first(),
		$( '#al_google_map_position').parents( '.rwmb-field' ).first()
	];

	function show_hide_google_settings() {

		if( pageType.val() == 'default' ) {

            googleMapField.show();

            if( googleMap.val() != 'none' ) {

                if( googleMap.val() == 'iframe' ) {
                    googleMapIframeField.show();
                } else {
                    googleMapIframeField.hide();
                }

                $.each( googleMapElements, function() {
                    $( this ).show();
                })
            } else {
                googleMapIframeField.hide();

                $.each( googleMapElements, function() {
                    $( this ).hide();
                })
            }

		} else {
            googleMapField.hide();
			googleMapIframeField.hide();
			$.each( googleMapElements, function() {
				$( this ).hide();
			})
		}
	}

	show_hide_google_settings();

	googleMap.change( function() {
		show_hide_google_settings();
	});

	/**
	 * Page Options VIDEO
	 * @type {*|HTMLElement}
	 */
	var videoSize = $( '#al_video_size' );
	var videoMinHeight = $( '#al_video_min_height').parents( '.rwmb-field' ).first();

	var videoElements = [
		videoSize.parents( '.rwmb-field' ).first(),
		$( '#al_video_links').parents( '.rwmb-field' ).first()
	];

	function show_hide_video_settings() {

		if( pageType.val() == 'video' ) {

			$.each( videoElements, function() {
				$( this ).show();
			} );

			if( videoSize.val() == 'fullwidth' ) {
				videoMinHeight.show();
			} else {
				videoMinHeight.hide();
			}

		} else {
			videoMinHeight.hide();
			$.each( videoElements, function() {
				$( this ).hide();
			})
		}
	}

	videoSize.change( function() {
		show_hide_video_settings();
	} );

    show_hide_video_settings();
	/**
	 * On page type change run
	 */
	pageType.change( function() {
		show_hide_sidebar();
        show_hide_google_settings();
		show_hide_video_settings();
    });

})( jQuery );

