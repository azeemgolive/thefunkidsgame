/*!
 * @package    artless Flato
 * @author     Christian Glingener <glingener.christian@gmail.com>
 * @version    1.0.0
 * @copyright  2014 artlessthemes.com
 * @link       http://artlessthemes.com/
 */
(function(a){a(window).load(function(){a("#al-home-slider").maximage({cycleOptions:al_home_slider,onImagesLoaded:function(){var b=a("#al-home-slider");var c=a("#home-parallax").height();if(c>b.height()){b.css("height",c+"px");b.find("div.mc-image").css("height",c+"px")}}})})})(jQuery);