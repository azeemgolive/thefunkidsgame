<?php
 /**
 * @package    artless Flato
 * @author     Christian Glingener <glingener.christian@gmail.com>
 * @version    1.0.0
 * @copyright  2014 artlessthemes.com
 * @link       http://artlessthemes.com/
 */

/**
 * Ajax
 * Blog Load More Function
 */
if ( isset( $_POST['al-blog-load-more'] ) ) {

	if ( have_posts() ) {
		get_template_part( AL_TEMPLATE_SECTION, 'blog-preview-single' );
	}

	die();
}

get_header();

get_template_part( AL_TEMPLATE_SECTION, 'blog-standalone' );

get_footer();