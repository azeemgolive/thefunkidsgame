<?php
/**
 * @package    artless Flato
 * @author     Christian Glingener <glingener.christian@gmail.com>
 * @version    1.0.0
 * @copyright  2014 artlessthemes.com
 * @link       http://artlessthemes.com/
 */

/**
 * Options
 */
global $al_theme_options;

// Show Comments on One-Page
global $content_show_comments;

$content_show_comments = $al_theme_options->getOption( 'al_blog_show_comments' );

if ( have_posts() ) {
	the_post();

	$post_format = get_post_format();

	?>

	<?php
	if ( isset( $_POST['ajax'] ) ) {
		?>
        <div <?php echo post_class(); ?>>
            <article class="al-blog-article">
                <?php
                if ( $post_format ) {
                    // Special Content ( Gallery, Audio, ...)
                    switch ( $post_format ) {
                        case 'gallery':
                        case 'audio':
                        case 'video':
                            get_template_part( AL_TEMPLATE_BLOG, $post_format );
                            break;
                    }
                }

                // Basic Content
                get_template_part( AL_TEMPLATE_BLOG );
                ?>
            </article>
        </div>
	<?php
	} else {

		get_header();
		?>
        <div <?php echo post_class(); ?>>
            <article class="al-blog-article">
                <div id="al-blog-wrapper" style="display: block;">
                    <div class="close">
                        <a class="al-close-back" href="<?php echo home_url() ?>/#al-blog-preview"></a>
                    </div>
                    <?php
                    if ( $post_format ) {
                        // Special Content ( Gallery, Audio, ...)
                        switch ( $post_format ) {
                            case 'gallery':
                            case 'audio':
                            case 'video':
                                get_template_part( AL_TEMPLATE_BLOG, $post_format );
                                break;
                        }
                    }
                    ?>
                </div>
                <?php get_template_part( AL_TEMPLATE_BLOG ); ?>
            </article>
        </div>
		<?php get_footer();
	}
	?>
<?php
}

