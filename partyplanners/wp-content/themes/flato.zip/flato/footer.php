<?php
/**
 * @package    artless Flato
 * @author     Christian Glingener <glingener.christian@gmail.com>
 * @version    1.0.0
 * @copyright  2014 artlessthemes.com
 * @link       http://artlessthemes.com/
 */

// Theme Options
global $al_theme_options;


/**
 * Blog Portfolio Slider
 */
$slider_options = array();

// Autoplay
$slider_autoplay = $al_theme_options->getOption( 'al_slider_autoplay' );
$slider_timeout = ( $slider_autoplay ) ? $al_theme_options->getOption( 'al_slider_timeout' ) : false;

if( $slider_timeout ) {
	$slider_options['autoPlay'] = $slider_timeout * 1000;
}

// Lazy Load
$slider_options['lazyLoad'] = ( $al_theme_options->getOption( 'al_slider_lazyload' ) ) ? true : false;

// Pagination
$slider_options['pagination'] = $al_theme_options->getOption( 'al_slider_pagination' )
	? true
	: false;

if( $al_theme_options->getOption( 'al_slider_transition' )
    && $al_theme_options->getOption( 'al_slider_transition' )  != 'default' ) {
	$slider_options['transitionStyle'] = $al_theme_options->getOption( 'al_slider_transition' );
}

if( $al_theme_options->getOption( 'al_slider_dragging' )
    && $al_theme_options->getOption( 'al_slider_dragging' ) != 'default' ) {

	switch( $al_theme_options->getOption( 'al_slider_dragging' ) ) {
		case 'false':
			$slider_options['mouseDrag'] = false;
			$slider_options['touchDrag'] = false;
			$slider_options['baseClass'] = "owl-carousel al-no-cursor-icon";
			break;
		case 'onTouch':
			$slider_options['mouseDrag'] = false;
			$slider_options['touchDrag'] = true;
			$slider_options['baseClass'] = "owl-carousel al-no-cursor-icon";
			break;
		case 'onMouse':
			$slider_options['mouseDrag'] = true;
			$slider_options['touchDrag'] = false;
			break;
	}
}

// Navigation
$slider_navigation = $al_theme_options->getOption( 'al_slider_button_next_prev' );

if( 'none' == $slider_navigation ) {
	$slider_options['navigation'] = false;
}


/**
 * Device Slider
 */
$device_slider_options = array();

// Autoplay
$device_slider_autoplay = $al_theme_options->getOption( 'al_device_slider_autoplay' );
$device_slider_timeout = ( $device_slider_autoplay ) ? $al_theme_options->getOption( 'al_device_slider_timeout' ) : false;

if( $device_slider_timeout ) {
    $device_slider_options['autoPlay'] = $device_slider_timeout * 1000;
}

/**
 * Quote Slider
 */
$quote_slider_options = array();

// Autoplay
$quote_slider_autoplay = $al_theme_options->getOption( 'al_quote_slider_autoplay' );
$quote_slider_timeout = ( $quote_slider_autoplay ) ? $al_theme_options->getOption( 'al_quote_slider_timeout' ) : false;

if( $quote_slider_timeout ) {
	$quote_slider_options['autoPlay'] = $quote_slider_timeout * 1000;
}

/**
 * Footer text
 */
$footer_text = $al_theme_options->getOption( 'al_general_footer_text' );
if ( $footer_text ) {
	?>
	<div class="bottom-box">
		<div class="row gutters">
			<?php echo do_shortcode( $footer_text ); ?>
		</div>
	</div>
<?php } ?>

</div><!-- END PAGE WRAPPER -->

<?php
/**
 * Output User Settings
 */
// Smooth Scroll
$smooth_scroll = $al_theme_options->getOption( 'al_general_smooth_scroll' );

if ( $smooth_scroll
	or !empty( $slider_options )
	or !empty( $device_slider_options )
	or !empty( $quote_slider_options ) ) { ?>
	<script type="text/javascript">
		(function ( $ ) {
			<?php if( $smooth_scroll ) { ?>
			$('a[href^="#"]:not([class="al-scrollto-anchor"])').each( function( e ) {
				$( this ).addClass('scrollto');
			});
			<?php } ?>
		})( jQuery );

		<?php if( !empty( $slider_options ) ) { ?>
		if (typeof alSliderSettingsUser === 'undefined') {
			var alSliderSettingsUser = <?php echo json_encode( $slider_options ); ?>;
		} else {
			alSliderSettingsUser = <?php echo json_encode( $slider_options ); ?>;
		}
		<?php } ?>

        <?php if( !empty( $device_slider_options ) ) { ?>
        if (typeof alDeviceSliderSettingsUser === 'undefined') {
            var alDeviceSliderSettingsUser = <?php echo json_encode( $device_slider_options ); ?>;
        } else {
            alDeviceSliderSettingsUser = <?php echo json_encode( $device_slider_options ); ?>;
        }
        <?php } ?>

		<?php if( !empty( $quote_slider_options ) ) { ?>
		if (typeof alQuoteSliderSettingsUser === 'undefined') {
			var alQuoteSliderSettingsUser = <?php echo json_encode( $quote_slider_options ); ?>;
		} else {
			alQuoteSliderSettingsUser = <?php echo json_encode( $quote_slider_options ); ?>;
		}
		<?php } ?>
	</script>
<?php
}

/**
 * Tracking Code
 */
$tracking_code = $al_theme_options->getOption( 'al_general_tracking' );
if ( $tracking_code ) {
	echo $tracking_code;
}

wp_footer();
?>
</body>
</html>