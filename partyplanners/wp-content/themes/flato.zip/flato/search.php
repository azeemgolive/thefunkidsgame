<?php
/**
 * The template for displaying Search Results pages
 *
 * @package WordPress
 * @subpackage Twenty_Fourteen
 * @since Twenty Fourteen 1.0
 */

get_header(); ?>

	<section id="primary" class="content-area">

        <div class="headline-wrapper">
            <div class="row">
                <h1 class="underline"><?php printf( __( 'Search Results for: %s', 'artless' ), get_search_query() ); ?></h1>
            </div>
        </div>

        <?php
        if ( have_posts() ) {
            get_template_part( AL_TEMPLATE_SECTION, 'search' );
        } else {
        ?>
            <div class="row gutters content-spacer">
                <div class="span-12" style="margin-bottom: 200px;">
                    <h4><?php  _e( 'Sorry, no results.', 'artless' );?></h4>
                    <p><a href="<?php echo home_url() ?>"><?php  _e( 'Back to Home...', 'artless' );?></a></p>
                </div>
            </div>
        <?php
        }
        ?>
	</section><!-- #primary -->

<?php
get_footer();
