<?php
/**
 * @package    artless Flato
 * @author     Christian Glingener <glingener.christian@gmail.com>
 * @version    1.0.0
 * @copyright  2014 artlessthemes.com
 * @link       http://artlessthemes.com/
 */

/**
 * Options
 */
global $al_theme_options;


// PreLoader
if ( ! isset( $al_preloader ) ) {
	$al_preloader = ( $al_theme_options->getOption( 'al_style_preloader', 'url' ) )
		? $al_theme_options->getOption( 'al_style_preloader', 'url' )
		: AL_PUBLIC . '/img/color_loader.gif';
}

if ( isset( $_POST['ajax'] ) ) {
	if ( is_single() ) {
		the_post();

		$post_format = get_post_format();
		?>

		<div class="al-pf-article" style="display: none;">

			<?php
			if ( $post_format ) {
				// Special Content ( Gallery, Audio, ...)
				switch ( $post_format ) {
					case 'gallery':
					case 'audio':
					case 'video':
						get_template_part( AL_TEMPLATE_PORTFOLIO, $post_format );
						break;
				}
			}

			// Basic Content
			get_template_part( AL_TEMPLATE_PORTFOLIO );
			?>
		</div>
	<?php
	}


} else {

	get_header();

	if ( have_posts() ) {

		the_post();

		$post_format = get_post_format();
		?>

		<div id="al-pf-wrapper" style="display: block;">
			<div class="close">
				<a id="al-pf-wrapper-close"></a>
			</div>
			<div id="al-pf-loader"><img class="al-loader-img" src="<?php echo $al_preloader; ?>" /></div>

			<div id="load-work-content">
				<?php
				if ( $post_format ) {
					// Special Content ( Gallery, Audio, ...)
					switch ( $post_format ) {
						case 'gallery':
						case 'audio':
						case 'video':
							get_template_part( AL_TEMPLATE_PORTFOLIO, $post_format );
							break;
					}
				}
				?>
			</div>
		</div>

		<?php
		// Basic Content
		get_template_part( AL_TEMPLATE_PORTFOLIO );
		?>
	<?php
	}
	get_footer();
}
?>
