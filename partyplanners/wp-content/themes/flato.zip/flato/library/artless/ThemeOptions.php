<?php
/**
 * @package    artless
 * @author     Christian Glingener <glingener.christian@gmail.com>
 * @version    1.0.0
 * @copyright  2014 artlessthemes.com
 * @link       http://artlessthemes.com/
 */

/**
 * Options
 * build on Redux-Framwork
 */

if( !class_exists( 'Artless_Theme_Options') AND class_exists( "ReduxFramework" ) ) {

	class Artless_Theme_Options {

        // Redux
        private $redux;

		// Options
		private static $options = array();

		// Redux Settings
		public $redux_settings;

		// Name of Menu
		private $menu_name = 'Theme Options';

		// Name of Global Options Var
		// DON'T CHANGE
		private $option_name = 'al_options';

		// Identicator
		public $identicator = 1;

		// Handlers
		private $handlers = array();

		// ContactUs
		public $contact_us = '<a href="mailto:support@artlessthemes.com">Need Support?</a>';

		/**
		 * __Construct
		 */
		public function __construct() {
			$this->init();
		}

		/**
		 * init
		 */
		private function init() {
			// Remove Redux 'Activate Demo Data'
			$this->remove_demo();
		}

		/**
		 * Register Handler
		 */
		public function registerHandler( $handler ) {
			$this->handlers[] = $handler;
		}

		/**
		 * Check if Method exists in Handler
		 */
		public function existHandlerMethod( $method ) {

			foreach ( $this->handlers as $handler ) {
				if ( method_exists( $handler, $method ) ) {
					return true;
				}
			}

			return false;
		}

		/**
		 * Call Handler
		 */
		public function __call( $method, $arguments ) {

			foreach ( $this->handlers as $handler ) {
				if ( method_exists( $handler, $method ) ) {
					return call_user_func_array(
						array(
							$handler,
							$method
						),
						$arguments
					);
				}
			}

			return false;
		}

		/**
         * get Option
         */
        public function getOption( $field, $key = false, $boolean = false ) {

            // Redux Option
            global $al_options;

            // Return value
            $return = false;

            // Options exists
            if( isset( $al_options[$field] ) ) {

                // Options key is set
                if( $key ) {

                    // Options key exists
                    if( isset( $al_options[$field][$key] ) ) {

                        // return value of field[key]
                        $return = $al_options[$field][$key];
                    }

                // No key set
                } else {
                    // return value of option
                    $return = $al_options[$field];
                }
            }

            // if return should boolean
            if( $boolean ) {

                // if return value
                if( $return ) {
                    $return = true;
                }
            }

            return $return;
        }


		/**
		 * print Options
		 */
		public function printOption( $field, $key = false, $format = false ) {

			$option = $this->getOption( $field, $key );

			if( $format ) {
				switch( $format ) {

				}
			} else {
				echo $option;
			}
		}

		/**
		 * Print Options as RGBA Value
		 * only for Hex Colors
		 */
		public function printRGBA( $field, $a = 1, $key = false ) {

			$option = $this->getOption( $field, $key );

			$hexColor = str_replace( '#', '', $option );

			if( ctype_xdigit( $hexColor ) ) {

				if(strlen( $hexColor ) == 3) {
					$r = hexdec( substr( $hexColor, 0, 1 ) . substr( $hexColor, 0, 1 ) );
					$g = hexdec( substr( $hexColor, 1, 1 ) . substr( $hexColor, 1, 1 ) );
					$b = hexdec( substr( $hexColor, 2, 1 ) . substr( $hexColor, 2, 1 ) );
				} else if (strlen( $hexColor ) == 6 ) {
					$r = hexdec( substr( $hexColor, 0, 2 ) );
					$g = hexdec( substr( $hexColor, 2, 2 ) );
					$b = hexdec( substr( $hexColor, 4, 2 ) );
				}

				if( isset( $r ) ) {
					if( $a >= 0 and $a <= 1 ) {
						echo 'rgba(' . $r . ',' . $g . ',' . $b . ',' . $a . ')';
					}
				}
			}
		}

		/**
		 * Add Options
		 */
		public static function addOption( $arr, $sortorder = false ) {

			// Proof if title and Fields exists
			// Cause nobody want empty Options with no Titles
			if( isset( $arr['title'] ) and isset( $arr['fields'] ) ) {

				if( !isset( $sortorder ) ){
					self::$options[] = $arr;
				} else {
					if( isset( self::$options[$sortorder] ) ) {
                        self::$options[] = $arr;
					} else {
                        self::$options[$sortorder] = $arr;
					}
				}
			}
		}

		/**
		 * "Render" Options in Admin
		 */
		public function renderAdmin() {

			ksort( self::$options );

			$this->redux = new ReduxFramework( self::$options, $this->redux_settings );

            // Add Google Api Key if set
            $google_api_key = $this->getOption('al_typo_google_api');

            if( $google_api_key ) {
                $this->redux->args['google_api_key'] = $google_api_key;
            }
		}

		/**
		 * Redux Settings
		 */
		public function setReduxSettings( array $user_settings = null ) {

			$theme = wp_get_theme();

			$default_settings = array(
				'opt_name' 			=> $this->option_name,
				'display_name' 		=> $theme->get('Name'),
				'display_version' 	=> $theme->get('Version'),
				'menu_type' 		=> 'submenu',
				'allow_sub_menu' 	=> true,
				'menu_title' 		=> __( 'Theme Options', 'artless'),
				'google_api_key' 	=> '',
				'global_variable' 	=> '',
				'dev_mode' 			=> false,
				'customizer' 		=> true,
				'page_priority'		=> null,
				'page_parent' 		=> 'themes.php',
				'page_permissions' 	=> 'manage_options',
				'menu_icon' 		=> '',
				'last_tab' 			=> '',
				'page_icon' 		=> 'icon-themes',
				'page_slug' 		=> '_options',
				'save_defaults' 	=> false,
				'default_show' 		=> false,
				'default_mark' 		=> '',
				// CAREFUL -> These options are for advanced use only
				'transient_time' 	=> 60 * MINUTE_IN_SECONDS,
				// Global shut-off for dynamic CSS output by the framework. Will also disable google fonts output
				'output' 			=> true,
				// Allows dynamic CSS to be generated for customizer and google fonts, but stops the dynamic CSS from going to the head
				'output_tag' 		=> false,
				'show_import_export'=> true,
                'hints' => array(
                    'icon'          => 'icon-question-sign',
                    'icon_position' => 'right',
                    'icon_color'    => 'gray',
                    'icon_size'     => 'big',
                    'tip_style'     => array(
                        'color'         => 'light',
                        'shadow'        => true,
                        'rounded'       => false,
                        'style'         => 'bootstrap',
                    ),
                    'tip_position'  => array(
                        'my' => 'top left',
                        'at' => 'bottom left',
                    ),
                    'tip_effect'    => array(
                        'show'          => array(
                            'effect'        => 'slide',
                            'duration'      => '500',
                            'event'         => 'click',
                        ),
                        'hide'      => array(
                            'effect'    => 'slide',
                            'duration'  => '500',
                            'event'     => 'click',
                        ),
                    ),
                )
			);


			if( $user_settings ) {
				$this->redux_settings = array_merge( $default_settings, $user_settings );
			} else {
				$this->redux_settings = $default_settings;
			}

		}

		/**
		 * Remove Demo
		 */
		function remove_demo() {

			// Used to hide the demo mode link from the plugin page. Only used when Redux is a plugin.
			if ( class_exists('ReduxFrameworkPlugin')) {

				// check the new Method name 'instance'
				if( method_exists( 'ReduxFrameworkPlugin', 'instance' )) {
					remove_filter('plugin_row_meta', array(ReduxFrameworkPlugin::instance(), 'plugin_metalinks'), null, 2);
					// Used to hide the activation notice informing users of the demo panel. Only used when Redux is a plugin.
					remove_action('admin_notices', array(ReduxFrameworkPlugin::instance(), 'admin_notices'));

				// check the old Method name 'get_instance'
				} else if( method_exists( 'ReduxFrameworkPlugin', 'get_instance' )) {
					remove_filter('plugin_row_meta', array(ReduxFrameworkPlugin::get_instance(), 'plugin_metalinks'), null, 2);
					remove_action('admin_notices', array(ReduxFrameworkPlugin::get_instance(), 'admin_notices'));
				}
			}
		}
	}

}