<?php
/**
 * @package    artless
 * @author     Christian Glingener <glingener.christian@gmail.com>
 * @version    1.0.0
 * @copyright  2014 artlessthemes.com
 * @link       http://artlessthemes.com/
 */

if( !class_exists( 'Artless_Plugin_Updater') ) {

	/**
	 * Class Artless_Plugin_Updater
	 */
	class Artless_Plugin_Updater {

	}

}