<?php
/**
 * @package    artless
 * @author     Christian Glingener <glingener.christian@gmail.com>
 * @version    1.0.0
 * @copyright  2014 artlessthemes.com
 * @link       http://artlessthemes.com/
 */

if( !class_exists( 'Artless_Helper') ) {

	/**
	 * Class Artless_Helper
	 */
	class Artless_Helper {

		private $path = array(
			'css' => array(
				'develop' => '/public/css/develop',
				'production' => '/public/css/production',
			),
			'js' => array(
				'develop' => '/public/js/develop',
				'production' => '/public/js/production',
			)
		);

		/**
		 * Returns Path of Child Theme File if exists, otherwise Theme File
		 *
		 * @param $file
		 * @param $type string css|js
		 *
		 * @return bool|string
		 */
		private function public_file( $file, $type ) {

			if( $type == 'css' OR $type == 'js' ) {

				$file_develop = get_template_directory() . $this->path[$type]['develop'] . $file;
				$file_production = get_template_directory() . $this->path[$type]['production'] . $file;

				// If Child Theme
				if( is_child_theme() ) {

					$file_child_develop = get_stylesheet_directory() . $this->path[$type]['develop'] . $file;
					$file_child_production = get_stylesheet_directory() . $this->path[$type]['production'] . $file;

					if( is_file( $file_child_production ) ) {
						return get_stylesheet_directory_uri() . $this->path[$type]['production'] . $file;
					} elseif( is_file( $file_child_develop ) ) {
						return get_stylesheet_directory_uri() . $this->path[$type]['develop'] . $file;
					}
				}

				if( is_file( $file_production ) ) {
					return get_template_directory_uri() . $this->path[$type]['production'] . $file;
				} elseif( is_file( $file_develop ) ) {
					return get_template_directory_uri() . $this->path[$type]['develop'] . $file;
				} else {
					return false;
				}

			} else {
				return false;
			}
		}

		/**
		 * @see public_file
		 */
		public function public_css( $file ) {
			return ( $this->public_file( $file, 'css' ) );
		}

		/**
		 * @see public_file
		 */
		public function public_js( $file ) {
			return ( $this->public_file( $file, 'js' ) );
		}
	}

}