<?php
/**
 * @package    artless Flato
 * @author     Christian Glingener <glingener.christian@gmail.com>
 * @version    1.0.0
 * @copyright  2014 artlessthemes.com
 * @link       http://artlessthemes.com/
 */

/**
 * Ajax
 * Blog Load More Function
 */
if ( isset( $_POST['al-blog-load-more'] ) ) {

	if ( have_posts() ) {
		get_template_part( AL_TEMPLATE_SECTION, 'blog-preview-single' );
	}

	die();
}

/**
 * OnePage
 */
$one_page_active = 0;

$qry_pages = new WP_Query( array(
	'post_type'      => 'page',
	'order'          => 'ASC',
	'orderby'        => 'menu_order date',
	'posts_per_page' => - 1
) );

get_header();

// have pages
if ( $qry_pages->have_posts() ) {
	while ( $qry_pages->have_posts() ) {

		$qry_pages->the_post();
		$id_post = get_the_ID();

		global $post;

		// Get Meta al_standalone
		$standalone = get_post_meta( $id_post, "al_standalone", TRUE );


		// Check if Page is not a Standalone Page
		if ( ! $standalone ) {

			// artless metas
			global $al_meta;

			$al_meta['show-title'] = get_post_meta( $id_post, "al_show_title", TRUE );
			$al_meta['title']      = get_post_meta( $id_post, "al_title", TRUE );
			$al_meta['subtitle']   = get_post_meta( $id_post, "al_subtitle", TRUE );
			$al_meta['page-type']  = get_post_meta( $id_post, "al_page_type", TRUE );

			$title                     = preg_replace( '#([^a-z0-9])#i', '', $post->post_title );
			if( empty( $title ) ) {
				$title = $post->ID;
			}
			$al_meta['section-anchor'] = 'to' . ucfirst( $title );

			switch( $al_meta['page-type'] ) {
				case 'blog':
				case 'home':
				case 'parallax':
				case 'portfolio':
				case 'video':
				case 'team':
				case 'single':
				case 'default':
					// One Page active
					$one_page_active = 1;

					get_template_part( AL_TEMPLATE_SECTION, $al_meta['page-type'] );
					break;
				// Uncomment and you will get all Pages as Section by default instead of blog
				/*
				default:
				 	$one_page_active = 1;
					get_template_part( AL_TEMPLATE_SECTION );
				*/
			}
		}
	}
}

// Show Blog on index, if user didn't want an one page.
if( $one_page_active == 0 ) {
	get_template_part( AL_TEMPLATE_SECTION, 'blog-standalone' );
}

get_footer();



