<?php
/**
 * @package    artless Flato
 * @author     Christian Glingener <glingener.christian@gmail.com>
 * @version    1.0.0
 * @copyright  2014 artlessthemes.com
 * @link       http://artlessthemes.com/
 */

get_header(); ?>

	<div id="primary" class="site-content">
		<div id="content" role="main">

			<section>
					<div class="headline-wrapper">
						<div class="row">
								<h1 class="underline">404</h1>
								<p class="undertitle"><?php  _e( 'Sorry, Page not found.', 'artless' );?></p>
						</div>
					</div>

					<div class="row gutters content-spacer">
						<div class="span-12" style="margin-bottom: 200px;">
							<p><a href="<?php echo home_url() ?>"><?php  _e( 'Back to Home...', 'artless' );?></a></p>
						</div>
					</div>
			</section>

		</div>
		<!-- #content -->
	</div><!-- #primary -->
<?php get_footer(); ?>