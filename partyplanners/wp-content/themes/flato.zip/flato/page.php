<?php
/**
 * @package    artless Flato
 * @author     Christian Glingener <glingener.christian@gmail.com>
 * @version    1.0.0
 * @copyright  2014 artlessthemes.com
 * @link       http://artlessthemes.com/
 */

get_header(); ?>

	<div id="primary" class="site-content">
		<div id="content" role="main">

			<?php
			while ( have_posts() ) {
				the_post();

				$id_post = get_the_ID();

				// Get Meta al_standalone
				$standalone = get_post_meta( $id_post, "al_standalone", TRUE );

				// mm metas
				global $al_meta;

				$al_meta['show-title']
					= get_post_meta( $id_post, "al_show_title", TRUE );
				$al_meta['title']
					= get_post_meta( $id_post, "al_title", TRUE );
				$al_meta['subtitle']
					= get_post_meta( $id_post, "al_subtitle", TRUE );
				$al_meta['page-type']
					= get_post_meta( $id_post, "al_page_type", TRUE );

				$title = preg_replace( '#([^a-z0-9])#i', '', $post->post_title );
				$al_meta['section-anchor'] = 'to' . ucfirst( $title );

				// should be standalone, but save
				if ( $standalone ) {
					switch ( $al_meta['page-type'] ) {
						case 'blog':
						case 'portfolio':
						case 'team':
						case 'video':
							get_template_part( AL_TEMPLATE_SECTION, $al_meta['page-type'] );
							break;
						default:
							get_template_part( AL_TEMPLATE_STANDALONE );
							break;
					}

				} else {

					switch ( $al_meta['page-type'] ) {
						case 'blog':
							get_template_part( AL_TEMPLATE_SECTION, 'single' );
							break;
						default:
							get_template_part( AL_TEMPLATE_SECTION, $al_meta['page-type'] );
							break;
					}
				}

				break;
			}
			?>
		</div>
		<!-- #content -->
	</div><!-- #primary -->
<?php get_footer(); ?>