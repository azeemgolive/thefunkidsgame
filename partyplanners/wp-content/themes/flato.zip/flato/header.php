<?php
/**
 * @package    artless Flato
 * @author     Christian Glingener <glingener.christian@gmail.com>
 * @version    1.0.0
 * @copyright  2014 artlessthemes.com
 * @link       http://artlessthemes.com/
 */
?><!DOCTYPE html>
<!--[if IE 7]>
<html class="ie ie7" <?php language_attributes(); ?>>
<![endif]-->
<!--[if IE 8]>
<html class="ie ie8" <?php language_attributes(); ?>>
<![endif]-->
<!--[if !(IE 7) | !(IE 8) ]><!-->
<html <?php language_attributes(); ?>>
<!--<![endif]-->
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
	<title><?php echo bloginfo( 'name' ); ?> | <?php is_front_page() ? bloginfo( 'description' ) : wp_title( '|', true, 'right' ); ?></title>

	<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
	<!--[if lt IE 9]>
    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/public/css/production/ie-stylesheet.css" media="all">
	<script src="<?php echo get_template_directory_uri(); ?>/public/js/production/html5.js"></script>
	<![endif]-->

	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>

<?php
global $al_theme_options;

$al_preloader = ( $al_theme_options->getOption( 'al_style_preloader', 'url' ) )
    ? $al_theme_options->getOption( 'al_style_preloader', 'url' )
    : AL_PUBLIC . '/img/color_loader.gif';

$al_navigation_toggle = ( $al_theme_options->getOption( 'al_general_navigation_button_html' ) )
    ? do_shortcode( $al_theme_options->getOption( 'al_general_navigation_button_html' ) )
    : '<i class="fa fa-bars"></i>';
?>
<div id="al-page-preloader">
    <div class="al-loader">
        <img class="al-loader-img" src="<?php echo $al_preloader; ?>" />
    </div>
</div>

<header id="header">
	<div class="logo-wrapper">
		<?php

		$al_general_logo = $al_theme_options->getOption( 'al_general_logo', 'url' )
			? $al_theme_options->getOption( 'al_general_logo', 'url' )
			: false;

		$logo_attributes = '';

		$logo_resize = $al_theme_options->getOption( 'al_general_logo_size' );

		if ( $logo_resize ) {
			$logo_width = $al_theme_options->getOption( 'al_general_logo_width' )
				? $al_theme_options->getOption( 'al_general_logo_width' )
				: false;

			$logo_height = $al_theme_options->getOption( 'al_general_logo_height' )
				? $al_theme_options->getOption( 'al_general_logo_height' )
				: false;

			$logo_attributes .= ( $logo_width ) ? ' width="' . $logo_width . '"' : '';
			$logo_attributes .= ( $logo_height ) ? ' height="' . $logo_height . '"' : '';

		}

		if ( $al_general_logo ) {
			echo '<a id="logo" href="'.home_url().'">'
				. '<img src="' . $al_general_logo . '"' . $logo_attributes . ' />'
				. '</a>';
		}
		?>
	</div>

	<ul id="main-navigation">
		<?php
		if ( has_nav_menu( 'primary' ) ) {
			wp_nav_menu( array(
				'theme_location' => 'primary',
				'container'      => false,
				'items_wrap'     => '%3$s',
				'walker'         => new Artless_Navigation()
			) );
		}
		?>
	</ul>

	<?php

	$social_links_file = AL_DIR . '/application/options/social-links/social-links.php';

	if ( is_file( $social_links_file ) ) {
		$social_links = require( $social_links_file );
		ksort( $social_links );

		$socials = array();

		foreach ( $social_links as $key => $social ) {

			$output = $al_theme_options->getOption( 'al_social_' . $key );

			if ( $output ) {
				$socials[] = '<a href="' . $output . '">'
					. '<i class="fa ' . $social['fa-icon'] . '"></i></a>';
			}
		}
	}

	if ( ! empty( $socials ) ) {
		echo '<div class="social-links">';

		foreach ( $socials as $social ) {
			echo $social;
		}

		echo '</div>';
	}

	if ( is_active_sidebar( 'al-navigation-top' ) ) {
		dynamic_sidebar( 'al-navigation-top' );
	}

	if ( is_active_sidebar( 'al-navigation-bottom' ) ) {
		dynamic_sidebar( 'al-navigation-bottom' );
	}

	?>
	<a id="open-nav"><?php echo $al_navigation_toggle; ?></a>

	<?php if( $al_theme_options->getOption( 'al_general_navigation_autoopen') ) { ?>
		<div id="open-nav-mousenter"></div>
	<?php } ?>
</header>


<div id="page-wrapper">
