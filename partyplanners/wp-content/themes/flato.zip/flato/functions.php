<?php
/**
 * @package    artless Flato
 * @author     Christian Glingener <glingener.christian@gmail.com>
 * @version    1.0.0
 * @copyright  2014 artlessthemes.com
 * @link       http://artlessthemes.com/
 */

if ( ! isset( $content_width ) ) {
	$content_width = 980;
}

/**
 * Artless Globals
 */
define( 'AL_DIR', untrailingslashit( get_template_directory() ) );
define( 'AL_URI', get_template_directory_uri() );
define( 'AL_PUBLIC', AL_URI . '/public' );

/**
 * Templates
 */
define( 'AL_TEMPLATE_SECTION', 'application/view/section/section' );
define( 'AL_TEMPLATE_BLOG', 'application/view/blog/content' );
define( 'AL_TEMPLATE_PORTFOLIO', 'application/view/portfolio/content' );
define( 'AL_TEMPLATE_STANDALONE', 'application/view/standalone/content' );
define( 'AL_TEMPLATE_PARTS', 'application/view/parts/part' );

/**
 * Meta-Box Globals
 */
define( 'RWMB_URL', AL_URI . '/library/meta-box/' );
define( 'RWMB_DIR', AL_DIR . '/library/meta-box/' );

/**
 * Artless Theme Options
 * uses ReduxFramework
 */
$al_theme_options_file = AL_DIR . '/library/artless/ThemeOptions.php';

// Load Options Class
if ( is_file( $al_theme_options_file ) ) {
	require_once( $al_theme_options_file );
}

// Load Artless Theme Options Class
if ( class_exists( 'Artless_Theme_Options' ) ) {
	$al_theme_options = new Artless_Theme_Options();

// Run Theme without Theme Options
} else {
	class Artless_Theme_Options {

		public function __construct() {
			return false;
		}

        public function __call( $method, $args ) {
            return false;
        }

	}

	$al_theme_options = new Artless_Theme_Options();
}

/**
 * Artless Helper
 * uses ReduxFramework
 */
$al_helper_file = AL_DIR . '/library/artless/Helper.php';

// Load Options Class
if ( is_file( $al_helper_file ) ) {
	require_once( $al_helper_file );
}

// Load Artless Theme Options Class
if ( class_exists( 'Artless_Helper' ) ) {
	$al_helper = new Artless_Helper;
}

/**
 * Translation
 */
load_theme_textdomain( 'artless', AL_DIR . '/public/lang' );

$locale_file = AL_DIR . '/public/lang/' . get_locale() . '.php';

if ( is_readable( $locale_file ) ) {
    require_once( $locale_file );
}

/**
 * DEVICE DETECT
 */
if( ! defined( 'AL_DEVICE' ) ) {

	$device_detect_file = AL_DIR . '/library/mobile-detect/Mobile_Detect.php';

	if ( is_file( $device_detect_file ) ) {
		require_once( $device_detect_file );

		$detect = new Mobile_Detect;
		$deviceType = ($detect->isMobile() ? ($detect->isTablet() ? 'tablet' : 'phone') : 'computer');
	} else {
		$deviceType = 'computer';
	}

	define( 'AL_DEVICE', $deviceType );
}



/**
 * RSS
 */
add_theme_support( 'automatic-feed-links' );

/**
 * Artless Flato setup
 *
 * Note that this function is hooked into the after_setup_theme hook, which
 * runs before the init hook. The init hook is too late for some features, such
 * as indicating support post thumbnails.
 */
add_action( 'after_setup_theme', 'al_setup' );

function al_setup() {

	/*
	 * Post Formats ( >= WP 3.1 )
	 */
	add_theme_support(
		'post-formats',
		array(
			'gallery',
			'audio',
			'video'
		)
	);

	/*
	 * Post Thumbnails
	 */
	add_theme_support( 'post-thumbnails' );
	set_post_thumbnail_size( 150, 150 );

	add_image_size( 'al-blog-preview', 600, 360, true );
	add_image_size( 'al-gallery', 1600 );
	add_image_size( 'al-parallax', 2400 );

	/*
	 * Prime Nav
	 */
	register_nav_menus( array(
		'primary' => __( 'Flato Menu - Left Side', 'artless' ),
	) );

	/*
	 * Switch output to valid HTML5
	 */
	add_theme_support(
		'html5',
		array(
			'search-form',
			'comment-form',
			'comment-list',
		)
	);

	/**
	 * Required Files
	 */
	$required_files = array(

		// Meta-Box
		AL_DIR . '/library/meta-box/meta-box.php',
		// Theme Extensions ( to keep this file cleaner )
		AL_DIR . '/application/extensions/extensions.php',
		// TGM
		AL_DIR . '/library/tgm-plugin-activation/class-tgm-plugin-activation.php'
	);

	// for each file in $require_files
	foreach ( $required_files as $file ) {
		// if file exists
		if ( is_file( $file ) ) {
			require( $file );
		}
	}

}

/**
 * Artless Options
 */
add_action( 'init', 'al_options' );

function al_options() {
	/**
	 * Redux
	 */
	if ( class_exists( 'ReduxFramework' ) ) {

		// Theme Options Class
		global $al_theme_options;

		// Redux Options
		$options_file = AL_DIR . '/application/options/options.php';

		if ( is_file( $options_file ) ) {
			require( $options_file );
		}

		// Redux Social Icons
		$redux_settings['share_icons']['github'] = array(
			'url'   => 'mailto:support@artlessthemes.com',
			'title' => 'support@artlessthemes.com',
			'icon'  => 'el-icon-question-sign'
		);

		// Redux Add content after the form.
		$redux_settings['footer_text'] = '<p><a href="http://artlessthemes.com">artlessthemes.com</a></p>';

		// Render Admin Options
		$al_theme_options->setReduxSettings( $redux_settings );
		$al_theme_options->renderAdmin();

		// Auto Theme Update
		if( is_admin() ) {
			$auto_update_username = $al_theme_options->getOption( 'al_updates_username' )
				? $al_theme_options->getOption( 'al_updates_username' )
				: false;

			$auto_update_api_key = $al_theme_options->getOption( 'al_updates_api_key' )
				? $al_theme_options->getOption( 'al_updates_api_key' )
				: false;


			if( $auto_update_username and $auto_update_api_key ) {
				$auto_update_file = AL_DIR . '/library/envato-wp-theme-updater/envato-wp-theme-updater.php';

				if( file_exists( $auto_update_file ) ) {
					require_once( $auto_update_file );
					Envato_WP_Theme_Updater::init( $auto_update_username, $auto_update_api_key, 'artless' );
				}
			}
		}

	}

	/**
	 * Ajax
	 */
	// Blog Load More
	$ajax_blog_load_more_file = AL_DIR . '/application/ajax/blog-load-more-posts.php';

	if ( is_file( $ajax_blog_load_more_file ) ) {
		require_once( $ajax_blog_load_more_file );
	}

	// Portfolio Load More
	$ajax_pf_load_more_file = AL_DIR . '/application/ajax/portfolio-load-more-posts.php';

	if ( is_file( $ajax_pf_load_more_file ) ) {
		require_once( $ajax_pf_load_more_file );
	}
}

/**
 * OpenGraph Meta Tags
 */
add_action( 'wp_head', 'al_opengraph_meta_tags' );
function al_opengraph_meta_tags() {
	global $al_theme_options;

	$opengraph = $al_theme_options->getOption( 'al_sharing_opengraph' )
		? $al_theme_options->getOption( 'al_sharing_opengraph' )
		: false;

	if( $opengraph ) {
		$post_type = get_post_type();

		// For One Page
		if ( is_front_page() and is_home() ) {
			$title = $al_theme_options->getOption( 'al_sharing_title' )
				? $al_theme_options->getOption( 'al_sharing_title' )
				: get_bloginfo( 'title' );

			$meta = array(
				'og:title' => $title,
				'og:url' => site_url(),
			);

			$desc = $al_theme_options->getOption( 'al_sharing_description' )
				? $al_theme_options->getOption( 'al_sharing_description' )
				: get_bloginfo( 'description' );

			$desc = ( !empty( $desc ) ) ? $desc : false;

			if( $desc ) {
				$meta['og:description'] = $desc;
			}

			$images = $al_theme_options->getOption( 'al_sharing_images' )
				? $al_theme_options->getOption( 'al_sharing_images' )
				: false;

			if ( $images ) {
				$images_arr = explode( ',', $images );
				foreach( $images_arr as $image ) {
					$thumbnail = wp_get_attachment_image_src( $image, 'full' );
					$meta['images'][] = $thumbnail[0];
				}
			}

			foreach( $meta as $key => $value ) {
				if( $key == 'images' ) {
					foreach( $value as $image ) {
						echo '<meta property="og:image" content="' . $image . '" />';
					}
				} else {
					echo '<meta property="' . $key . '" content="' . $value . '" />';
				}

			}
		// Blog Post
		} elseif ( 'post' == $post_type ) {

			$opengraph_blog = $al_theme_options->getOption( 'al_sharing_opengraph_blog' )
				? $al_theme_options->getOption( 'al_sharing_opengraph_blog' )
				: false;

			if( $opengraph_blog ) {
				$title = get_post_meta( get_the_ID(), "al_blog_og_title", TRUE );
				$title = ( !empty( $title ) ) ? $title : get_the_title();

				$meta = array(
					'og:title' => $title,
					'og:url' => get_permalink(),
				);

				$desc = get_post_meta( get_the_ID(), "al_blog_og_description", TRUE );
				$desc = ( !empty( $desc ) ) ? $desc : false;

				if( $desc ) {
					$meta['og:description'] = $desc;
				}

				if ( has_post_thumbnail() ) {
					$thumbnail = wp_get_attachment_image_src( get_post_thumbnail_id(), 'full' );
					$meta['og:image'] = $thumbnail[0];
				}

				if( get_post_format() == 'gallery' ) {
					$images = rwmb_meta( 'al_content_gallery_images', 'type=image&size=full' );

					if( is_array( $images ) ) {
						foreach ( $images as $image ) {
							$meta['images'][] =  $image['url'];
						}
					}
				}

				foreach( $meta as $key => $value ) {
					if( $key == 'images' ) {
						foreach( $value as $image ) {
							echo '<meta property="og:image" content="' . $image . '" />';
						}
					} else {
						echo '<meta property="' . $key . '" content="' . $value . '" />';
					}
				}
			}

		// Page
		} elseif ( 'page' == $post_type  ) {

			$opengraph_page = $al_theme_options->getOption( 'al_sharing_opengraph_page' )
				? $al_theme_options->getOption( 'al_sharing_opengraph_page' )
				: false;

			if( $opengraph_page ) {
				$title = get_post_meta( get_the_ID(), "al_page_og_title", TRUE );
				$title = ( !empty( $title ) ) ? $title : get_the_title();

				$meta = array(
					'og:title' => $title,
					'og:url' => get_permalink(),
				);

				$desc = get_post_meta( get_the_ID(), "al_page_og_description", TRUE );
				$desc = ( !empty( $desc ) ) ? $desc : false;

				if( $desc ) {
					$meta['og:description'] = $desc;
				}

				if ( has_post_thumbnail() ) {
					$thumbnail = wp_get_attachment_image_src( get_post_thumbnail_id(), 'full' );
					$meta['og:image'] = $thumbnail[0];
				}

				foreach( $meta as $key => $value ) {
					echo '<meta property="' . $key . '" content="' . $value . '" />';
				}
			}

		}
	}
}

/**
 * Widgets
 */
add_action( 'widgets_init', 'al_widgets_init' );

function al_widgets_init() {
	register_sidebar( array(
		'name'          => __( 'Main Sidebar', 'artless' ),
		'id'            => 'al-sidebar-right',
		'description'   => __( 'Appears on Standalone-Pages and Single-Blog-Posts', 'artless' ),
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h3 class="widget-title">',
		'after_title'   => '</h3>',
	) );

	register_sidebar( array(
		'name'          => __( 'Navigation Top', 'artless' ),
		'id'            => 'al-navigation-top',
		'description'   => __( 'Adjust it under "Theme Options" -> "General"', 'artless' ),
		'before_widget' => '<div class="al-widget-navigation-top"><div>',
		'after_widget'  => '</div></div>',
		'before_title'  => '',
		'after_title'   => '',
	) );

	register_sidebar( array(
		'name'          => __( 'Navigation Bottom', 'artless' ),
		'id'            => 'al-navigation-bottom',
		'description'   => __( 'Adjust it under "Theme Options" -> "General"', 'artless' ),
		'before_widget' => '<div class="al-widget-navigation-bottom"><div>',
		'after_widget'  => '</div></div>',
		'before_title'  => '',
		'after_title'   => '',
	) );
}

/**
 * Front
 */
if ( ! is_admin() ) {

	/**
	 * SCRIPTS
	 */
	add_action( 'wp_enqueue_scripts', 'al_front_scripts', 1 );

	function al_front_scripts() {
		global $al_helper;
		global $al_theme_options;

		// jQuery - Easing
		$js = $al_helper->public_js( '/jquery.easing.1.3.js' );
		wp_register_script( 'jquery.easing', $js, array( 'jquery' ), '1.3', true );

		// jQuery - Parallax
		$js = $al_helper->public_js( '/jquery.parallax-1.1.3.js' );
		wp_register_script( 'jquery.parallax', $js,	array( 'jquery' ), '1.1.3', true );

		// jQuery - BXSlider
		// $js = $al_helper->public_js( '/jquery.bxslider.js' );
		// wp_register_script( 'jquery.bxslider', $js,	array( 'jquery' ), '4.1.1', true );

		// jQuery - Owl Carousel
		$js = $al_helper->public_js( '/owl.carousel.js' );
		wp_register_script( 'jquery.owl.carousel', $js,	array( 'jquery' ), '1.3.3', true );

		// jQuery - Hoverdir
		$js = $al_helper->public_js( '/jquery.hoverdir.js' );
		wp_register_script( 'jquery.hoverdir', $js,	array( 'jquery' ), '1.1.0', true );

		// jQuery - MixItUp
		$js = $al_helper->public_js( '/jquery.mixitup.js' );
		wp_register_script( 'jquery.mixitup', $js, array( 'jquery' ), '1.5.5', true );

		// jQuery - CarouFredSel
		// $js = $al_helper->public_js( '/jquery.carouFredSel-6.2.1.js' );
		// wp_register_script( 'jquery.carouFredSel', $js,	array( 'jquery' ), '6.2.1', true );

		// jQuery - Cycle
		$js = $al_helper->public_js( '/jquery.cycle.all.js' );
		wp_register_script( 'jquery.cycle.all', $js, array( 'jquery' ), '2.9998', true );

		// jQuery - Maximage
		$js = $al_helper->public_js( '/jquery.maximage.js' );
		wp_register_script( 'jquery.maximage', $js, array( 'jquery.cycle.all' ), '2.0.8', true );

		// Youtube Iframe Api
		wp_register_script( 'youtube.iframeapi', '//www.youtube.com/iframe_api', array(), '1.0', true );

		// jQuery - Tubular
		$js = $al_helper->public_js( '/jquery.tubular.modified.js' );
		wp_register_script( 'jquery.tubular', $js, array( 'jquery', 'youtube.iframeapi' ), '1.0', true );

		// Modernizr
		$js = $al_helper->public_js( '/modernizr.custom.97074.js' );
		wp_register_script( 'modernizr', $js, array(), '2.6.2', true );

		// SmoothScroll
		$js = $al_helper->public_js( '/SmoothScroll.js' );
		wp_register_script( 'SmoothScroll', $js, array(), '1.2.1', true );

		// Respond
		$js = $al_helper->public_js( '/respond.min.js' );
		wp_register_script( 'respond', $js,	array(), '1.1.0', true );

		// Flato
		$js = $al_helper->public_js( '/theme.js' );
		wp_register_script( 'al-flato', $js, array( 'jquery', 'respond', 'SmoothScroll', 'modernizr' ), '1.1.2', true );

        // Flato Slider
        $js = $al_helper->public_js( '/theme.slider.js' );
        wp_register_script( 'al-flato-slider', $js, array( 'jquery.maximage' ), '1.1.2', true );

		// Custom JS
		$js = $al_helper->public_js( '/custom.js' );
		wp_register_script( 'al-flato-custom', $js, array( 'jquery' ), '1.0', true );

		wp_enqueue_script( 'jquery.easing' );
		wp_enqueue_script( 'jquery.parallax' );
		//wp_enqueue_script( 'jquery.bxslider' );
		wp_enqueue_script( 'jquery.owl.carousel' );
		wp_enqueue_script( 'jquery.hoverdir' );
		wp_enqueue_script( 'jquery.mixitup' );
		// wp_enqueue_script( 'jquery.carouFredSel' );

		// If Home Slider is activated
		if ( $al_theme_options->getOption( 'al_home_show_slider' ) ) {

            // User Settings
            // - Transition
            $slider_transition = $al_theme_options->getOption( 'al_home_slider_transition' );

            switch ( $slider_transition ) {
                case 'fade':
                case 'scrollLeft':
                case 'scrollRight':
                case 'scrollUp':
                case 'scrollDown':
                    break;
                default:
                    $slider_transition = 'fade';
            }
            // - Timeout
            $slider_timeout = $al_theme_options->getOption( 'al_home_slider_timeout' ) * 1000;

            // - Pause on Mousehover
            $slider_pause_on_mousehover = 0;

            if ( $al_theme_options->getOption( 'al_home_slider_pause_on_mousehover' ) ) {
                $slider_pause_on_mousehover = 1;
            }

            ?>
            <script type="text/javascript">
                //<![CDATA[
                var al_home_slider = {
                    fx     : '<?php echo $slider_transition; ?>',
                    speed  : 1000,
                    timeout: <?php echo $slider_timeout; ?>,
                    prev   : '.maximage-prev',
                    next   : '.maximage-next',
                    pause  : <?php echo $slider_pause_on_mousehover; ?>
                };
                //]]>
            </script>

            <?php
			wp_enqueue_script( 'al-flato-slider' );
		}

		wp_enqueue_script( 'al-flato' );
		wp_enqueue_script( 'al-flato-custom' );
	}

    /**
	 * STYLES
	 */
	add_action( 'wp_enqueue_scripts', 'al_front_styles', 50 );

	function al_front_styles() {
		global $al_helper;
		global $al_theme_options;

		// reset css
		$css = $al_helper->public_css( '/reset.css' );
		wp_register_style( 'al-reset', $css, array(), '1', 'all' );

		// font-awesome
		$css = $al_helper->public_css( '/font-awesome.min.css' );
		wp_register_style( 'font-awesome', $css, array(), '4.1.0', 'all' );

		// responsive gs
		$css = $al_helper->public_css( '/responsive.gs.12col.css' );
		wp_register_style( 'responsive-gs', $css , array(), '1', 'all' );

		// jquery bxslider
		// $css = $al_helper->public_css( '/jquery.bxslider.css' );
		// wp_register_style( 'jquery-bxslider', $css, array(), '1', 'all' );

		// jquery owl carousel
		$css = $al_helper->public_css( '/jquery.owl.carousel.css' );
		wp_register_style( 'jquery-owl-carousel', $css, array(), '1.3.3', 'all' );

		// jquery maximage
		$css = $al_helper->public_css( '/jquery.maximage.css' );
		wp_register_style( 'jquery-maximage', $css, array(), '1', 'all' );

		// theme css
		$css = $al_helper->public_css( '/theme.css' );
		wp_register_style( 'al-theme', $css, array(), '1.1.2', 'all' );

		// comments css
		$css = $al_helper->public_css( '/comments.css' );
		wp_register_style( 'al-comments', $css, array(), '1.1.2', 'all' );

        // responsive css
        $css = $al_helper->public_css( '/responsive.css' );
        wp_register_style( 'al-responsive', $css, array(), '1.1.2', 'all' );

		// Google Open Sans - Default Theme Font
		wp_register_style( 'googlefont-open-sans', 'http://fonts.googleapis.com/css?family=Open+Sans:400italic,300,400,600,700', array(), '1', 'all' );

		// enqueue all the good stuff
		wp_enqueue_style( 'al-reset' );
		wp_enqueue_style( 'font-awesome' );
		wp_enqueue_style( 'responsive-gs' );
		// wp_enqueue_style( 'jquery-bxslider' );
		wp_enqueue_style( 'jquery-owl-carousel' );

		// If Home Slider is activated
		if ( $al_theme_options->getOption( 'al_home_show_slider' ) ) {
            wp_enqueue_style( 'jquery-maximage' );
		}

		wp_enqueue_style( 'al-theme' );
		wp_enqueue_style( 'al-comments' );
        wp_enqueue_style( 'al-responsive' );
	}

	// Custom Styles
	if ( is_file( AL_DIR . '/header-custom-styles.php' ) ) {
		include( AL_DIR . '/header-custom-styles.php' );
	}

	/**
	 * BACKEND
	 */
} else {
	// Scripts
	add_action( 'admin_enqueue_scripts', 'al_backend_scripts' );

	function al_backend_scripts() {
		global $al_helper;

		$js = $al_helper->public_js( '/theme.admin.js' );
		wp_register_script( 'al-theme-admin', $js , array( 'jquery'), '1.1.2', TRUE );

		wp_enqueue_script( 'al-theme-admin' );
		wp_localize_script( 'al-theme-admin', 'alAdmin', array( 'ajaxurl' => admin_url( 'admin-ajax.php' ) ) );
	}

	// Style
	add_action( 'admin_enqueue_scripts', 'al_backend_styles' );
	function al_backend_styles() {
		global $al_helper;

		$css = $al_helper->public_css( '/theme.admin.css' );
		wp_register_style( 'al-theme-admin', $css, array(), '1.1.2', 'all' );
		wp_enqueue_style( 'al-theme-admin' );
	}
}

/**
 * WIDGET ARCHIVES MODIFICATION
 */
add_filter( 'get_archives_link', 'al_widget_archives_post_count_to_link');

function al_widget_archives_post_count_to_link( $archive_link ) {

    if( preg_match( '#<\/a>(.*)<\/li>#u', $archive_link, $founds ) ) {
        $post_count = $founds[1];
        $archive_link = str_replace( $post_count, '', $archive_link );
        $archive_link = str_replace( '</a>', $post_count . '</a>', $archive_link );
    }

    return $archive_link;
}

/**
 * WIDGET CATEGORIES MODIFICATION
 */
add_filter( 'wp_list_categories', 'al_widget_categories_post_count_to_link');

function al_widget_categories_post_count_to_link( $list ) {

    preg_match_all( '#<\/a>\s([\(\)0-9]{3,10})#u', $list, $matches );

    foreach( $matches[1] as $post_count ) {
        $list = str_replace( '</a> ' . $post_count, ' ' . $post_count . '</a>', $list );
    }
    return( $list );
}

/**
 * READ MORE
 */
// Replaces the excerpt "more" text by a link
function new_excerpt_more( $more ) {
    global $post;
    return '<a class="moretag" href="'. get_permalink($post->ID) . '"> ...read more!</a>';
}
add_filter('excerpt_more', 'new_excerpt_more');

/**
 * TGM_Plugin_Activation
 */
add_action( 'tgmpa_register', 'al_register_required_plugins' );

function al_register_required_plugins() {

	/**
	 * Array of plugin arrays. Required keys are name and slug.
	 * If the source is NOT from the .org repo, then source is also required.
	 */
	$plugins = array(
        array(
            'name'               => 'Redux Framework',
            'slug'               => 'redux-framework',
			'source'			 => 'http://s3.amazonaws.com/artless-plugins/redux-framework.zip',
            'required'           => true,
            'version'            => '3.0.0',
        ),

        array(
            'name'               => 'artless Shortcodes',
            'slug'               => 'artless-shortcodes',
			'source'			 => 'https://artless-plugins.s3.amazonaws.com/artless-shortcodes/104/artless-shortcodes.zip',
            'required'           => false,
			'version'            => '1.0.4',
        ),

		array(
			'name'               => 'artless Portfolio',
			'slug'               => 'artless-portfolio',
			'source'			 => 'https://artless-plugins.s3.amazonaws.com/115/artless-portfolio.zip',
			'required'           => false,
			'version'            => '1.0.8',
		),

        array(
            'name'               => 'artless Team',
            'slug'               => 'artless-team',
			'source'			 => 'https://artless-plugins.s3.amazonaws.com/artless-team/106/artless-team.zip',
            'required'           => false,
			'version'            => '1.0.6',
        ),

        array(
            'name'               => 'artless Maps',
            'slug'               => 'artless-maps',
			'source'     		 => 'https://artless-plugins.s3.amazonaws.com/114/artless-maps.zip',
            'required'           => false,
			'version'            => '1.0.4',
        ),

        array(
            'name'               => 'artless Icons',
            'slug'               => 'artless-icons',
			'source'			 => 'https://artless-plugins.s3.amazonaws.com/115/artless-icons.zip',
            'required'           => false,
			'version'            => '1.0.1',
        ),


	);

	/**
	 * Array of configuration settings. Amend each line as needed.
	 * If you want the default strings to be available under your own theme domain,
	 * leave the strings uncommented.
	 * Some of the strings are added into a sprintf, so see the comments at the
	 * end of each line for what each argument will be.
	 */
	$config = array(
		'domain'           => 'artless', // Text domain - likely want to be the same as your theme.
		'default_path'     => '', // Default absolute path to pre-packaged plugins
		'parent_menu_slug' => 'themes.php', // Default parent menu slug
		'parent_url_slug'  => 'themes.php', // Default parent URL slug
		'has_notices'      => true, // Show admin notices or not
		'is_automatic'     => true, // Automatically activate plugins after installation or not
		'message'          => '', // Message to output right before the plugins table
		'strings'          => array(
			'page_title'                      => __( 'Install Required Plugins', 'artless' ),
			'menu_title'                      => __( 'Install Plugins', 'artless' ),
			'installing'                      => __( 'Installing Plugin: %s', 'artless' ), // %1$s = plugin name
			'oops'                            => __( 'Something went wrong with the plugin API.', 'artless' ),
			'notice_can_install_required'     => _n_noop( 'This theme requires the following plugin: %1$s.', 'This theme requires the following plugins: %1$s.' ), // %1$s = plugin name(s)
			'notice_can_install_recommended'  => _n_noop( 'This theme recommends the following plugin: %1$s.', 'This theme recommends the following plugins: %1$s.' ), // %1$s = plugin name(s)
			'notice_cannot_install'           => _n_noop( 'Sorry, but you do not have the correct permissions to install the %s plugin. Contact the administrator of this site for help on getting the plugin installed.', 'Sorry, but you do not have the correct permissions to install the %s plugins. Contact the administrator of this site for help on getting the plugins installed.' ), // %1$s = plugin name(s)
			'notice_can_activate_required'    => _n_noop( 'The following required plugin is currently inactive: %1$s.', 'The following required plugins are currently inactive: %1$s.' ), // %1$s = plugin name(s)
			'notice_can_activate_recommended' => _n_noop( 'The following recommended plugin is currently inactive: %1$s.', 'The following recommended plugins are currently inactive: %1$s.' ), // %1$s = plugin name(s)
			'notice_cannot_activate'          => _n_noop( 'Sorry, but you do not have the correct permissions to activate the %s plugin. Contact the administrator of this site for help on getting the plugin activated.', 'Sorry, but you do not have the correct permissions to activate the %s plugins. Contact the administrator of this site for help on getting the plugins activated.' ), // %1$s = plugin name(s)
			'notice_ask_to_update'            => _n_noop( 'The following plugin needs to be updated to its latest version to ensure maximum compatibility with this theme: %1$s.', 'The following plugins need to be updated to their latest version to ensure maximum compatibility with this theme: %1$s.' ), // %1$s = plugin name(s)
			'notice_cannot_update'            => _n_noop( 'Sorry, but you do not have the correct permissions to update the %s plugin. Contact the administrator of this site for help on getting the plugin updated.', 'Sorry, but you do not have the correct permissions to update the %s plugins. Contact the administrator of this site for help on getting the plugins updated.' ), // %1$s = plugin name(s)
			'install_link'                    => _n_noop( 'Begin installing plugin', 'Begin installing plugins' ),
			'activate_link'                   => _n_noop( 'Activate installed plugin', 'Activate installed plugins' ),
			'return'                          => __( 'Return to Required Plugins Installer', 'artless' ),
			'plugin_activated'                => __( 'Plugin activated successfully.', 'artless' ),
			'complete'                        => __( 'All plugins installed and activated successfully. %s', 'artless' ), // %1$s = dashboard link
			'nag_type'                        => 'updated' // Determines admin notice type - can only be 'updated' or 'error'
		)
	);

	tgmpa( $plugins, $config );

}

/**
 * Flush rewrite rules after theme switch
 */
add_action( 'after_switch_theme', 'al_flush_rewrite_rules' );

function al_flush_rewrite_rules() {
	flush_rewrite_rules();
}

/**
 * Update Notice
 */
$version = '115';

add_action( 'admin_notices', 'artless_admin_notice' );

function artless_admin_notice() {
	global $version, $current_user;

	$headline = 'Flato 1.1.5 - Update Message';
	$message = 'Hello ' . $current_user->user_login . ', <br /><br />'
		. 'we had to change our video shortcode since the great new features of Wordpress 3.9.1. Here the code of our new video shortcode:<br />
		[al_video type="vimeo,youtube" id="Video ID here" autoplay="yes,no"]</p>

		<p>Thanks for all your feedback and we are sorry for any inconvenience this update may have caused.</p>

		<p>Best Regards,<br />
		artless' ;

    $user_id = $current_user->ID;


    /* Check that the user hasn't already clicked to ignore the message */

    if ( ! get_user_meta( $user_id, 'artless_update_' . $version ) ) {

        echo '<div class="updated">';

        printf( '<h3>'.$headline.'</h3>'. '<p>' . $message . '</p><p><a href="%1$s"><b>Hide Notice</b></a> | <a href="mailto:support@artlessthemes.com"><b>Need Support?</b></a></p>', '?artless_update_' . $version . '=0');

        echo "</div>";
    }
}

add_action( 'admin_init', 'artless_admin_notice_ignore' );

function artless_admin_notice_ignore() {
    global $version, $current_user;
    $user_id = $current_user->ID;

    /* If user clicks to ignore the notice, add that to their user meta */

    if ( isset( $_GET['artless_update_'.$version]) && '0' == $_GET['artless_update_'.$version] ) {
		add_user_meta( $user_id, 'artless_update_'.$version, 'true', true);
    }
}

/**
 * Disable Wordpress.org Updates
 */
function disable_wordpress_org_update_flato( $r, $url ) {
	if ( 0 !== strpos( $url, 'http://api.wordpress.org/themes/update-check' ) )
		return $r; // Not a theme update request. Bail immediately.

	$themes = unserialize( $r['body']['themes'] );
	unset( $themes['artless Flato'] );
	unset( $themes['flato'] );
	$r['body']['themes'] = serialize( $themes );
	return $r;
}

add_filter( 'http_request_args', 'disable_wordpress_org_update_flato', 5, 2 );



/**
 * Hide Admin Bar
 */
/*
add_action( 'set_current_user', 'al_hide_admin_bar' );

function al_hide_admin_bar() {
	// for all
	show_admin_bar( false );
}
*/