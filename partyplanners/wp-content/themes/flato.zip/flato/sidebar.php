<?php
/**
 * @package    artless Flato
 * @author     Christian Glingener <glingener.christian@gmail.com>
 * @version    1.0.0
 * @copyright  2014 artlessthemes.com
 * @link       http://artlessthemes.com/
 */

if ( is_active_sidebar( 'al-sidebar-right' ) ) {
	dynamic_sidebar( 'al-sidebar-right' );
}