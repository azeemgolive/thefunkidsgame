<?php
/**
 * @package    artless Flato
 * @author     Christian Glingener <glingener.christian@gmail.com>
 * @version    1.0.0
 * @copyright  2014 artlessthemes.com
 * @link       http://artlessthemes.com/
 */
global $al_meta;
global $al_theme_options;

$gmap          = rwmb_meta( 'al_google_map' );
$gmap_iframe   = rwmb_meta( 'al_google_map_iframe' );
$gmap_height   = rwmb_meta( 'al_google_map_height' );
$gmap_position = rwmb_meta( 'al_google_map_position' );

if ( ! empty( $gmap ) and $gmap != 'none' ) {

	$gmap_height = preg_replace( '#[^0-9]#', '', $gmap_height );

	if ( ! empty( $gmap_height ) ) {
		$style = ' style="height:' . $gmap_height . 'px;"';
	} else {
		$style = '';
	}

	switch ( $gmap ) {
		case 'api':

			$error = false;

			if ( $al_theme_options->existHandlerMethod( 'googleMapsApi' ) ) {

				if ( $al_theme_options->googleMapsApi() ) {
					$script = $al_theme_options->scriptGoogleMapsApi();
					$gmap   = '<div class="al-google-maps-api" id="al-gmaps-' . $al_theme_options->identicator . '"' . $style . '></div>' . $script;

					$al_theme_options->identicator ++;
				} else {
					$error = "Map configuration invalid. Please check <i>\"Location Latitude, Longitude Coordinates\"</i> value. " . $al_theme_options->contact_us;
				}
			} else {
				$error = "Please activate <i>\"artless Maps\"</i>-Plugin to use artless <i>[google_maps_api]</i>-Shortcode. " . $al_theme_options->contact_us;
			}

			if ( $error ) {
				$gmap = '<div class="alert-box error">' . $error . ' <a class="close">x</a></div>';
			}

			break;

		case 'iframe':

			$gmap = '<div class="al-google-map"' . $style . '>' . $gmap_iframe . '</div>';
			break;
	}

} else {
	$gmap = false;
}