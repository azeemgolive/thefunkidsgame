<?php
/**
 * @package    artless Flato
 * @author     Christian Glingener <glingener.christian@gmail.com>
 * @version    1.0.0
 * @copyright  2014 artlessthemes.com
 * @link       http://artlessthemes.com/
 */

global $al_meta;

if( isset( $al_meta['show-title'] ) ) {
	if ( $al_meta['show-title'] or $al_meta['subtitle'] ) { ?>
	<div class="headline-wrapper">
		<div class="row">
			<?php if ( $al_meta['show-title'] ) { ?>
				<h1 class="underline"><?php echo $al_meta['title'] ? $al_meta['title'] : get_the_title(); ?></h1>
			<?php } ?>

			<?php if ( $al_meta['subtitle'] ) { ?>
				<p class="undertitle"><?php echo $al_meta['subtitle']; ?></p>
			<?php } ?>
		</div>
	</div>
<?php
	}
// if user data is imported and pages never been saved after import
} else {
?>
	<div class="headline-wrapper">
		<div class="row">
			<h1 class="underline"><?php the_title(); ?></h1>
		</div>
	</div>
<?php
}