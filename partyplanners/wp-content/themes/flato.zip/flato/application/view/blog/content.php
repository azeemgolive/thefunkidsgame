<?php
/**
 * @package    artless Flato
 * @author     Christian Glingener <glingener.christian@gmail.com>
 * @version    1.0.0
 * @copyright  2014 artlessthemes.com
 * @link       http://artlessthemes.com/
 */

global $al_theme_options;

// Term - Category
$categories = get_the_category();
$categories_str = '';

if( is_array( $categories ) ) {
	foreach ( $categories as $category ) {
		if ( $category->term_id != 1 ) {
			$categories_str .= '<a href="'.get_category_link( $category->term_id ).'" title="' . esc_attr( sprintf( __( "View all posts in %s", 'artless' ), $category->name ) ) . '">' . $category->name . '</a>, ';
		}
	}
	$categories_str = rtrim( $categories_str, ', ' );
}

$term_category = $al_theme_options->getOption( 'al_blog_term_category' )
	? $al_theme_options->getOption( 'al_blog_term_category' ) : 'CATEGORY / <i>[category-name]</i>';

if ( preg_match( '#\[category-name\]#', $term_category ) ) {
	if ( $categories_str != '' ) {
		$term_category = str_replace( '[category-name]', $categories_str, $term_category );
	} else {
		$term_category = false;
	}
}

// Term - Tags
$tags     = get_the_tags();
$tags_str = '';

if( is_array( $tags ) ) {
	foreach ( $tags as $tag ) {
		$tags_str .= '<a href="'.get_tag_link( $tag->term_id ).'" title="' . esc_attr( sprintf( __( "View all posts tagged with %s", 'artless' ), $tag->name ) ) . '">' . $tag->name . '</a>, ';
	}
	$tags_str = rtrim( $tags_str, ', ' );
}

$term_tags = $al_theme_options->getOption( 'al_blog_term_tags' )
    ? $al_theme_options->getOption( 'al_blog_term_tags' ) : 'TAGS / <i>[tags]</i>';

if ( preg_match( '#\[tags\]#', $term_tags ) ) {
    if ( $tags_str != '' ) {
        $term_tags = str_replace( '[tags]', $tags_str, $term_tags );
    } else {
        $term_tags = false;
    }
}

// Term - Author
$term_author = $al_theme_options->getOption( 'al_blog_term_author' )
	? $al_theme_options->getOption( 'al_blog_term_author' ) : 'AUTHOR / <i>[author-name]</i>';

$term_author = str_replace( '[author-name]', '<a href="'. get_author_posts_url( get_the_author_meta( 'ID' ) ) . '">' . get_the_author_meta( 'display_name' ) . '</a>', $term_author );

// Term - Date
$term_date = $al_theme_options->getOption( 'al_blog_term_date' )
	? $al_theme_options->getOption( 'al_blog_term_date' ) : 'DATE / <i>[date]</i>';

$term_date = str_replace( '[date]', '<a href="'. get_day_link( get_post_time( 'Y' ), get_post_time( 'm' ), get_post_time( 'j' ) ).'">' . get_the_date() . '</a>', $term_date );

// Term - Comments
$term_comments = $al_theme_options->getOption( 'al_blog_term_comments' )
	? $al_theme_options->getOption( 'al_blog_term_comments' ) : 'Comments';


?>
<div class="wrapper">
	<?php
	$comments = false;

	if ( ! isset( $_POST['ajax'] ) ) {

		// Sidebar
		$sidebar = $al_theme_options->getOption( 'al_blog_sidebar' );
		$sidebar = ( $sidebar == 'none' or $sidebar == 1 ) ? false : $sidebar;

		// Comments
		if( comments_open() || get_comments_number() ) {
			$comments = true;
		}

	} else {
		$sidebar = $al_theme_options->getOption( 'al_blog_sidebar_onepage' );
		$sidebar = ( $sidebar == 'none' or $sidebar == 1 ) ? false : $sidebar;

		global $content_show_comments;

		if ( $content_show_comments ) {
			// If comments
			if ( comments_open() || get_comments_number() ) {
				$comments = true;
			}
		}
	}

		?>
		<div class="row gutters">
			<?php if ( is_active_sidebar( 'al-sidebar-right' ) and $sidebar ) { ?>

				<?php if ( $sidebar == 'right' ) { ?>
					<div class="col span_8">
						<div class="row gutters">
							<h3><?php the_title(); ?></h3>
							<?php if ( $term_category ) { ?>
                                <span class="info"><?php echo $term_category; ?></span>
                            <?php } ?>
                            <?php if ( $term_tags ) { ?>
                                <span class="info"><?php echo $term_tags; ?></span>
                            <?php } ?>
							<span class="info"><?php echo $term_author; ?></span>
							<span class="info-last"><?php echo $term_date; ?></span>

                            <div class="content">
                                <?php the_content(); ?>
								<?php wp_link_pages( array( 'before' => '<div class="page-links"><p>' . __( 'Pages:', 'artless' ), 'after' => '</p></div>' ) ); ?>
                            </div>
                            <?php
							if ( $comments ) {
								comments_template();
							} elseif( isset( $_POST['ajax'] ) ) {
								if ( comments_open() || get_comments_number() ) {
									?>
									<a href="<?php the_permalink(); ?>#comments" class="button"><?php echo $term_comments; ?></a>
								<?php
								}
							}
							?>
						</div>
					</div>

					<div class="col span_4 last">
						<div class="row gutters">
							<?php get_sidebar(); ?>
						</div>
					</div>

				<?php } else { ?>

					<div class="col span_4">
						<div class="row gutters">
							<?php get_sidebar(); ?>
						</div>
					</div>

					<div class="col span_8 last">
						<div class="row gutters">
							<h3><?php the_title(); ?></h3>
							<?php if ( $term_category ) { ?>
								<span class="info"><?php echo $term_category; ?></span>
							<?php } ?>
                            <?php if ( $term_tags ) { ?>
                                <span class="info"><?php echo $term_tags; ?></span>
                            <?php } ?>
							<span class="info"><?php echo $term_author; ?></span>
							<span class="info-last"><?php echo $term_date; ?></span>

                            <div class="content">
                                <?php the_content(); ?>
								<?php wp_link_pages( array( 'before' => '<div class="page-links"><p>' . __( 'Pages:', 'artless' ), 'after' => '</p></div>' ) ); ?>
                            </div>
                            <?php
							if ( $comments ) {
								comments_template();
							} elseif( isset( $_POST['ajax'] ) ) {
								if ( comments_open() || get_comments_number() ) {
									?>
									<a href="<?php the_permalink(); ?>#comments" class="button"><?php echo $term_comments; ?></a>
								<?php
								}
							}
							?>
						</div>
					</div>
				<?php } ?>
			<?php
			} else {
				?>
				<h4><?php the_title(); ?></h4>

				<?php if ( $term_category ) { ?>
					<span class="info"><?php echo $term_category; ?></span>
				<?php } ?>
                <?php if ( $term_tags ) { ?>
                    <span class="info"><?php echo $term_tags; ?></span>
                <?php } ?>
				<span class="info"><?php echo $term_author; ?></span>
				<span class="info-last"><?php echo $term_date; ?></span>

                <div class="content">
                    <?php the_content(); ?>
					<?php wp_link_pages( array( 'before' => '<div class="page-links"><p>' . __( 'Pages:', 'artless' ), 'after' => '</p></div>' ) ); ?>
                </div>
                <?php
				if ( $comments ) {
					comments_template();
				} elseif( isset( $_POST['ajax'] ) ) {
					if ( comments_open() || get_comments_number() ) {
						?>
						<a href="<?php the_permalink(); ?>#comments" class="button"><?php echo $term_comments; ?></a>
					<?php
					}
				}
			}
			?>
		</div>


	<?php /* ajax  } else { ?>
		<div class="row gutters">
			<h4><?php the_title(); ?></h4>
			<?php if ( $term_category ) { ?>
				<span class="info"><?php echo $term_category; ?></span>
			<?php } ?>
            <?php if ( $term_tags ) { ?>
                <span class="info"><?php echo $term_tags; ?></span>
            <?php } ?>
			<span class="info"><?php echo $term_author; ?></span>
			<span class="info-last"><?php echo $term_date; ?></span>

            <div class="content">
				<?php
				add_filter( 'the_password_form', 'custom_password_form' );
				function custom_password_form() {
					global $post;
					$html = '<p>' . __( "This post is password protected.", 'artless' ) . '<br />'
	.'<a href="'. get_permalink( $post->ID ) .'">'. __( 'Unlock here.', 'artless' ) .'</a></p>';
					return $html;
				}

				global $more;
				$more = 0;
				the_content( __( 'Read more...', 'artless' ) );

				wp_link_pages( array( 'before' => '<div class="page-links"><p>' . __( 'Pages:', 'artless' ), 'after' => '</p></div>' ) ); ?>
            </div>

            <?php
			// Comments
			global $content_show_comments;

			if ( $content_show_comments and isset( $_POST['ajax'] ) ) {
				// If comments
				if ( comments_open() || get_comments_number() ) {
					comments_template();
				}
			} else {
				if ( comments_open() || get_comments_number() ) {
					?>
					<a href="<?php the_permalink(); ?>#comments" class="button"><?php echo $term_comments; ?></a>
				<?php
				}
			}
			?>
		</div>
	<?php } */ ?>
</div>


