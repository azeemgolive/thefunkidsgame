<?php
/**
 * @package    artless Flato
 * @author     Christian Glingener <glingener.christian@gmail.com>
 * @version    1.0.0
 * @copyright  2014 artlessthemes.com
 * @link       http://artlessthemes.com/
 */
// Audio Iframe
$audio = rwmb_meta( 'al_content_audio_embed' );
?>
<div class="blog-audio">
	<?php echo $audio; ?>
</div>