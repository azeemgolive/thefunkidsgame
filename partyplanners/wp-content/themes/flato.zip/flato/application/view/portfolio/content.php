<?php
/**
 * @package    artless Flato
 * @author     Christian Glingener <glingener.christian@gmail.com>
 * @version    1.0.0
 * @copyright  2014 artlessthemes.com
 * @link       http://artlessthemes.com/
 */

global $al_theme_options;

// Term - Client Name
$client_name = rwmb_meta( 'al_pf_client' );
$term_client = $al_theme_options->getOption( 'al_portfolio_term_client' )
	? $al_theme_options->getOption( 'al_portfolio_term_client' ) : 'CLIENT / <i>[client-name]</i>';

// Term - View Project
$term_view_project = $al_theme_options->getOption( 'al_portfolio_term_view_project' )
	? $al_theme_options->getOption( 'al_portfolio_term_view_project' ) : 'View Project';


// Link
$portfolio_link = rwmb_meta( 'al_pf_link' );

if ( $portfolio_link ) {
	if ( $portfolio_link == 'http://' ) {
		$portfolio_link = false;
	}
}

$portfolio_link_blank = false;

if( $portfolio_link ) {
    $portfolio_link_blank = rwmb_meta( 'al_pf_link_blank' );

    if( empty( $portfolio_link_blank ) ) {
        $portfolio_link_blank = false;
    } else {
        $portfolio_link_blank = true;
    }
}

?>
<div class="wrapper">
	<?php
	if ( ! isset( $_POST['ajax'] ) ) {

		// Sidebar
		$sidebar = $al_theme_options->getOption( 'al_blog_sidebar' );
		$sidebar = ( $sidebar == 'none' ) ? false : $sidebar;
		?>
		<div class="row gutters">
			<?php if ( is_active_sidebar( 'al-sidebar-right' ) and $sidebar ) { ?>

				<?php if ( $sidebar == 'right' ) { ?>
					<div class="col span_8">
						<div class="row gutters">
							<?php if ( rwmb_meta( 'al_pf_show_title' ) ) { ?>
								<h3><?php echo ( rwmb_meta( 'al_pf_title' ) ) ? rwmb_meta( 'al_pf_title' ) : get_the_title(); ?></h3>
							<?php } ?>

							<?php
							if ( $client_name ) {
								$term_client = str_replace( '[client-name]', $client_name, $term_client );
								?>
								<span class="client"><?php echo $term_client; ?></span>
							<?php } ?>


                            <div class="content">
                                <?php the_content(); ?>
                            </div>
                            <?php
							if ( $portfolio_link ) {
								?>
								<a class="button"<?php if( $portfolio_link_blank ) { echo ' target="_blank"'; } ?>  href="<?php echo $portfolio_link; ?>"><?php echo $term_view_project; ?></a>
							<?php } ?>
						</div>
					</div>

					<div class="col span_4 last">
						<div class="row gutters">
							<?php get_sidebar(); ?>
						</div>
					</div>

				<?php } else { ?>

					<div class="col span_4">
						<div class="row gutters">
							<?php get_sidebar(); ?>
						</div>
					</div>

					<div class="col span_8 last">
						<div class="row gutters">
							<?php if ( rwmb_meta( 'al_pf_show_title' ) ) { ?>
								<h3><?php echo ( rwmb_meta( 'al_pf_title' ) ) ? rwmb_meta( 'al_pf_title' ) : get_the_title(); ?></h3>
							<?php } ?>

							<?php
							if ( $client_name ) {
								$term_client = str_replace( '[client-name]', $client_name, $term_client );
								?>
								<span class="client"><?php echo $term_client; ?></span>
							<?php } ?>


                            <div class="content">
                                <?php the_content(); ?>
                            </div>
                            <?php

							if ( $portfolio_link ) {
								?>
								<a class="button"<?php if( $portfolio_link_blank ) { echo ' target="_blank"'; } ?>  href="<?php echo $portfolio_link; ?>"><?php echo $term_view_project; ?></a>
							<?php
							}

							if ( comments_open() || get_comments_number() ) {
								comments_template();
							}
							?>
						</div>
					</div>
				<?php } ?>
			<?php
			} else {
				?>
				<?php if ( rwmb_meta( 'al_pf_show_title' ) ) { ?>
					<h4><?php echo ( rwmb_meta( 'al_pf_title' ) ) ? rwmb_meta( 'al_pf_title' ) : get_the_title(); ?></h4>
				<?php } ?>

				<?php
				if ( $client_name ) {
					$term_client = str_replace( '[client-name]', $client_name, $term_client );
					?>
					<span class="client"><?php echo $term_client; ?></span>
				<?php } ?>


                <div class="content">
                    <?php the_content(); ?>
                </div>
                <?php
				if ( $portfolio_link ) {
					?>
					<a class="button"<?php if( $portfolio_link_blank ) { echo ' target="_blank"'; } ?> href="<?php echo $portfolio_link; ?>"><?php echo $term_view_project; ?></a>
				<?php
				}

				if ( comments_open() || get_comments_number() ) {
					comments_template();
				}
			}
			?>
		</div>

	<?php } else { ?>
		<div class="row gutters">
			<?php if ( rwmb_meta( 'al_pf_show_title' ) ) { ?>
				<h4><?php echo ( rwmb_meta( 'al_pf_title' ) ) ? rwmb_meta( 'al_pf_title' ) : get_the_title(); ?></h4>
			<?php } ?>

			<?php
			if ( $client_name ) {
				$term_client = str_replace( '[client-name]', $client_name, $term_client );
				?>
				<span class="client"><?php echo $term_client; ?></span>
			<?php } ?>


            <div class="content">
                <?php the_content(); ?>
            </div>
            <?php

			if ( $portfolio_link ) {
				?>
				<a class="button"<?php if( $portfolio_link_blank ) { echo ' target="_blank"'; } ?>  href="<?php echo $portfolio_link; ?>"><?php echo $term_view_project; ?></a>
			<?php
			}

			if ( comments_open() || get_comments_number() ) {
				comments_template();
			} ?>
		</div>
	<?php } ?>
</div>


