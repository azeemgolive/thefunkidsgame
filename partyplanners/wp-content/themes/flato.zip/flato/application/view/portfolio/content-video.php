<?php
/**
 * @package    artless Flato
 * @author     Christian Glingener <glingener.christian@gmail.com>
 * @version    1.0.0
 * @copyright  2014 artlessthemes.com
 * @link       http://artlessthemes.com/
 */
// Video Iframe
$video = rwmb_meta( 'al_pf_video_embed' );

if ( preg_match( '#youtube\.com\/watch\?v\=([^\"]{1,30})#', $video, $result ) ) {
    $video = '<iframe scrolling="no" frameborder="no" src="//www.youtube.com/embed/' . $result[1] . '" allowfullscreen></iframe>';
} elseif ( preg_match( '#youtu\.be\/([^\"]{1,30})#', $video, $result ) ) {
    $video = '<iframe scrolling="no" frameborder="no" src="//www.youtube.com/embed/' . $result[1] . '" allowfullscreen></iframe>';
}

?>
<div class="blog-video">
	<?php echo $video; ?>
</div>