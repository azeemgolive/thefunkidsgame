<?php
/**
 * @package    artless Flato
 * @author     Christian Glingener <glingener.christian@gmail.com>
 * @version    1.0.0
 * @copyright  2014 artlessthemes.com
 * @link       http://artlessthemes.com/
 */

// Gallery Images
$images = rwmb_meta( 'al_pf_gallery_images', 'type=image&size=al-gallery' );

if ( is_array( $images ) ) {
	global $al_theme_options;

	// Lazy Load
	$lazy_load = ( $al_theme_options->getOption( 'al_slider_lazyload' ) ) ? true : false;
	?>
	<div class="al-pf-slider">
		<?php
		if( $lazy_load ) {
			foreach ( $images as $image ) { ?>
				<div><img class="lazyOwl" data-src="<?php echo $image['url']; ?>" alt="<?php echo $image['alt']; ?>" /></div>
			<?php }
		} else {
			foreach ( $images as $image ) { ?>
				<div><img src="<?php echo $image['url']; ?>" alt="<?php echo $image['alt']; ?>" /></div>
			<?php }
		} ?>
	</div>
<?php } ?>


