<?php
/**
 * @package    artless Flato
 * @author     Christian Glingener <glingener.christian@gmail.com>
 * @version    1.0.0
 * @copyright  2014 artlessthemes.com
 * @link       http://artlessthemes.com/
 */

global $al_theme_options;

?>
<div class="wrapper">
    <?php
    // Sidebar
    $sidebar = $al_theme_options->getOption( 'al_blog_sidebar' );
    $sidebar = ( $sidebar == 'none' or $sidebar == 1 ) ? false : $sidebar;

    ?>
    <div class="row gutters">
        <?php if ( is_active_sidebar( 'al-sidebar-right' ) and $sidebar ) { ?>

            <?php if ( $sidebar == 'right' ) { ?>
                <div class="col span_8">
                    <div class="row gutters">
                        <?php while ( have_posts() ) { the_post(); ?>
                        <h4><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>

                        <div class="content">
                            <?php the_excerpt(); ?>
                        </div>
                        <?php } ?>
                    </div>
                </div>

                <div class="col span_4 last">
                    <div class="row gutters">
                        <?php get_sidebar(); ?>
                    </div>
                </div>

            <?php } else { ?>

                <div class="col span_4">
                    <div class="row gutters">
                        <?php get_sidebar(); ?>
                    </div>
                </div>

                <div class="col span_8 last">
                    <div class="row gutters">
                        <?php while ( have_posts() ) { the_post(); ?>
                            <h4><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>

                            <div class="content">
                                <?php the_excerpt(); ?>
                            </div>
                        <?php } ?>
                    </div>
                </div>
            <?php } ?>
        <?php
        } else {
            while ( have_posts() ) { the_post(); ?>
                <h4><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>

                <div class="content">
                    <?php the_excerpt(); ?>
                </div>
            <?php }
        }
        ?>
    </div>
</div>
