<?php
/**
 * @package    artless Flato
 * @author     Christian Glingener <glingener.christian@gmail.com>
 * @version    1.0.0
 * @copyright  2014 artlessthemes.com
 * @link       http://artlessthemes.com/
 */

/**
 * Meta & Options
 */
global $al_theme_options;

// Number of Projects
$al_pf_posts_number = $al_theme_options->getOption( 'al_portfolio_posts' );

if ( ! isset( $paged ) ) {
	$paged = ( get_query_var( 'paged' ) ) ? intval( get_query_var( 'paged' ) ) : 1;
}

$portfolio = new WP_Query( array(
	'post_type'      => 'portfolio',
	'posts_per_page' => $al_pf_posts_number,
	'orderby'        => 'menu_order date',
	'order'          => 'DESC',
	'paged'          => $paged
) );

if ( $portfolio->have_posts() ) {
	while ( $portfolio->have_posts() ) {

		$portfolio->the_post();
		$post_format = get_post_format();

		$image = false;

		if ( has_post_thumbnail() ) {
			$image = wp_get_attachment_image( get_post_thumbnail_id(), 'al-pf-preview' );

		} else {

			switch ( $post_format ) {
				case 'gallery':
					$images = rwmb_meta( 'al_pf_gallery_images', 'type=image' );

					// Get First Image
					$image = reset( $images );

					if ( ! empty( $image ) ) {
						$image = wp_get_attachment_image( $image['ID'], 'al-pf-preview' );
					} else {
						$image = false;
					}

					break;
				case 'audio':
					$image = rwmb_meta( 'al_pf_audio_embed' );

					if ( preg_match( '#soundcloud\.com\/tracks\/([0-9]{1,20})#', $image, $result ) ) {

						$image = '<iframe align="center" width="100%" height="467" scrolling="no" frameborder="no" data-after-preload-src="https://w.soundcloud.com/player/?url=https%3A//api.soundcloud.com/tracks/' . $result[1] . '&auto_play=false&hide_related=false&visual=true"></iframe>';
					}
					break;

				case 'video':
					$image = rwmb_meta( 'al_pf_video_embed' );

					if ( preg_match( '#src=\"([^\"]{1,500})\"#', $image, $result ) ) {

						$image = '<iframe width="100%" height="467" scrolling="no" frameborder="no" data-after-preload-src="' . $result[1] . '"></iframe>';
					} else {
						if ( preg_match( '#youtube\.com\/watch\?v\=([^\"]{1,30})#', $image, $result ) ) {
							$image = '<iframe width="100%" height="467" scrolling="no" frameborder="no" data-after-preload-src="//www.youtube.com/embed/' . $result[1] . '"></iframe>';
						}
					}
					break;
			}
		}

		$client_name = rwmb_meta( 'al_pf_client' );
		$term_client = $al_theme_options->getOption( 'al_portfolio_term_client' )
			? $al_theme_options->getOption( 'al_portfolio_term_client' ) : 'CLIENT / <i>[client-name]</i>';

		$post_terms = get_the_terms( get_the_ID(), 'portfolio_categories' );
		?>

		<li class="al-pf-mix<?php if ( $post_terms ) {
			foreach ( $post_terms as $term ) {
				echo ' ' . $term->slug;
			}
		} ?>">
			<a data-load="<?php the_permalink(); ?>">
				<?php if ( $image ) {
					echo $image;
				} else {
					echo '<div class="al-pf-empty-preview"></div>';
				} ?>
				<div class="layer">
					<?php if ( rwmb_meta( 'al_pf_show_title' ) ) { ?>
						<h4 class="underline"><?php echo ( rwmb_meta( 'al_pf_title' ) ) ? rwmb_meta( 'al_pf_title' ) : get_the_title(); ?></h4>
					<?php } ?>
					<?php if ( $client_name ) {
						$term_client = str_replace( '[client-name]', $client_name, $term_client );
						?>
						<span class="client"><?php echo $term_client; ?></span>
					<?php } ?>
				</div>
			</a>
		</li>
	<?php } ?>
<?php
}
