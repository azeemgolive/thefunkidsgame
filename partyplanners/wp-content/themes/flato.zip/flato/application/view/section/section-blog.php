<?php
/**
 * @package    artless Flato
 * @author     Christian Glingener <glingener.christian@gmail.com>
 * @version    1.0.0
 * @copyright  2014 artlessthemes.com
 * @link       http://artlessthemes.com/
 */

/**
 * Meta & Options
 */
global $al_meta;
global $al_theme_options;

$standalone = get_post_meta( get_the_ID(), "al_standalone", TRUE );
$sidebar = rwmb_meta( 'al_sidebar' );
$sidebar = ( $sidebar == 'none' or !$standalone or !is_active_sidebar( 'al-sidebar-right' ) ) ? false : $sidebar;

// Filter
$al_blog_filter = $al_theme_options->getOption( 'al_blog_filter' );

// Load More
$al_blog_load_more = $al_theme_options->getOption( 'al_blog_load_more' );

// PreLoader
if ( ! isset( $al_preloader ) ) {
	$al_preloader = ( $al_theme_options->getOption( 'al_style_preloader', 'url' ) )
		? $al_theme_options->getOption( 'al_style_preloader', 'url' )
		: AL_PUBLIC . '/img/color_loader.gif';
}


$paged = ( get_query_var( 'paged' ) ) ? intval( get_query_var( 'paged' ) ) : 1;

$blog = new WP_Query( array(
	'post_type' 	 => 'post',
	'posts_per_page' => get_option( 'posts_per_page' ),
	'orderby'   	 => 'menu_order date',
	'paged'     	 => $paged
) );

$blog_terms = get_terms( 'category', array( 'orderby' => 'slug' ) );

$al_blog_load_more_active = ( $al_blog_load_more and $blog->max_num_pages > 1 ) ? true : false;

// Background
$banner_style = '';

if ( has_post_thumbnail() ) {
	$bg_image     = wp_get_attachment_image_src( get_post_thumbnail_id(), 'al-parallax' );
	$bg_image_src = $bg_image[0];

	if( !$al_blog_load_more_active ) {
		$banner_style = ' style="background-image: url(\'' . $bg_image_src . '\'); margin-bottom: 0; padding-bottom: 80px;"';
	} else {
		$banner_style = ' style="background-image: url(\'' . $bg_image_src . '\');"';
	}

}
?>

<section id="<?php echo $al_meta['section-anchor']; ?>" <?php if ( ! $al_blog_load_more_active ) {
	echo 'class="margin-bottom"';
} ?><?php echo $banner_style; ?>>

	<?php

	if ( $blog_terms and $al_blog_filter ) {
		get_template_part( AL_TEMPLATE_PARTS , 'headline-no-margin' );
	} else {
		get_template_part( AL_TEMPLATE_PARTS , 'headline' );
	} ?>

	<div id="al-blog-wrapper">
		<div class="close">
			<a id="close-blog-wrapper"></a>
		</div>
		<div id="al-blog-loader"><img class="al-loader-img" src="<?php echo $al_preloader; ?>" alt="" /></div>

		<div id="al-blog-load-content">
			<!-- Blog Details load here -->
		</div>
	</div>

	<?php
	if( $sidebar ) { ?>
		<div class="row gutters margin-top">
		<?php
		if( $sidebar == 'right' ) { ?>
			<div class="col span_8">
		<?php
		} else { ?>
			<div class="col span_4">
				<div class="row gutters">
					<?php get_sidebar(); ?>
				</div>
			</div>

			<div class="col span_8 last">
		<?php
	   	}
	}
		?>

		<?php if ( get_the_content() ) { ?>
			<div class="row gutters">
				<div class="content">
					<?php the_content(); ?>
				</div>
			</div>
		<?php } ?>

		<?php if ( $blog->have_posts() ) { ?>

			<?php if ( $blog_terms and $al_blog_filter ) {
				$term_all_categories = $al_theme_options->getOption( 'al_blog_term_filter_all' )
					? $al_theme_options->getOption( 'al_blog_term_filter_all' ) : 'All';
				?>

				<div class="row">
					<ul id="al-blog-tabs" class="al-tabs">
						<li class="al-blog-filter active" data-filter="all">
							<a><?php echo $term_all_categories; ?></a>
						</li>

						<?php
						foreach ( $blog_terms as $category ) {
							if ( $category->term_id != 1 ) {
								?>
								<li class="al-blog-filter" data-filter="<?php echo $category->slug; ?>">
									<a><?php echo $category->name; ?></a>
								</li>
							<?php
							}
						}
						?>
					</ul>
				</div>
			<?php } ?>

			<div class="row gutters">
				<ul id="al-blog-preview"<?php if ( ! $al_blog_filter ) {
					echo ' class="margin-top"';
				} ?>>
					<?php get_template_part( AL_TEMPLATE_SECTION, 'blog-preview-single' ); ?>
				</ul>

				<div class="clear"></div>

				<?php
				/**
				 * LOAD MORE
				 */
				if ( $al_blog_load_more_active ) {

					$paged ++;

					$pages = array();
					for ( $i = $paged; $i <= $blog->max_num_pages; $i ++ ) {
						$pages[] = '"' . $i . '"';
					}

					$json_pages = '[' . implode( ',', $pages ) . ']';

					$term_load_more = $al_theme_options->getOption( 'al_blog_term_load_more' )
						? $al_theme_options->getOption( 'al_blog_term_load_more' ) : 'Load More'; ?>

					<div class="load-more-button">
						<img id="al-blog-load-more-loader" class="al-loader-img" src="<?php echo $al_preloader; ?>" />
						<a id="al-blog-button-load-more" name="al-blog-load-more" class="button border" data-post-paged='<?php echo $json_pages; ?>'><?php echo $term_load_more; ?></a>
					</div>
				<?php
				} // Load More
				?>
			</div>
		<?php
		} // have posts

	if( $sidebar ) {
		if( $sidebar == 'right' ) { ?>
			</div>

			<div class="col span_4 last">
				<div class="row gutters">
					<?php get_sidebar(); ?>
				</div>
			</div>
		<?php
		} else { ?>
			</div>
		<?php
		} ?>
		</div>
	<?php
	} ?>

</section>
