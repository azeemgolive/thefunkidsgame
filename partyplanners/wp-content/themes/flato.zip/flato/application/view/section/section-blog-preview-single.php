<?php
/**
 * @package    artless Flato
 * @author     Christian Glingener <glingener.christian@gmail.com>
 * @version    1.0.0
 * @copyright  2014 artlessthemes.com
 * @link       http://artlessthemes.com/
 */

global $al_theme_options;

if ( ! isset( $_POST['post-paged'] ) ) {
	$paged = ( get_query_var( 'paged' ) ) ? intval( get_query_var( 'paged' ) ) : 1;
} else {
	$paged = $_POST['post-paged'];
    $filter = $_POST['post-filter'];
    $filter_value = $_POST['post-filter-value'];
}

if( is_archive() ) {

    while( have_posts() ) {
        the_post();

        showBlogPreviewSingle();
    }

} else {
    $args = array(
        'post_type' 	 => 'post',
        'posts_per_page' => get_option( 'posts_per_page' ),
        'orderby'   	 => 'menu_order date',
        'paged'     	 => $paged
    );

    if( isset( $filter ) and !empty( $filter ) and isset( $filter_value ) and !empty( $filter_value ) ) {
        $args[$filter] = $filter_value;
    }


    $blog = new WP_Query( $args );

    while ( $blog->have_posts() ) {
        $blog->the_post();

        showBlogPreviewSingle();
    }
}


function showBlogPreviewSingle() {
    global $al_theme_options;
    $post_format = get_post_format();

    $thumbnail       = null;
    $thumbnail_dummy = '<img class="prev-img" src="' . AL_PUBLIC . '/img/blog-dummy.jpg" />';

    // Post Thumbnail
    $image = wp_get_attachment_image_src( get_post_thumbnail_id(), 'al-blog-preview' );
    $true_thumbnail = get_the_post_thumbnail();

    // Has no Thumbnail
    if ( ! $image ) {
	    global $post;
        switch ( $post_format ) {
            case 'gallery':
                // our gallery upload
                $images = rwmb_meta( 'al_content_gallery_images', 'type=image' );
                $image  = reset( $images );

                if ( ! empty( $image ) ) {
                    $image = wp_get_attachment_image_src( $image['ID'], 'al-blog-preview' );
                    $image = '<img class="prev-img" src="' . $image[0] . '" />';
                    break;
                } else {
                    $image = false;
                }

                // default wordpress gallery
                if( ! $image and has_shortcode( $post->post_content, 'gallery' ) ) {

                    $images = get_post_gallery( $post, false );
                    $image = reset( explode( ',', $images['ids'] ) );

                    if ( ! empty( $image ) ) {
                        $image = '<img class="prev-img" src="' . wp_get_attachment_url( $image ) . '" />';
                        break;
                    } else {
                        $image = false;
                    }
                }

                break;
            case 'audio':
                $image = rwmb_meta( 'al_content_audio_embed' );

                if ( preg_match( '#soundcloud\.com\/tracks\/([0-9]{1,20})#', $image, $result ) ) {

                    $image = '<iframe width="100%" height="366" scrolling="no" frameborder="no" data-after-preload-src="https://w.soundcloud.com/player/?url=https%3A//api.soundcloud.com/tracks/' . $result[1] . '&auto_play=false&hide_related=false&visual=true"></iframe>';
                } else {
                    $image = false;
                }
                break;

            case 'image':
                if ( preg_match( '#src=\"([^\"]{1,500})\"#', get_the_content(), $result ) ) {
                    $image = '<img class="prev-img" src="' . $result[1] . '" />';
                }
                break;

            case 'video':
                $image = rwmb_meta( 'al_content_video_embed' );

                if ( preg_match( '#src=\"([^\"]{1,500})\"#', $image, $result ) ) {
                    $image = '<iframe width="100%" height="366" scrolling="no" frameborder="no" data-after-preload-src="' . $result[1] . '"></iframe>';
                } elseif ( preg_match( '#youtube\.com\/watch\?v\=([^\"]{1,30})#', $image, $result ) ) {
                    $image = '<iframe width="100%" height="366" scrolling="no" frameborder="no" data-after-preload-src="//www.youtube.com/embed/' . $result[1] . '"></iframe>';
                } elseif ( preg_match( '#youtube\.com\/watch\?v\=([^\s\"]{1,30})#', get_the_content(), $result ) ) {
                    $image = '<iframe width="100%" height="366" scrolling="no" frameborder="no" data-after-preload-src="//www.youtube.com/embed/' . $result[1] . '"></iframe>';
                } else {
                    $image = false;
                }
                break;
        }
    } else {
        $image = '<img class="prev-img" src="' . $image[0] . '" />';
    }

    // Term - Show Article
    $term_show_article = $al_theme_options->getOption( 'al_blog_term_show_article' )
        ? $al_theme_options->getOption( 'al_blog_term_show_article' ) : 'Show Article';

    // Term - Categories
    $categories     = get_the_category();
    $categories_str = '';

    if( is_array( $categories ) ) {
        foreach ( $categories as $category ) {
            if ( $category->term_id != 1 ) {
                $categories_str .= '<a href="'.get_category_link( $category->term_id ).'" title="' . esc_attr( sprintf( __( "View all posts in %s", 'artless' ), $category->name ) ) . '">' . $category->name . '</a>, ';
            }
        }
        $categories_str = rtrim( $categories_str, ', ' );
    }

    $term_category = $al_theme_options->getOption( 'al_blog_term_category' )
        ? $al_theme_options->getOption( 'al_blog_term_category' ) : 'CATEGORY / <i>[category-name]</i>';

    if ( preg_match( '#\[category-name\]#', $term_category ) ) {
        if ( $categories_str != '' ) {
            $term_category = str_replace( '[category-name]', $categories_str, $term_category );
        } else {
            $term_category = false;
        }
    }

    // Term - Tags
    $tags     = get_the_tags();
    $tags_str = '';

    if( is_array( $tags ) ) {
        foreach ( $tags as $tag ) {
            $tags_str .= '<a href="'.get_tag_link( $tag->term_id ).'" title="' . esc_attr( sprintf( __( "View all posts tagged with %s", 'artless' ), $tag->name ) ) . '">' . $tag->name . '</a>, ';
        }
        $tags_str = rtrim( $tags_str, ', ' );
    }

    $term_tags = $al_theme_options->getOption( 'al_blog_term_tags' )
        ? $al_theme_options->getOption( 'al_blog_term_tags' ) : 'TAGS / <i>[tags]</i>';

    if ( preg_match( '#\[tags\]#', $term_tags ) ) {
        if ( $tags_str != '' ) {
            $term_tags = str_replace( '[tags]', $tags_str, $term_tags );
        } else {
            $term_tags = false;
        }
    }

    // Term - Author
    $term_author = $al_theme_options->getOption( 'al_blog_term_author' )
        ? $al_theme_options->getOption( 'al_blog_term_author' ) : 'AUTHOR / <i>[author-name]</i>';

    $term_author = str_replace( '[author-name]', '<a href="'. get_author_posts_url( get_the_author_meta( 'ID' ) ) . '">' . get_the_author_meta( 'display_name' ) . '</a>', $term_author );

    // Term - Date
    $term_date = $al_theme_options->getOption( 'al_blog_term_date' )
        ? $al_theme_options->getOption( 'al_blog_term_date' ) : 'DATE / <i>[date]</i>';

    $term_date = str_replace( '[date]', '<a href="'. get_day_link( get_post_time( 'Y' ), get_post_time( 'm' ), get_post_time( 'j' ) ).'">' . get_the_date() . '</a>', $term_date );

    // css class
    $post_class = 'al-blog-mix';
    if ( $categories ) {
        foreach ( $categories as $term ) {
            $post_class .= ' ' . $term->slug;
        }
    }
    ?>
    <li <?php post_class( $post_class ); ?>>
        <div class="layer">
            <a data-load="<?php the_permalink(); ?>" class="button"><?php echo $term_show_article; ?></a>
        </div>
        <?php if ( $image ) {
            echo $image;
        } else { ?>
            <div class="al-blog-empty-preview">
                <?php
                switch( $post_format ) {
                    case 'aside':
                    case 'status':
                        echo '<div class="aside al-vertical-mid-to-parent"><p class="no-margin">' . get_the_content() . '</p></div>';
                        break;
                }
                ?>
            </div>
        <?php } ?>
        <div class="text al-vertical-mid-to-parent">
            <?php if( get_the_title() ) { the_title( '<h4 class="underline">', '</h4>' ); } ?>
            <?php if ( $term_category ) { ?>
                <span class="detail"><?php echo $term_category; ?></span>
            <?php } ?>
            <?php if ( $term_tags ) { ?>
                <span class="detail"><?php echo $term_tags; ?></span>
            <?php } ?>
            <span class="detail"><?php echo $term_author; ?></span>
            <span class="detail"><?php echo $term_date; ?></span>
        </div>
        <div class="clear"></div>
    </li>
<?php
}
?>

