<?php
/**
 * @package    artless Flato
 * @author     Christian Glingener <glingener.christian@gmail.com>
 * @version    1.0.0
 * @copyright  2014 artlessthemes.com
 * @link       http://artlessthemes.com/
 */

/**
 * Meta & Options
 */
global $al_meta;
global $al_theme_options;

$video = get_post_meta( get_the_ID(), 'al_video_links', TRUE );
$video_size = get_post_meta( get_the_ID(), 'al_video_size', TRUE );
$video_urls = array();
$video_style = '';
$video_home = '';
$home = false;
$home_logo = false;

// Jumping Circle
$al_home_jumper = $al_theme_options->getOption( 'al_home_show_jumper' );

if( $video_size == 'fullwidth' ) {
	$video_min_height = get_post_meta( get_the_ID(), 'al_video_min_height', TRUE );

	if( isset( $video_min_height ) and ! empty( $video_min_height ) ) {
		$video_style = ' style="min-height:'.$video_min_height.';"';
	}
} elseif( $video_size == 'fullscreen-home' ) {
	$video_size = 'fullscreen';
	$video_home = ' al-home-banner';
	$home = true;

	// Check if Logo should be shown and Logo is set
	if ( $al_theme_options->getOption( 'al_home_show_logo' ) and
		$al_theme_options->getOption( 'al_general_logo', 'url', true )
	) {

		$home_logo = $al_theme_options->getOption( 'al_general_logo', 'url' );

		$logo_width  = $al_theme_options->getOption( 'al_home_logo_width' );
		$logo_height = $al_theme_options->getOption( 'al_home_logo_height' );

		$logo_attributes = '';
		$logo_attributes .= ( $logo_width ) ? ' width="' . $logo_width . '"' : '';
		$logo_attributes .= ( $logo_height ) ? ' height="' . $logo_height . '"' : '';
	}
}

if( ! empty( $video ) ) {

	$urls = preg_split( '#\r\n|[\r\n]#', $video );
	$youtube = true;

	foreach( $urls as $url ) {
		if( $youtube ) {
			if ( preg_match( '#(?:youtube(?:-nocookie)?\.com/(?:[^/]+/.+/|(?:v|e(?:mbed)?)/|.*[?&]v=)|youtu\.be/)([^"&?/ ]{11})#i', $url, $match ) ) {
				$youtube = $match[1];
			} else {
				$youtube = false;
			}
		}

		if( ! $youtube ) {
			if( strpos( $url, '.mp4' ) ) {
				$video_urls[3]['type'] = 'video/mp4';
				$video_urls[3]['url'] = $url;
			} else if( strpos( $url, '.ogg' ) ) {
				$video_urls[2]['type'] = 'video/ogg';
				$video_urls[2]['url'] = $url;
			} else if( strpos( $url, '.ogv' ) ) {
				$video_urls[2]['type'] = 'video/ogg';
				$video_urls[2]['url'] = $url;
			} else if( strpos( $url, '.webm' ) ) {
				$video_urls[1]['type'] = 'video/webm';
				$video_urls[1]['url'] = $url;
			}
		}
	}
} else {
	$video = false;
	$youtube = false;
}

// Background
$banner_style = '';
$video_poster = '';
if ( has_post_thumbnail() ) {
	$bg_image     = wp_get_attachment_image_src( get_post_thumbnail_id(), 'full' );
	$bg_image_src = $bg_image[0];

    $video_poster = ' poster="'.$bg_image_src.'"';
	$banner_style = ' style="background-image: url(\'' . $bg_image_src . '\');"';
}
?>

<section id="<?php echo $al_meta['section-anchor']; ?>" class="al-video-background section<?php echo $video_home;?>"<?php echo $banner_style;?>>

	<?php
	// Headline
	if( !$home ) {
		get_template_part( AL_TEMPLATE_PARTS , 'headline-no-margin' );
	}
	?>
		<div id="al-video-<?php the_ID(); ?>" class="al-video-<?php echo $video_size;?>"<?php echo $video_style;?>>

			<?php if( $home ) { ?>
			<div class="al-home-container">
				<?php if ( $home_logo ) { ?>
					<a class="al-logo" href="<?php echo site_url(); ?>">
						<img src="<?php echo $home_logo; ?>"<?php echo $logo_attributes; ?> />
					</a>
				<?php } ?>

				<?php if ( $al_meta['show-title'] ) { ?>
					<h1><?php echo $al_meta['title'] ? $al_meta['title'] : get_the_title(); ?></h1>
				<?php } ?>

				<?php if ( $al_meta['subtitle'] ) { ?>
					<span class="subheadline">
                <?php echo do_shortcode( $al_meta['subtitle'] ); ?>
            </span>
				<?php } ?>

			<?php } ?>

			<div  class="row<?php if( $home ) { ?> al-home-content<?php } ?>" style="z-index: 100;">
				<div class="content">
					<?php the_content(); ?>
				</div>
			</div>
			<?php if( $home ) { ?></div> <?php } ?>

			<?php if( AL_DEVICE == 'computer' ) { ?>
				<?php if( $video and ! empty( $video_urls ) ) {	?>
					<video<?php echo $video_poster;?> autoplay loop muted>
						<?php foreach( $video_urls as $video ) { ?>
						<source src="<?php echo $video['url'];?>" type="<?php echo $video['type'];?>">
						<?php } ?>
					</video>
				<?php }	?>
			<?php } ?>
			<?php if ( $home and $al_home_jumper ) { ?>
				<div class="scroll-down">
					<a class="scrollto" name="to-next-section"></a>
				</div>
			<?php } ?>
		</div>


</section>
<?php if( $youtube and empty( $video_urls ) and AL_DEVICE == 'computer' ) {
wp_enqueue_script( 'jquery.tubular' );
?>
<script type="text/javascript">
	( function( $ ) {
		$( window ).load(function() {
			var options = { videoId: '<?php echo $youtube; ?>' };
			$( '#al-video-<?php the_ID(); ?>' ).tubular(options);
		});
	} )( jQuery );
</script>
<?php } ?>