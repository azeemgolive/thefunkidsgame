<?php
/**
 * @package    artless Flato
 * @author     Christian Glingener <glingener.christian@gmail.com>
 * @version    1.0.0
 * @copyright  2014 artlessthemes.com
 * @link       http://artlessthemes.com/
 */

/**
 * Meta & Options
 */
global $al_meta;
global $al_theme_options;

// Filter
$al_blog_filter = $al_theme_options->getOption( 'al_blog_filter' );

// Load More
$al_blog_load_more = $al_theme_options->getOption( 'al_blog_load_more' );

$al_blog_load_more_active = ( $al_blog_load_more and $GLOBALS['wp_query']->max_num_pages > 1 ) ? true : false;

$blog_terms = get_terms( 'category', array( 'orderby' => 'slug' ) );

// PreLoader
if ( ! isset( $al_preloader ) ) {
	$al_preloader = ( $al_theme_options->getOption( 'al_style_preloader', 'url' ) )
		? $al_theme_options->getOption( 'al_style_preloader', 'url' )
		: AL_PUBLIC . '/img/color_loader.gif';
}

$page_for_posts = get_option( 'page_for_posts' ) ? get_option( 'page_for_posts' ) : false;
if( $page_for_posts ) {
	$title = get_the_title( $page_for_posts );
} else {
	$title = get_bloginfo( 'name' );
}
?>

<section id="<?php echo $al_meta['section-anchor']; ?>" <?php if ( ! $al_blog_load_more_active ) {
	echo 'class="margin-bottom"';
} ?>>
	<div class="headline-wrapper">
		<div class="row">
			<h1 class="underline"><?php if( is_category() ) {
					_e( 'Category: ', 'artless' ); single_cat_title();
				} elseif( is_tag() ) {
					_e( 'Tag: ', 'artless' ); single_tag_title();
				} elseif( is_author() ) {
					_e( 'Author: ', 'artless' ); the_author();
				} elseif (is_day()) {
					the_time( 'F jS, Y' );
				} elseif (is_month()) {
					the_time(' F, Y' );
				} elseif (is_year()) {
					the_time( 'Y' );
				} else { echo $title; } ?></h1>
		</div>
	</div>

	<?php if ( have_posts() ) { ?>
		<div id="al-blog-wrapper">
			<div class="close">
				<a id="close-blog-wrapper"></a>
			</div>
			<div id="al-blog-loader"><img class="al-loader-img" src="<?php echo $al_preloader; ?>" /></div>

			<div id="al-blog-load-content">
				<!-- Blog Details load here -->
			</div>
		</div>

		<?php if ( $blog_terms and $al_blog_filter and !is_archive() ) {
			$term_all_categories = $al_theme_options->getOption( 'al_blog_term_filter_all' )
				? $al_theme_options->getOption( 'al_blog_term_filter_all' ) : 'All';
			?>

			<div class="row">
				<ul id="al-blog-tabs" class="al-tabs">
					<li class="al-blog-filter active" data-filter="all">
						<a><?php echo $term_all_categories; ?></a>
					</li>

					<?php
					foreach ( $blog_terms as $category ) {
						if ( $category->term_id != 1 ) {
							?>
							<li class="al-blog-filter" data-filter="<?php echo $category->slug; ?>">
								<a><?php echo $category->name; ?></a>
							</li>
						<?php
						}
					}
					?>
				</ul>
			</div>
		<?php } ?>

		<div class="row gutters">
			<ul id="al-blog-preview"<?php if ( ! $al_blog_filter ) {
				echo ' class="margin-top"';
			} ?>>
				<?php get_template_part( AL_TEMPLATE_SECTION, 'blog-preview-single' ); ?>
			</ul>


		<?php
		/**
		 * LOAD MORE
		 */
		if ( $al_blog_load_more_active ) {

            $paged = ( get_query_var( 'paged' ) ) ? intval( get_query_var( 'paged' ) ) : 1;
            $paged ++;

            $pages = array();
            for ( $i = $paged; $i <= $GLOBALS['wp_query']->max_num_pages; $i ++ ) {
                $pages[] = '"' . $i . '"';
            }

            $filter = false;
            $filter_value = '';

            if (is_author()) {

            }

            if (is_category()) {

                $category_ids = wp_get_post_categories( get_the_ID(), array( 'fields' => 'ids' ) );
                $filter = ' data-post-filter="category_name"';

                $cat = get_category( get_query_var( 'cat' ) );
                $filter_value = ' data-post-filter-value="'.$cat->slug.'"';
            }

            if( is_tag() ) {

            }

            $json_pages = '[' . implode( ',', $pages ) . ']';

            $term_load_more = $al_theme_options->getOption( 'al_blog_term_load_more' )
                ? $al_theme_options->getOption( 'al_blog_term_load_more' ) : 'Load More'; ?>

            <div class="load-more-button">
                <img id="al-blog-load-more-loader" class="al-loader-img" src="<?php echo $al_preloader; ?>" />
                <a id="al-blog-button-load-more" name="al-blog-load-more" class="button border" data-post-paged='<?php echo $json_pages; ?>'<?php if( $filter ) { echo $filter.$filter_value; } ?>><?php echo $term_load_more; ?></a>
            </div>

            <?php

            /*
			$term_load_more = $al_theme_options->getOption( 'al_blog_term_load_more' )
				? $al_theme_options->getOption( 'al_blog_term_load_more' ) : 'Load More';
			?>
			<div class="load-more-button">
				<img id="al-blog-load-more-loader" class="al-loader-img" src="<?php echo $al_preloader; ?>" />
				<a id="al-blog-button-load-more" name="al-blog-load-more" class="button border"><?php echo $term_load_more; ?></a>
			</div>
			<?php
			// Pagination Links ( needed for Load More Function )
			if ( $GLOBALS['wp_query']->max_num_pages < 2 ) {
				return;
			}

			$paged = get_query_var( 'paged' ) ? intval( get_query_var( 'paged' ) ) : 1;
			$pagenum_link = html_entity_decode( get_pagenum_link() );
			$query_args = array();
			$url_parts = explode( '?', $pagenum_link );

			if ( isset( $url_parts[1] ) ) {
				wp_parse_str( $url_parts[1], $query_args );
			}

			$pagenum_link = remove_query_arg( array_keys( $query_args ), $pagenum_link );
			$pagenum_link = trailingslashit( $pagenum_link ) . '%_%';

			$format = $GLOBALS['wp_rewrite']->using_index_permalinks() && ! strpos( $pagenum_link, 'index.php' ) ? 'index.php/' : '';
			$format .= $GLOBALS['wp_rewrite']->using_permalinks() ? user_trailingslashit( 'page/%#%', 'paged' ) : '?paged=%#%';

			$links = paginate_links( array(
				'base'      => $pagenum_link,
				'format'    => $format,
				'total'     => $GLOBALS['wp_query']->max_num_pages,
				'current'   => $paged,
				'show_all'  => true,
				'add_args'  => array_map( 'urlencode', $query_args ),
				'prev_text' => __( 'Prev', 'artless' ),
				'next_text' => __( 'Next', 'artless' ),
				'type'      => 'array'
			) );

			?>
			<div id="al-blog-load-more-links">
				<?php
				foreach ( $links as $link ) :
					echo $link;
				endforeach;
				?>
			</div>
            */

		} // Load More
		?>
		</div>
	<?php
	} // have posts
	?>
</section>
