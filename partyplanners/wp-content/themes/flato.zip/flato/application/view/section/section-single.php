<?php
/**
 * @package    artless Flato
 * @author     Christian Glingener <glingener.christian@gmail.com>
 * @version    1.0.0
 * @copyright  2014 artlessthemes.com
 * @link       http://artlessthemes.com/
 */

/**
 * Meta & Options
 */
global $al_meta;
global $al_theme_options;

// Background
$banner_style = '';

if ( has_post_thumbnail() ) {
	$bg_image     = wp_get_attachment_image_src( get_post_thumbnail_id(), 'al-parallax' );
	$bg_image_src = $bg_image[0];

	$banner_style = ' style="background-image: url(\'' . $bg_image_src . '\'); margin-bottom: 0; padding-bottom: 80px;"';
}
?>

<section class="margin-bottom"<?php echo $banner_style; ?>>
	<?php
	// Headline
    get_template_part( AL_TEMPLATE_PARTS , 'headline' );
	?>

	<div class="row gutters">
		<p style="text-align:center;">This section does not work standalone. But it looks beautiful
			<a href="<?php echo site_url() . '#' . $al_meta['section-anchor']; ?>">here</a>.</p>
        <div class="content">
            <?php the_content(); ?>
        </div>
	</div>

</section>