<?php
/**
 * @package    artless Flato
 * @author     Christian Glingener <glingener.christian@gmail.com>
 * @version    1.0.0
 * @copyright  2014 artlessthemes.com
 * @link       http://artlessthemes.com/
 */

/**
 * Meta & Options
 */
global $al_meta;
global $al_theme_options;

// Jumping Circle
$al_home_jumper = $al_theme_options->getOption( 'al_home_show_jumper' );

// Logo
$al_home_logo = false;

// Check if Logo should be shown and Logo is set
if ( $al_theme_options->getOption( 'al_home_show_logo' ) and
	$al_theme_options->getOption( 'al_general_logo', 'url', true )
) {

	$al_home_logo = $al_theme_options->getOption( 'al_general_logo', 'url' );

	$logo_width  = $al_theme_options->getOption( 'al_home_logo_width' );
	$logo_height = $al_theme_options->getOption( 'al_home_logo_height' );

	$logo_attributes = '';
	$logo_attributes .= ( $logo_width ) ? ' width="' . $logo_width . '"' : '';
	$logo_attributes .= ( $logo_height ) ? ' height="' . $logo_height . '"' : '';
}

// Banner Background
$banner_style = '';

// Slider
if ( $al_theme_options->getOption( 'al_home_show_slider' ) ) {

	// slides
	$slides = $al_theme_options->getOption( 'al_home_slides' );

// Parallax Background
} else {
	if ( has_post_thumbnail() ) {
		$bg_image     = wp_get_attachment_image_src( get_post_thumbnail_id(), 'full' );
		$bg_image_src = $bg_image[0];

		$banner_style = ' style="background-image: url(\'' . $bg_image_src . '\');"';
	} else {
		$parallax_default = $al_theme_options->getOption( 'al_general_parallax_background', 'url' );

		if ( $parallax_default ) {
			$banner_style = ' style="background-image: url(\'' . $parallax_default . '\');"';
		}
	}
}

?>

<div id="home-parallax">
<section id="<?php echo $al_meta['section-anchor']; ?>" class="al-home-banner section"<?php echo $banner_style; ?>>
	<div class="al-home-container">

		<?php if ( $al_home_logo ) { ?>
			<a class="al-logo" href="<?php echo site_url(); ?>">
				<img src="<?php echo $al_home_logo; ?>"<?php echo $logo_attributes; ?> />
			</a>
		<?php } ?>

		<?php if ( $al_meta['show-title'] ) { ?>
			<h1><?php echo $al_meta['title'] ? $al_meta['title'] : get_the_title(); ?></h1>
		<?php } ?>

		<?php if ( $al_meta['subtitle'] ) { ?>
			<span class="subheadline">
                <?php echo do_shortcode( $al_meta['subtitle'] ); ?>
            </span>
		<?php } ?>

		<div class="al-home-content">
            <div class="content">
                <?php the_content(); ?>
            </div>
		</div>
	</div>

	<?php if ( $al_home_jumper ) { ?>
		<div class="scroll-down">
			<a class="scrollto" name="to-next-section"></a>
		</div>
	<?php } ?>

	<?php if ( isset( $slides ) ) { ?>
		<a class="maximage-next"></a>
		<a class="maximage-prev"></a>

		<div id="al-home-slider">

			<?php foreach ( $slides as $slide ) { ?>
				<div>
					<?php echo do_shortcode( $slide['description'] ); ?>
					<?php if( $slide['url'] ) { ?>
						<img data-href="<?php echo $slide['url'];?>" src="<?php echo $slide['image']; ?>" alt="" />
					<?php } else {  ?>
						<img src="<?php echo $slide['image']; ?>" alt="" />
					<?php } ?>
				</div>
			<?php } ?>
		</div>

	<?php } ?>

</section>
</div>
