<?php
/**
 * @package    artless Flato
 * @author     Christian Glingener <glingener.christian@gmail.com>
 * @version    1.0.0
 * @copyright  2014 artlessthemes.com
 * @link       http://artlessthemes.com/
 */
global $al_meta;
global $al_theme_options;

// Google Map API
$gmaps_api_file = AL_DIR . '/application/view/parts/google-maps-api.php';
file_exists( $gmaps_api_file ) ? require( $gmaps_api_file ) : false;


// Background
$banner_style = '';

if ( has_post_thumbnail() ) {
	$bg_image     = wp_get_attachment_image_src( get_post_thumbnail_id(), 'al-parallax' );
	$bg_image_src = $bg_image[0];

	if ( ! $gmap ) {
		$banner_style = ' style="background-image: url(\'' . $bg_image_src . '\'); margin-bottom: 0; padding-bottom: 80px;"';
	} else {
		$banner_style = ' style="background-image: url(\'' . $bg_image_src . '\');"';
	}
}
?>

<section id="<?php echo $al_meta['section-anchor']; ?>"<?php if ( ! $gmap ) {
	echo ' class="margin-bottom"';
} ?><?php echo $banner_style; ?>>

	<?php
	//Headline
	if ( $gmap and $gmap_position == 'top' ) {
        get_template_part( AL_TEMPLATE_PARTS , 'headline-no-margin' );
		echo $gmap;
	} else {
        get_template_part( AL_TEMPLATE_PARTS , 'headline' );
	}

	$content = get_the_content();
	if ( ! empty( $content ) ) {
		?>
		<div class="row gutters content-spacer"<?php if ( $gmap_iframe ) {
			echo ' style="margin-top: 80px; margin-bottom: 80px;"';
		} ?>>
            <div class="content">
                <?php the_content(); ?>
            </div>

			<?php
			if ( comments_open() || get_comments_number() ) {
				comments_template();
			}
			?>
		</div>
	<?php } ?>

	<?php
	if ( $gmap and $gmap_position == 'bottom' ) {
		echo $gmap;
	}
	?>
</section>