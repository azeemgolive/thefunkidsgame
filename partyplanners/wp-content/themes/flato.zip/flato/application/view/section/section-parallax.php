<?php
/**
 * @package    artless Flato
 * @author     Christian Glingener <glingener.christian@gmail.com>
 * @version    1.0.0
 * @copyright  2014 artlessthemes.com
 * @link       http://artlessthemes.com/
 */

/**
 * Meta & Options
 */
global $al_meta;
global $al_theme_options;

$banner_style = '';

if ( has_post_thumbnail() ) {
	$bg_image     = wp_get_attachment_image_src( get_post_thumbnail_id(), 'al-parallax' );
	$bg_image_src = $bg_image[0];

	$banner_style = ' style="background-image: url(\'' . $bg_image_src . '\');"';
} else {
	$parallax_default = $al_theme_options->getOption( 'al_general_parallax_background', 'url' );

	if ( $parallax_default ) {
		$banner_style = ' style="background-image: url(\'' . $parallax_default . '\');"';
	}
}
?>

<section id="<?php echo $al_meta['section-anchor']; ?>" class="section">

	<?php
	// Headline
    get_template_part( AL_TEMPLATE_PARTS , 'headline-no-margin' );
	?>

	<div class="parallax-content"<?php echo $banner_style; ?>>
		<div class="row">

            <div class="content">
                <?php the_content(); ?>
            </div>

		</div>
	</div>
</section>