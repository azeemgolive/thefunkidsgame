<?php
/**
 * @package    artless Flato
 * @author     Christian Glingener <glingener.christian@gmail.com>
 * @version    1.0.0
 * @copyright  2014 artlessthemes.com
 * @link       http://artlessthemes.com/
 */

/**
 * Meta & Options
 */
global $al_meta;
global $al_theme_options;

// Filter
$al_pf_filter = $al_theme_options->getOption( 'al_portfolio_filter' );

// Load More
$al_pf_load_more = $al_theme_options->getOption( 'al_portfolio_load_more' );

// Number of Projects
$al_pf_posts_number = $al_theme_options->getOption( 'al_portfolio_posts' );


$paged = ( get_query_var( 'paged' ) ) ? intval( get_query_var( 'paged' ) ) : 1;
$portfolio = new WP_Query( array(
	'post_type'      => 'portfolio',
	'posts_per_page' => $al_pf_posts_number,
	'orderby'        => 'menu_order date',
	'paged'          => $paged
) );

$portfolio_terms = get_terms( 'portfolio_categories', array( 'orderby' => 'slug' ) );


// PreLoader
if ( ! isset( $al_preloader ) ) {
	$al_preloader = ( $al_theme_options->getOption( 'al_style_preloader', 'url' ) )
		? $al_theme_options->getOption( 'al_style_preloader', 'url' )
		: AL_PUBLIC . '/img/color_loader.gif';
}

// Background
$banner_style = '';

if ( has_post_thumbnail() ) {
	$bg_image     = wp_get_attachment_image_src( get_post_thumbnail_id(), 'al-parallax' );
	$bg_image_src = $bg_image[0];

	$banner_style = ' style="background-image: url(\'' . $bg_image_src . '\');"';
}
?>

<section id="<?php echo $al_meta['section-anchor']; ?>"<?php echo $banner_style; ?>>

	<?php
	// Headline
    get_template_part( AL_TEMPLATE_PARTS , 'headline-no-margin' );
	?>

	<?php if ($portfolio->have_posts()) { ?>
	<div class="al-pf">
		<div id="al-pf-wrapper">
			<div class="close">
				<a id="al-pf-wrapper-close"></a>
			</div>
			<div id="al-pf-loader"><img class="al-loader-img" src="<?php echo $al_preloader; ?>" alt="" /></div>

			<div id="al-pf-load-content">
				<!-- PORTFOLIO DETAILS LOAD HERE -->
			</div>
		</div>

		<?php
		if ( $portfolio_terms and $al_pf_filter ) {
			$term_all_categories = $al_theme_options->getOption( 'al_portfolio_term_filter_all' )
				? $al_theme_options->getOption( 'al_portfolio_term_filter_all' ) : 'All';
			?>
			<div class="row">
				<ul id="al-pf-tabs" class="al-tabs">
					<li class="al-pf-filter active" data-filter="all">
						<a><?php echo $term_all_categories; ?></a>
					</li>
					<?php foreach ( $portfolio_terms as $category ) { ?>
						<li class="al-pf-filter" data-filter="<?php echo $category->slug; ?>">
							<a><?php echo $category->name; ?></a>
						</li>
					<?php } ?>
				</ul>
			</div>
		<?php } ?>

		<div id="al-pf-preview-loader">
			<ul id="al-pf-preview">
				<?php get_template_part( AL_TEMPLATE_SECTION, 'portfolio-preview-single' ); ?>
			</ul>
		</div>

		<?php
		/**
		 * LOAD MORE
		 */
		if ( $al_pf_load_more and $portfolio->max_num_pages > 1 ) {

			$paged ++;

			$pages = array();
			for ( $i = $paged; $i <= $portfolio->max_num_pages; $i ++ ) {
				$pages[] = '"' . $i . '"';
			}

			$json_pages = '[' . implode( ',', $pages ) . ']';

			$term_load_more = $al_theme_options->getOption( 'al_portfolio_term_load_more' )
				? $al_theme_options->getOption( 'al_portfolio_term_load_more' ) : 'Load More'; ?>

			<div class="load-more-button">
				<img id="al-pf-load-more-loader" class="al-loader-img" src="<?php echo $al_preloader; ?>" />
				<a id="al-pf-button-load-more" class="button border" name="al-pf-load-more"
				   data-post-paged='<?php echo $json_pages; ?>'><?php echo $term_load_more; ?></a>
			</div>

		<?php } ?>
	</div>
<?php } ?>

</section>
