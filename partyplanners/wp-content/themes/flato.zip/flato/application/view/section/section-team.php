<?php
/**
 * @package    artless Flato
 * @author     Christian Glingener <glingener.christian@gmail.com>
 * @version    1.0.0
 * @copyright  2014 artlessthemes.com
 * @link       http://artlessthemes.com/
 */

/**
 * Meta & Options
 */
global $al_meta;
global $al_theme_options;

// Team Filter
$al_team_filter = $al_theme_options->getOption( 'al_team_filter' );
$al_team_filter_show_all = $al_theme_options->getOption( 'al_team_filter_show_all' );

// Members per Row
$al_team_members_per_row = $al_theme_options->getOption( 'al_team_members_per_row' );

// Member description min-height
$al_team_member_description_min_height = $al_theme_options->getOption( 'al_team_members_description_min_height' );

// Option to open socials in a new window
$al_team_socials_blank = $al_theme_options->getOption( 'al_team_socials_blank' );

if( $al_team_member_description_min_height ) {
	$description_style = ' style="min-height:'.$al_team_member_description_min_height.';"';
} else {
	$description_style = '';
}

// Get the Team
$team = new WP_Query( array(
	'post_type'      => 'team',
	'posts_per_page' => - 1,
	'orderby'        => 'menu_order'
) );

$team_terms = get_terms( 'team_professions', array( 'orderby' => 'slug' ) );

// Background
$banner_style = '';

if ( has_post_thumbnail() ) {
	$bg_image     = wp_get_attachment_image_src( get_post_thumbnail_id(), 'al-parallax' );
	$bg_image_src = $bg_image[0];

	$banner_style = ' style="background-image: url(\'' . $bg_image_src . '\'); margin-bottom: 0; padding-bottom: 80px;"';
}
?>

<section id="<?php echo $al_meta['section-anchor']; ?>" class="margin-bottom"<?php echo $banner_style; ?>>

	<?php
	// Headline
	if ( $al_team_filter and $team_terms ) {
        get_template_part( AL_TEMPLATE_PARTS , 'headline-no-margin' );
	} else {
        get_template_part( AL_TEMPLATE_PARTS , 'headline' );
    }
	?>

	<?php if ( get_the_content() ) { ?>
		<div class="row gutters">
            <div class="content">
                <?php the_content(); ?>
            </div>
		</div>
	<?php } ?>


	<?php
	if ($team->have_posts()) {

	/**
	 * Define Cols per Row
	 */
	$user_cols =
		( $al_team_members_per_row ) ? $al_team_members_per_row : 3;
	$col_width = 12 / $user_cols;

	switch ( $user_cols ) {
		case 1:
			$style = "margin-left: 0; margin-right: 0;";
			break;
		case 2:
			$style = "margin-left: 1%; margin-right: 1%;";
			break;
		case 3:
			$style = "margin-left: 2%; margin-right: 1%;";
			break;
		case 4:
			$style = "margin-left: 2%; margin-right: 1%;";
			break;
		case 6:
			$style = "margin-left: 2%; margin-right: 2%;";
			break;
		default:
			$style     = "margin-left: 2% ; margin-right: 1%;";
			$col_width = 4;
			break;
	}

	?>

	<?php
	if ($al_team_filter) {
	if ( $team_terms ) {
		?>
		<div class="row">
			<ul id="al-team-tabs" class="al-tabs">
				<?php if ( $al_team_filter_show_all ) { ?>
					<li class="al-team-filter active" data-filter="all">
						<a><?php _e( 'All', 'artless' ); ?></a>
					</li>
				<?php } ?>

				<?php
				foreach ( $team_terms as $category ) {
					if ( $category->term_id != 1 ) {
						?>
						<li class="al-team-filter" data-filter="<?php echo $category->slug; ?>">
							<a><?php echo $category->name; ?></a>
						</li>
					<?php
					}
				}
				?>
			</ul>
		</div>
	<?php
	}
	?>
	<div class="row gutters">
		<?php } else { ?>
		<div class="row gutters content-spacer">
			<?php } ?>


			<ul id="al-team">
				<?php

				while ( $team->have_posts() ) {

					$team->the_post();
					$id_post = get_the_ID();

					$thumbnail       = null;
					$thumbnail_dummy = AL_PUBLIC . '/img/blog-dummy.jpg';

					// Image
					$post_image     = wp_get_attachment_image_src( get_post_thumbnail_id(), 'al-team-member' );
					$post_image_src = $post_image[0];

					// Has Thumbnail
					if ( $post_image_src ) {

						$thumbnail = $post_image_src;
					} else {
						$thumbnail = $thumbnail_dummy;
					}

					// Professions
					$professions     = get_the_terms( get_the_ID(), 'team_professions' );
					$professions_str = '';

					if ( $professions ) {
						foreach ( $professions as $profession ) {

							if ( $profession->term_id != 1 ) {
								$professions_str .= $profession->name . ', ';
							}
						}

						$professions_str = rtrim( $professions_str, ', ' );
					}

					$team_socials = al_team_socials();

					foreach ( $team_socials as $key => $value ) {

						$social = get_post_meta( $id_post, 'al_team_socials_' . $key, TRUE );

						$team_socials[$key]['link'] = $social;
					}

					// col css
					$col_css = $col_width;

					// if team filte is enabled
					if ( $al_team_filter ) {

						$col_css .= ' al-team-mix';

						$member_terms = get_the_terms( get_the_ID(), 'team_professions' );

						if ( $member_terms ) {
							foreach ( $member_terms as $term ) {
								$col_css .= ' ' . $term->slug;
							}
						}
					} else {
						$style .= 'display: inline-block;';
					}

					?>
					<li class="col span_<?php echo $col_css; ?>" style="<?php echo $style; ?>">
						<div class="al-team-member">
							<img class="member-img" src="<?php echo $thumbnail; ?>" alt="<?php the_title(); ?>" />
							<span class="member-name"><?php the_title(); ?></span>
							<span class="member-function"><?php echo $professions_str; ?></span>

							<?php $content = get_the_content();
							if( ! empty( $content ) or $description_style != '' ) { ?>
								<div class="member-description"<?php echo $description_style;?>>
									<?php the_content(); ?>
								</div>
							 <?php } ?>

							<div class="social-icons">
								<?php
								foreach ( $team_socials as $social_icon ) {
									if ( ! empty( $social_icon['link'] ) ) {
                                        if( $al_team_socials_blank ) {
                                            echo '<a href="' . $social_icon['link'] . '" target="_blank">'
                                                . '<i class="fa ' . $social_icon['fa-icon'] . '"></i></a>';
                                        } else {
                                            echo '<a href="' . $social_icon['link'] . '">'
                                                . '<i class="fa ' . $social_icon['fa-icon'] . '"></i></a>';
                                        }

									}
								}
								?>
							</div>
						</div>
					</li>

				<?php
				} /* /while have_posts */
				?>
			</ul>
		</div>

		<?php } /* /if have posts */ ?>

</section>
