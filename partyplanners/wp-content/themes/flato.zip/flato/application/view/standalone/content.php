<?php
/**
 * @package    artless Flato
 * @author     Christian Glingener <glingener.christian@gmail.com>
 * @version    1.0.0
 * @copyright  2014 artlessthemes.com
 * @link       http://artlessthemes.com/
 */

global $al_meta;
global $al_theme_options;

$post_class = ( $al_meta['page-type'] == 'parallax' )
	? 'parallax-content'
	: '';

$sidebar = rwmb_meta( 'al_sidebar' );
$sidebar = ( $sidebar == 'none' ) ? false : $sidebar;

// Google Map API
$gmaps_api_file = AL_DIR . '/application/view/parts/google-maps-api.php';
file_exists( $gmaps_api_file ) ? require( $gmaps_api_file ) : false;

// Background
$banner_style = '';
if ( $gmap_iframe ) {
	$content_style = ' style="padding-bottom: 80px;"';
} else {
	$content_style = '';
}

if ( has_post_thumbnail() ) {
	$bg_image     = wp_get_attachment_image_src( get_post_thumbnail_id(), 'al-parallax' );
	$bg_image_src = $bg_image[0];

	$banner_style = ' style="background-image: url(\'' . $bg_image_src . '\'); margin-bottom: 0; padding-bottom: 80px;"';

	if ( $gmap_iframe ) {
		$content_style = ' style="margin-top: 0; padding-top: 80px; padding-bottom: 80px;"';
	} else {
		$content_style = ' style="margin-top: 0; padding-top: 80px;"';
	}
}
?>
<article id="post-<?php the_ID(); ?>" <?php post_class( $post_class ); ?><?php echo $banner_style; ?>>

	<?php
	//Headline
	if ( $gmap and $gmap_position == 'top' ) {
        get_template_part( AL_TEMPLATE_PARTS , 'headline-no-margin' );
		echo $gmap;
	} else {
        get_template_part( AL_TEMPLATE_PARTS , 'headline' );
	} ?>

	<div class="row gutters content-spacer"<?php echo $content_style; ?>>
		<?php if ( is_active_sidebar( 'al-sidebar-right' ) and $sidebar ) { ?>

			<?php if ( $sidebar == 'right' ) { ?>

				<div class="col span_8">
					<div class="row gutters">
                        <div class="content">
                            <?php the_content(); ?>
							<?php wp_link_pages( array( 'before' => '<div class="page-links"><p>' . __( 'Pages:', 'artless' ), 'after' => '</p></div>' ) ); ?>
                        </div>

						<?php comments_template( '', true ); ?>
					</div>
				</div>

				<div class="col span_4 last">
					<div class="row gutters">
						<?php get_sidebar(); ?>
					</div>
				</div>

			<?php } else { ?>

				<div class="col span_4">
					<div class="row gutters">
						<?php get_sidebar(); ?>
					</div>
				</div>

				<div class="col span_8 last">
					<div class="row gutters">
                        <div class="content">
                            <?php the_content(); ?>
							<?php wp_link_pages( array( 'before' => '<div class="page-links"><p>' . __( 'Pages:', 'artless' ), 'after' => '</p></div>' ) ); ?>
                        </div>

						<?php comments_template( '', true ); ?>
					</div>
				</div>

			<?php } ?>

		<?php } else { ?>
            <div class="content">
                <?php the_content(); ?>
				<?php wp_link_pages( array( 'before' => '<div class="page-links"><p>' . __( 'Pages:', 'artless' ), 'after' => '</p></div>' ) ); ?>
            </div>
        <?php
			comments_template( '', true );
		}
		?>
	</div>
	<!-- .entry-content -->
	<?php
	if ( $gmap and $gmap_position == 'bottom' ) {
		echo $gmap;
	}
	?>

</article><!-- #post -->