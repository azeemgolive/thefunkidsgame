<?php
/**
 * @package    artless Flato
 * @author     Christian Glingener <glingener.christian@gmail.com>
 * @version    1.0.0
 * @copyright  2014 artlessthemes.com
 * @link       http://artlessthemes.com/
 */

add_filter( 'rwmb_meta_boxes', 'al_content_meta_boxes' );

/**
 * Meta Boxes for Content Gallery
 *
 * @param $meta_boxes
 */
function al_content_meta_boxes( $meta_boxes ) {

	// Gallery
	$meta_boxes[] = array(
		'id'       => 'al_content_gallery',
		'title'    => __( 'Gallery Images', 'artless' ),
		'pages'    => array( 'post' ),
		'context'  => 'normal',
		'autosave' => true,
		'fields'   => array(
			array(
				'id'   => 'al_content_gallery_images',
				'type' => 'image_advanced',
				//	'type' => 'plupload_image',
				'name' => __( 'Gallery Images', 'artless' )
			),
		),
	);

	// Audio
	$meta_boxes[] = array(
		'id'       => 'al_content_audio',
		'title'    => __( 'Audio', 'artless' ),
		'pages'    => array( 'post' ),
		'context'  => 'normal',
		'autosave' => true,
		'fields'   => array(
			array(
				'id'   => 'al_content_audio_embed',
				'type' => 'textarea',
				'name' => __( 'Embed Code', 'artless' ),
			),
		),
	);

	// Video
	$meta_boxes[] = array(
		'id'       => 'al_content_video',
		'title'    => __( 'Video', 'artless' ),
		'pages'    => array( 'post' ),
		'context'  => 'normal',
		'autosave' => true,
		'fields'   => array(
			array(
				'id'   => 'al_content_video_embed',
				'type' => 'textarea',
				'name' => __( 'Embed Code / Youtube Link', 'artless' ),
			),
		),
	);

	// Meta OG
	$meta_boxes[] = array(
		'id' => 'al_blog_og',
		'title' => __( 'Meta: OpenGraph (i.e. for Facebook sharing)', 'artless' ),
		'pages' => array( 'post' ),
		'context' => 'normal',
		'autosave' => true,
		'default_hidden' => true,
		'fields' => array(
			array(
				'id'   => 'al_blog_og_title',
				'type' => 'text',
				'name' => __( 'Title', 'artless' ),
				'desc' => __( 'If no title is set, the default title will be used.', 'artless' ),
			),
			array(
				'id'   => 'al_blog_og_description',
				'type' => 'textarea',
				'name' => __( 'Description', 'artless' ),
			),
		),
	);

	return $meta_boxes;
}