<?php
/**
 * @package    artless Flato
 * @author     Christian Glingener <glingener.christian@gmail.com>
 * @version    1.0.0
 * @copyright  2014 artlessthemes.com
 * @link       http://artlessthemes.com/
 */

$extensions_dir = dirname( __FILE__ );

$extension_files = array(
	/**
	 * All kind of Posts
	 */
	$extensions_dir . '/pages.php',
	$extensions_dir . '/blog.php',

	/**
	 * Class Artless_Navigation extends Walker_Nav_Menu
	 */
	$extensions_dir . '/navigation.php',
);

// for each file
foreach ( $extension_files as $file ) {
	// if file exists
	if ( is_file( $file ) ) {
		require( $file );
	}
}






