<?php
/**
 * @package    artless Flato
 * @author     Christian Glingener <glingener.christian@gmail.com>
 * @version    1.0.0
 * @copyright  2014 artlessthemes.com
 * @link       http://artlessthemes.com/
 */
add_filter( 'rwmb_meta_boxes', 'al_pages_meta_boxes' );

/**
 * Meta Boxes for Pages
 *
 * @param $meta_boxes
 */
function al_pages_meta_boxes( $meta_boxes ) {

	// Page Types - home, default and parallax
	$page_types = array(
		'home'     => __( 'Home', 'artless' ),
		'default'  => __( 'Default', 'artless' ),
		'parallax' => __( 'Parallax', 'artless' ),
		'video'	   => __( 'Video', 'artless' ),
	);

	// Page Type portfolio if plugin is active
	if ( is_plugin_active( 'artless-portfolio/artless-portfolio.php' ) ) {
		$page_types['portfolio'] = __( 'Portfolio', 'artless' );
	}

	// Page Type blog
	$page_types['blog'] = __( 'Blog', 'artless' );

	// Page Type team if plugin is active
	if ( is_plugin_active( 'artless-team/artless-team.php' ) )
		$page_types['team'] = __( 'Team', 'artless' );


	$meta_boxes[] = array(
		'id'       => 'al_page',
		'title'    => __( 'Page Options', 'artless' ),
		'pages'    => array( 'page' ),
		'context'  => 'normal',
		'priority' => 'high',
		'autosave' => true,
		'fields'   => array(

			array(
				'id'   => "al_show_title",
				'type' => 'checkbox',
				'name' => __( 'Show Title', 'artless' ),
				'std'  => 1,
			),

			array(
				'id'   => "al_title",
				'type' => 'text',
				'name' => __( 'Title', 'artless' ),
				'desc' => __( 'overwrites default Page Title', 'artless' ),
			),

			array(
				'id'   => "al_subtitle",
				'type' => 'text',
				'name' => __( 'Subtitle', 'artless' ),
			),

			array(
				'id'      => "al_page_type",
				'type'    => 'select',
				'name'    => __( 'Section Type', 'artless' ),
				'options' => $page_types,
				'desc'    => '<b>' . __( 'Home, Portfolio, Team and Blog', 'artless' ) . '</b> ' . __( 'should only be used once.', 'artless' ) . '<br />'
                               . __( 'Use Home for the first section.', 'artless' ),
				'std'     => 'default',
			),

			array(
				'id'       => "al_google_map",
				'name'     => __( 'Google Map - Full Width', 'artless' ),
				'type'     => 'select',

				'options'  => array(
					'none'   => __( 'None', 'artless' ),
					'api'    => __( 'Per Google API', 'artless' ),
					'iframe' => __( 'Per IFrame', 'artless' ),
				),

				'multiple' => false,
				'std'      => 'none',
			),

			array(
				'id'   => "al_google_map_iframe",
				'type' => 'textarea',
				'name' => __( 'Google Map IFrame', 'artless' ),
				'desc' => __( 'Height and Width of IFrame will be overwritten.', 'artless' ),
			),

			array(
				'id'   => "al_google_map_height",
				'type' => 'text',
				'name' => __( 'Google Map Height', 'artless' ),
				'desc' => __( 'in px', 'artless' ),
				'std'  => '500px'
			),

			array(
				'id'       => "al_google_map_position",
				'name'     => __( 'Google Map Position', 'artless' ),
				'type'     => 'select',

				'options'  => array(
					'top'    => __( 'Before Page Content', 'artless' ),
					'bottom' => __( 'After Page Content', 'artless' ),
				),

				'multiple' => false,
				'std'      => 'top',
			),

			array(
				'id'       => "al_video_size",
				'name'     => __( 'Video Size', 'artless' ),
				'type'     => 'select',

				'options'  => array(
					'fullwidth'   => __( 'Fullwidth', 'artless' ),
					'fullscreen'  => __( 'Fullscreen', 'artless' ),
					'fullscreen-home'  => __( 'Fullscreen with Home Layout', 'artless' )
				),

				'multiple' => false,
				'std'      => 'fullwidth',
			),

			array(
				'id'       => "al_video_min_height",
				'name'     => __( 'Video Min-Height', 'artless' ),
				'type'     => 'text',
				'subtitle' => __( 'For Fullwidth Videos', 'artless' ),
				'desc'	   => __( 'For Example:', 'artless' ) . ' 200px',
			),

			array(
				'id'       => "al_video_links",
				'name'     => __( 'Videos', 'artless' ),
				'type'     => 'textarea',
				'desc'	   => __( 'Link to your own hosted videos ( one per line, should be at least .mp4 and .webm format ) or Youtube link. For better performance we recommend own hosted videos.', 'artless' )
			),

			array(
				'id'   => "al_standalone",
				'type' => 'checkbox',
				'name' => __( 'Standalone', 'artless' ),
				'desc' => __( 'This page won\'t be shown on the One Page', 'artless' ),
				'std'  => 0,
			),

			array(
				'id'      => "al_sidebar",
				'type'    => 'select',
				'name'    => __( 'Standalone Layout', 'artless' ),

				'options' => array(
					'none'  => __( 'Content', 'artless' ),
					'right' => __( 'Content / Sidebar', 'artless' ),
					'left'  => __( 'Sidebar / Content', 'artless' ),

				),

				'std'     => 'none',
			),


		),
	);

	// Meta OG
	$meta_boxes[] = array(
		'id' => 'al_page_og',
		'title' => __( 'Meta: OpenGraph (i.e. for Facebook sharing)', 'artless' ),
		'pages' => array( 'page' ),
		'context' => 'normal',
		'autosave' => true,
		'priority' => 'core',
		'default_hidden' => true,
		'fields' => array(
			array(
				'id'   => 'al_page_og_title',
				'type' => 'text',
				'name' => __( 'Title', 'artless' ),
				'desc' => __( 'If no title is set, the default title will be used.', 'artless' ),
			),
			array(
				'id'   => 'al_page_og_description',
				'type' => 'textarea',
				'name' => __( 'Description', 'artless' ),
			),
		),
	);

	return $meta_boxes;
}