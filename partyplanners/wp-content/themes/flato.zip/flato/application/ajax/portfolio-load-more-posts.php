<?php
/**
 * @package    artless Flato
 * @author     Christian Glingener <glingener.christian@gmail.com>
 * @version    1.0.0
 * @copyright  2014 artlessthemes.com
 * @link       http://artlessthemes.com/
 */

add_action( 'wp_ajax_al_portfolio_load_more_posts', 'al_portfolio_load_more_posts' );
add_action( 'wp_ajax_nopriv_al_portfolio_load_more_posts', 'al_portfolio_load_more_posts' );

function al_portfolio_load_more_posts() {

	$paged = $_POST['post-paged'];

	$file = dirname( __FILE__ ) . '/../view/section/section-portfolio-preview-single.php';

	if ( is_file( $file ) ) {
		require( $file );
	}

	die();
}