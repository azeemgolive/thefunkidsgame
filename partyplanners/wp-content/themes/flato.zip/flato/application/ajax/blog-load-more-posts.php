<?php
/**
 * @package    artless Flato
 * @author     Christian Glingener <glingener.christian@gmail.com>
 * @version    1.0.0
 * @copyright  2014 artlessthemes.com
 * @link       http://artlessthemes.com/
 */

add_action( 'wp_ajax_al_blog_load_more_posts', 'al_blog_load_more_posts' );
add_action( 'wp_ajax_nopriv_al_blog_load_more_posts', 'al_blog_load_more_posts' );

function al_blog_load_more_posts() {

	get_template_part( AL_TEMPLATE_SECTION, 'blog-preview-single' );

	die();
}