<?php
/**
 * @package    artless Flato
 * @author     Christian Glingener <glingener.christian@gmail.com>
 * @version    1.0.0
 * @copyright  2014 artlessthemes.com
 * @link       http://artlessthemes.com/
 */

// General Settings
// Icons http://shoestrap.org/downloads/elusive-icons-webfont/
return ( array(

	// Sortorder ASC
	'sortorder' => 4,

	// Options
	'options'   => array(
		'title'  => __( 'Styling', 'artless' ),
		'icon'   => 'el-icon-website',
		'fields' => array(
			array(
				'id'       => 'al_style_color_primary',
				'type'     => 'color',
				'title'    => __( 'Accent Color 1', 'artless' ),
				'subtitle' => __( 'Default:', 'artless' ) . ' #48a65b',
				'default'  => '#48a65b',
				'validate' => 'color',
			),

			array(
				'id'       => 'al_style_color_primary_lighten',
				'type'     => 'color',
				'title'    => __( 'Accent Color 2', 'artless' ),
				'subtitle' => __( 'Default:', 'artless' ) . ' #56c16b ' . __( '(lightened version of color 1)', 'artless' ),
				'default'  => '#56c16b',
				'validate' => 'color',
			),

			array(
				'id'       => 'al_style_bg_color',
				'type'     => 'color',
				'title'    => __( 'Background Color 1', 'artless' ),
				'subtitle' => __( 'Default:', 'artless' ) . ' #2d3943',
				'default'  => '#2d3943',
				'validate' => 'color',
			),

			array(
				'id'       => 'al_style_bg_color_lighten',
				'type'     => 'color',
				'title'    => __( 'Background Color 2', 'artless' ),
				'subtitle' => __( 'Default:', 'artless' ) . ' #384551 ' . __( '(lightened version of background color 1)' , 'artless' ),
				'default'  => '#384551',
				'validate' => 'color',
			),

			array(
				'id'       => 'al_style_bg_color_footer',
				'type'     => 'color',
				'title'    => __( 'Navigation / Footer Background Color', 'artless' ),
				'subtitle' => __( 'Default:', 'artless' ) . ' #27333d',
				'default'  => '#27333d',
				'validate' => 'color',
			),

			array(
				'id'       => 'al_style_link_color',
				'type'     => 'link_color',
				'title'    => __( 'Links Color Option', 'artless' ),
				'subtitle' => __( 'If no color is set Accent Color 1 and Accent Color 2 will be used.', 'artless' ),
				'visited'  => true,
			),

			array(
				'id'    => 'al_style_preloader',
				'type'  => 'media',
				'title' => __( 'Custom Preloader Image', 'artless' ),
				'hint'  => array(
					'title'   => 'Default width is 30 px!',
					'content' => 'To change copy to <b>Custom CSS</b>:<br /><br />.al-loader-img { <br />&nbsp; &nbsp; width: 50px;<br />&nbsp; &nbsp; height: 50px;<br />}'
				)
			),

			array(
				'id'       => 'al_style_headline_underline',
				'type'     => 'media',
				'title'    => __( 'Custom Underline-Graphic', 'artless' ),
				'subtitle' => __( 'For Headlines', 'artless' ),
				'hint'     => array(
					'title'   => 'Don\'t want underlined headlines?',
					'content' => 'Copy to <b>Custom CSS</b>:<br /><br />.underline { <br />&nbsp; &nbsp; background: none;<br />&nbsp; &nbsp; padding-bottom: 0;<br />}'
				)
			),

			array(
				'id'    => 'al_style_user_css',
				'type'  => 'ace_editor',
				'title' => __( 'Custom CSS', 'artless' ),
				'mode'  => 'css',
				'theme' => 'chrome'
			),
		),
	)
) );