<?php
/**
 * @package    artless Flato
 * @author     Christian Glingener <glingener.christian@gmail.com>
 * @version    1.0.0
 * @copyright  2014 artlessthemes.com
 * @link       http://artlessthemes.com/
 */

// Theme Options Class
global $al_theme_options;

// Presets
$preset_files['flato-parallax'] = AL_DIR . '/application/options/presets/flato-parallax.php';
$preset_files['flato-slider'] = AL_DIR . '/application/options/presets/flato-slider.php';

foreach ( $preset_files as $preset_key => $preset_file ) {
    if ( is_file( $preset_file ) ) {
        $preset[$preset_key] = require( $preset_file );
    }
}


// General Options
$options_files[] = AL_DIR . '/application/options/general.php';

// Typography Options
$options_files[] = AL_DIR . '/application/options/typography.php';

// Styling Options
$options_files[] = AL_DIR . '/application/options/styling.php';

// Home Options
$options_files[] = AL_DIR . '/application/options/home.php';

// Blog Options
$options_files[] = AL_DIR . '/application/options/blog.php';

// Social Links
$options_files[] = AL_DIR . '/application/options/social-links/options.php';

// Slider (Blog/Portfolio)
$options_files[] = AL_DIR . '/application/options/slider.php';

// Sharing
$options_files[] = AL_DIR . '/application/options/sharing.php';

// Automatic Updates
$options_files[] = AL_DIR . '/application/options/automatic-updates.php';

//if( is_file( $gmaps_ajax_file ) ) {
//	require( $gmaps_ajax_file );
//}

// Redux Add Options
foreach ( $options_files as $option_file ) {

	// Check if File exists
	if ( is_file( $option_file ) ) {

		$arr_options = require( $option_file );

		$al_theme_options->addOption( $arr_options['options'], $arr_options['sortorder'] );
	}

}