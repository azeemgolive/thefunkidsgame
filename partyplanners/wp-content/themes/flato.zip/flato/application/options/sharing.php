<?php
/**
 * @package    artless Flato
 * @author     Christian Glingener <glingener.christian@gmail.com>
 * @version    1.0.0
 * @copyright  2014 artlessthemes.com
 * @link       http://artlessthemes.com/
 */

// General Settings
// Icons http://shoestrap.org/downloads/elusive-icons-webfont/
return ( array(

	// Sortorder ASC
	'sortorder' => 400,

	// Options
	'options'   => array(
		'title'  => __( 'Sharing', 'artless' ),
		'icon'   => 'el-icon-share',
		'fields' => array(

			array(
				'id'       => 'al_sharing_opengraph',
				'type'     => 'switch',
				'title'    => __( 'OpenGraph Meta-Tags', 'artless' ),
				'subtitle' => __( 'Disable if you want to use a OpenGraph Plugin.', 'artless' ),
				'hint' 	   => array(
					'title' 	=> __( 'What is OpenGraph?', 'artless' ),
					'content' 	=> __( 'If enabled the OpenGraph Title, Description and Image will be used for Facebook Sharing or other networks which supports OpenGraph.', 'artless' ),
				),
				'default'  => 0,
				'on'       => 'Enabled',
				'off'      => 'Disabled',

			),

			array(
				'id'       => 'al_sharing_title',
				'type'     => 'text',
				'required' => array( 'al_sharing_opengraph', '=', '1' ),
				'title'    => __( 'OnePage OpenGraph Title', 'artless' ),
				'subtitle' => __( 'If empty the Site Title will be used.', 'artless' ),
			),

			array(
				'id'       => 'al_sharing_description',
				'type'     => 'textarea',
				'required' => array( 'al_sharing_opengraph', '=', '1' ),
				'title'    => __( 'OnePage OpenGraph Description', 'artless' ),
				'subtitle' => __( 'If empty the Site Tagline will be used.', 'artless' ),
			),

			array(
				'id'    => 'al_sharing_images',
				'type'  => 'gallery',
				'required' => array( 'al_sharing_opengraph', '=', '1' ),
				'title' => __( 'OnePage OpenGraph Images', 'artless' ),
				'subtitle' => __( 'You should not use more than 5 images.', 'artless' ),
			),

			array(
				'id'       => 'al_sharing_opengraph_blog',
				'type'     => 'switch',
				'required' => array( 'al_sharing_opengraph', '=', '1' ),
				'title'    => __( 'OpenGraph Single Blog Posts', 'artless' ),
				'subtitle' => __( 'Disable if you want to use a OpenGraph Plugin for Blog Posts.', 'artless' ),
				'hint' 	   => array(
					'title' 	=> __( 'Title / Description / Images', 'artless' ),
					'content' 	=> __( 'For Single Blog Posts the Post\'s Title, Description, Featured Image and Gallery Images will be used.', 'artless' ),
				),
				'default'  => 1,
				'on'       => 'Enabled',
				'off'      => 'Disabled',

			),

			array(
				'id'       => 'al_sharing_opengraph_page',
				'type'     => 'switch',
				'required' => array( 'al_sharing_opengraph', '=', '1' ),
				'title'    => __( 'OpenGraph Single Page', 'artless' ),
				'subtitle' => __( 'Disable if you want to use a OpenGraph Plugin for Pages.', 'artless' ),
				'hint' 	   => array(
					'title' 	=> __( 'Title / Description / Images', 'artless' ),
					'content' 	=> __( 'For Single Pages the Page\'s Title, Description and Featured Image will be used.', 'artless' ),
				),
				'default'  => 1,
				'on'       => 'Enabled',
				'off'      => 'Disabled',

			),
		),
	)
) );