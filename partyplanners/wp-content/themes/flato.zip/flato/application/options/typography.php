<?php
/**
 * @package    artless Flato
 * @author     Christian Glingener <glingener.christian@gmail.com>
 * @version    1.0.0
 * @copyright  2014 artlessthemes.com
 * @link       http://artlessthemes.com/
 */

$fonts = array(
	"flato-default"                                        => "'Open Sans', sans-serif (Flato Default)",
	"Arial, Helvetica, sans-serif"                         => "Arial, Helvetica, sans-serif",
	"'Arial Black', Gadget, sans-serif"                    => "'Arial Black', Gadget, sans-serif",
	"'Bookman Old Style', serif"                           => "'Bookman Old Style', serif",
	"'Comic Sans MS', cursive"                             => "'Comic Sans MS', cursive",
	"Courier, monospace"                                   => "Courier, monospace",
	"Garamond, serif"                                      => "Garamond, serif",
	"Georgia, serif"                                       => "Georgia, serif",
	"Impact, Charcoal, sans-serif"                         => "Impact, Charcoal, sans-serif",
	"'Lucida Console', Monaco, monospace"                  => "'Lucida Console', Monaco, monospace",
	"'Lucida Sans Unicode', 'Lucida Grande', sans-serif"   => "'Lucida Sans Unicode', 'Lucida Grande', sans-serif",
	"'MS Sans Serif', Geneva, sans-serif"                  => "'MS Sans Serif', Geneva, sans-serif",
	"'MS Serif', 'New York', sans-serif"                   => "'MS Serif', 'New York', sans-serif",
	"'Palatino Linotype', 'Book Antiqua', Palatino, serif" => "'Palatino Linotype', 'Book Antiqua', Palatino, serif",
	"Tahoma,Geneva, sans-serif"                            => "Tahoma, Geneva, sans-serif",
	"'Times New Roman', Times,serif"                       => "'Times New Roman', Times, serif",
	"'Trebuchet MS', Helvetica, sans-serif"                => "'Trebuchet MS', Helvetica, sans-serif",
	"Verdana, Geneva, sans-serif"                          => "Verdana, Geneva, sans-serif",
);

// General Settings
// Icons http://shoestrap.org/downloads/elusive-icons-webfont/
return ( array(

	// Sortorder ASC
	'sortorder' => 3,

	// Options
	'options'   => array(
		'title'  => __( 'Typography', 'artless' ),
		'icon'   => 'el-icon-font',
		'fields' => array(

			array(
				'id'       => 'al_typo_google_api',
				'type'     => 'text',
				'title'    => __( 'Your Google API Key', 'artless' ),
				'subtitle' => __( 'Needed to activate Google Fonts.', 'artless' ),
				'desc'     => '<a href="https://developers.google.com/fonts/docs/developer_api#Auth">' . __( 'How to get an API key?', 'artless' ) . '</a>',
			),

			array(
				'id'             => 'al_typo_body',
				'type'           => 'typography',
				'title'          => __( 'General', 'artless' ),
				//'compiler'=>true, // Use if you want to hook in your own CSS compiler
				'google'         => true, // Disable google fonts. Won't work if you haven't defined your google api key
				'font-backup'    => true, // Select a backup non-google font in addition to a google font
				'font-style'     => false, // Includes font-style and weight. Can use font-style or font-weight to declare
				'subsets'        => false, // Only appears if google is true and subsets not set to false
				//'font-size'   => false,
				'line-height'    => true,
				'text-transform' => true,
				'text-align'     => false,
				//'word-spacing'=>true, // Defaults to false
				//'letter-spacing'=>true, // Defaults to false
				//'color'=>false,
				'preview'        => false, // Disable the previewer
				'all_styles'     => true, // Enable all Google Font style/weight variations
				'units'          => '%', // Defaults to px
				'subtitle'       => __( 'All elements will get this Typo, unless they will be overwritten with next options.', 'artless' ),
				'fonts'          => $fonts,
				'default'        => array(
					'color'       => "#d7d7d7",
					'font-style'  => '400',
					'font-family' => 'flato-default',
					'google'      => true,
					'font-size'   => '100%',
					'line-height' => '145%' ),
			),

			array(
				'id'             => 'al_typo_paragraphs',
				'type'           => 'typography',
				'title'          => __( 'Paragraphs', 'artless' ),
				'subtitle'       => __( 'Notice: Font-Size based on General Font-Size', 'artless' ),
				'google'         => true,
				'font-backup'    => true,
				'font-size'      => true,
				'subsets'        => false,
				'text-align'     => true,
				'line-height'    => true,
				'letter-spacing' => true,
				'text-transform' => true,
				'all_styles'     => true,
				'preview'        => false,
				'units'          => 'em',
				'fonts'          => $fonts,
				'default'        => array(
					'google' => true ),
			),

			array(
				'id'             => 'al_typo_headlines',
				'type'           => 'typography',
				'title'          => __( 'All Headlines', 'artless' ),
				'subtitle'       => __( 'Notice: Font-Size based on General Font-Size', 'artless' ),
				'google'         => true,
				'font-backup'    => true,
				'font-size'      => false,
				'subsets'        => false,
				'text-align'     => false,
				'line-height'    => false,
				'letter-spacing' => false,
				'text-transform' => true,
				'all_styles'     => true,
				'preview'        => false,
				'units'          => 'em',
				'fonts'          => $fonts,
				'default'        => array(
					'google' => true ),
			),

			array(
				'id'             => 'al_typo_home_h1',
				'type'           => 'typography',
				'title'          => __( 'Home Headline', 'artless' ),
				'google'         => true,
				'subsets'        => false,
				'line-height'    => true,
				'text-align'     => false,
				'letter-spacing' => true,
				'text-transform' => true,
				'all_styles'     => true,
				'preview'        => false,
				'units'          => 'em',
				'subtitle'       => __( 'Notice: Font-Size based on General Font-Size', 'artless' ),
				'fonts'          => $fonts,
				'default'        => array(
					'google'      => true,
					'font-style'  => '600',
					'font-family' => 'Open Sans',
					'font-size'   => '5em',
					'line-height' => '1.5em' ),
			),

			array(
				'id'             => 'al_typo_home_subheadline',
				'type'           => 'typography',
				'title'          => __( 'Home Subheadline', 'artless' ),
				'google'         => true,
				'subsets'        => false,
				'line-height'    => true,
				'text-align'     => false,
				'letter-spacing' => true,
				'text-transform' => true,
				'all_styles'     => true,
				'preview'        => false,
				'units'          => 'em',
				'subtitle'       => __( 'Notice: Font-Size based on General Font-Size', 'artless' ),
				'fonts'          => $fonts,
				'default'        => array(
					'google'      => true,
					'font-style'  => '400',
					'font-family' => 'Open Sans',
					'font-size'   => '1.5em' ),
			),

			array(
				'id'             => 'al_typo_h1',
				'type'           => 'typography',
				'title'          => __( 'H1 Headline', 'artless' ),
				'google'         => true,
				'subsets'        => false,
				'line-height'    => true,
				'text-align'     => false,
				'letter-spacing' => true,
				'text-transform' => true,
				'all_styles'     => true,
				'preview'        => false,
				'units'          => 'em',
				'subtitle'       => __( 'Notice: Font-Size based on General Font-Size', 'artless' ),
				'fonts'          => $fonts,
				'default'        => array(
					'google'      => true,
					'font-size'   => '3.5em',
					'line-height' => '1.5em' ),
			),

			array(
				'id'             => 'al_typo_h2',
				'type'           => 'typography',
				'title'          => __( 'H2 Headline', 'artless' ),
				'google'         => true,
				'subsets'        => false,
				'line-height'    => true,
				'text-align'     => false,
				'letter-spacing' => true,
				'text-transform' => true,
				'all_styles'     => true,
				'preview'        => false,
				'units'          => 'em',
				'subtitle'       => __( 'Notice: Font-Size based on General Font-Size', 'artless' ),
				'fonts'          => $fonts,
				'default'        => array(
					'google'      => true,
					'font-size'   => '2.5em',
					'line-height' => '1.5em' ),
			),

			array(
				'id'             => 'al_typo_h3',
				'type'           => 'typography',
				'title'          => __( 'H3 Headline', 'artless' ),
				'google'         => true,
				'subsets'        => false,
				'line-height'    => true,
				'text-align'     => false,
				'letter-spacing' => true,
				'text-transform' => true,
				'all_styles'     => true,
				'preview'        => false,
				'units'          => 'em',
				'subtitle'       => __( 'Notice: Font-Size based on General Font-Size', 'artless' ),
				'fonts'          => $fonts,
				'default'        => array(
					'font-style'  => '600',
					'google'      => true,
					'font-size'   => '2em',
					'line-height' => '1.5em' ),
			),

			array(
				'id'             => 'al_typo_h4',
				'type'           => 'typography',
				'title'          => __( 'H4 Headline', 'artless' ),
				'google'         => true,
				'subsets'        => false,
				'line-height'    => true,
				'text-align'     => false,
				'letter-spacing' => true,
				'text-transform' => true,
				'all_styles'     => true,
				'preview'        => false,
				'units'          => 'em',
				'subtitle'       => __( 'Notice: Font-Size based on General Font-Size', 'artless' ),
				'fonts'          => $fonts,
				'default'        => array(
					'google'      => true,
					'font-size'   => '1.3em',
					'line-height' => '1.5em' ),
			),

			array(
				'id'             => 'al_typo_h5',
				'type'           => 'typography',
				'title'          => __( 'H5 Headline', 'artless' ),
				'google'         => true,
				'subsets'        => false,
				'line-height'    => true,
				'text-align'     => false,
				'letter-spacing' => true,
				'text-transform' => true,
				'all_styles'     => true,
				'preview'        => false,
				'units'          => 'em',
				'subtitle'       => __( 'Notice: Font-Size based on General Font-Size', 'artless' ),
				'fonts'          => $fonts,
				'default'        => array(
					'google'      => true,
					'font-size'   => '1.1em',
					'line-height' => '1.5em' ),
			),

			array(
				'id'             => 'al_typo_h6',
				'type'           => 'typography',
				'title'          => __( 'H6 Headline', 'artless' ),
				'google'         => true,
				'subsets'        => false,
				'line-height'    => true,
				'text-align'     => false,
				'letter-spacing' => true,
				'text-transform' => true,
				'all_styles'     => true,
				'preview'        => false,
				'units'          => 'em',
				'subtitle'       => __( 'Notice: Font-Size based on General Font-Size', 'artless' ),
				'fonts'          => $fonts,
				'default'        => array(
					'google'      => true,
					'font-size'   => '1.0em',
					'line-height' => '1.5em' ),
			),

			array(
				'id'             => 'al_typo_subheadlines',
				'type'           => 'typography',
				'title'          => __( 'Subheadlines', 'artless' ),
				'google'         => true,
				'subsets'        => false,
				'line-height'    => true,
				'text-align'     => false,
				'letter-spacing' => true,
				'text-transform' => true,
				'all_styles'     => true,
				'preview'        => false,
				'units'          => 'em',
				'subtitle'       => __( 'Notice: Font-Size based on General Font-Size', 'artless' ),
				'fonts'          => $fonts,
				'default'        => array(
					'google'      => true,
					'font-size'   => '1.1em',
					'line-height' => '1.7em',
				),
			),
		),
	)
) );