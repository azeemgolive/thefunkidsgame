<?php
/**
 * @package    artless Flato
 * @author     Christian Glingener <glingener.christian@gmail.com>
 * @version    1.0.0
 * @copyright  2014 artlessthemes.com
 * @link       http://artlessthemes.com/
 */

$fonts = array(
    "flato-default"                                        => "'Open Sans', sans-serif (Flato Default)",
    "Arial, Helvetica, sans-serif"                         => "Arial, Helvetica, sans-serif",
    "'Arial Black', Gadget, sans-serif"                    => "'Arial Black', Gadget, sans-serif",
    "'Bookman Old Style', serif"                           => "'Bookman Old Style', serif",
    "'Comic Sans MS', cursive"                             => "'Comic Sans MS', cursive",
    "Courier, monospace"                                   => "Courier, monospace",
    "Garamond, serif"                                      => "Garamond, serif",
    "Georgia, serif"                                       => "Georgia, serif",
    "Impact, Charcoal, sans-serif"                         => "Impact, Charcoal, sans-serif",
    "'Lucida Console', Monaco, monospace"                  => "'Lucida Console', Monaco, monospace",
    "'Lucida Sans Unicode', 'Lucida Grande', sans-serif"   => "'Lucida Sans Unicode', 'Lucida Grande', sans-serif",
    "'MS Sans Serif', Geneva, sans-serif"                  => "'MS Sans Serif', Geneva, sans-serif",
    "'MS Serif', 'New York', sans-serif"                   => "'MS Serif', 'New York', sans-serif",
    "'Palatino Linotype', 'Book Antiqua', Palatino, serif" => "'Palatino Linotype', 'Book Antiqua', Palatino, serif",
    "Tahoma,Geneva, sans-serif"                            => "Tahoma, Geneva, sans-serif",
    "'Times New Roman', Times,serif"                       => "'Times New Roman', Times, serif",
    "'Trebuchet MS', Helvetica, sans-serif"                => "'Trebuchet MS', Helvetica, sans-serif",
    "Verdana, Geneva, sans-serif"                          => "Verdana, Geneva, sans-serif",
);

// General Settings
// Icons http://shoestrap.org/downloads/elusive-icons-webfont/
return ( array(

	// Sortorder ASC
	'sortorder' => 1,

	// Options
	'options'   => array(
		'title'  => __( 'General', 'artless' ),
		'icon'   => 'el-icon-cogs',
		'fields' => array(
            array(
                'id' => 'presets',
                'type' => 'image_select',
                'presets' => true,
                'title' => __('Demo Presets', 'artless'),
                'subtitle' => __('Click on the preset you want to load.', 'artless')
                    . '<br /><br /><span style="font-weight: bold; color: #f32f2f;">'
                    . __( 'Warning!', 'artless' ) . '</span><br />'
                    . __( 'This will overwrite ALL of your "Theme Options" settings!', 'artless'),
                'default' => 0,
                'options' => array(
                    '1' => array( 'alt' => 'Preset 1', 'img' => AL_PUBLIC . '/img/presets/preset-select-parallax.png', 'presets' => $preset['flato-parallax'] ),
                    '2' => array( 'alt' => 'Preset 2', 'img' => AL_PUBLIC . '/img/presets/preset-select-slider.png', 'presets' =>  $preset['flato-slider'] ),
                ),
            ),
			array(
				'id'    => 'al_general_logo',
				'type'  => 'media',
				'title' => __( 'Logo', 'artless' ),
			),

			array(
				'id'       => 'al_general_logo_size',
				'type'     => 'switch',
				'title'    => __( 'Adjust Logo Size for Navigation', 'artless' ),
				'subtitle' => __( 'Enable to adjust your Logo Size', 'artless' ),
				"default"  => 0,
				'on'       => 'Enabled',
				'off'      => 'Disabled',
			),
			array(
				'id'       => 'al_general_logo_width',
				'type'     => 'text',
				'required' => array( 'al_general_logo_size', '=', '1' ),
				'title'    => __( 'Logo Width', 'artless' ),
				'subtitle' => __( 'Leave empty for auto adjustment.', 'artless' ),
				'desc'     => __( 'i.e. 100px or 90%', 'artless' ),
			),

			array(
				'id'       => 'al_general_logo_height',
				'type'     => 'text',
				'required' => array( 'al_general_logo_size', '=', '1' ),
				'title'    => __( 'Logo Height', 'artless' ),
				'subtitle' => __( 'Leave empty for auto adjustment.', 'artless' ),
				'desc'     => __( 'i.e. 100px or 90%.', 'artless' ),
			),

			array(
				'id'       => 'al_general_parallax_background',
				'type'     => 'media',
				'title'    => __( 'Default Parallax Background', 'artless' ),
				'subtitle' => __( 'Can be overwritten by each parallax section.', 'artless' ),
			),

			array(
				'id'       => 'al_general_smooth_scroll',
				'type'     => 'switch',
				'title'    => __( 'Activate Smooth Scroll for all anchors', 'artless' ),
				"default"  => 0,
				'on'       => 'Enabled',
				'off'      => 'Disabled',
			),

			array(
				'id'       => 'al_general_navigation_autoopen',
				'type'     => 'switch',
				'title'    => __( 'Navigation Auto-Open-Close', 'artless' ),
				'subtitle' => __( 'Enabled the navigation will open when the mouse goes to the left of the screen and close when the mouse leaves the opened navigation.', 'artless' ),
				"default"  => 0,
				'on'       => 'Enabled',
				'off'      => 'Disabled',
			),

            array(
                'id'       => 'al_general_navigation_button_html',
                'type'     => 'editor',
                'title'    => __( 'Navigation Toggle: HTML', 'artless' ),
                'subtitle' => __( 'Default: [al_icon icon="bars" inline]' ),
                'default'  => '[al_icon icon="bars" inline]'
            ),

            array(
                'id'             => 'al_general_navigation_button_typo',
                'type'           => 'typography',
                'title'          => __( 'Navigation Toggle: Typography', 'artless' ),
                'google'         => true,
                'font-backup'    => false,
                'font-size'      => true,
                'font-weight'    => true,
                'subsets'        => true,
                'text-align'     => false,
                'line-height'    => true,
                'letter-spacing' => true,
                'text-transform' => true,
                'color'          => false,
                'preview'        => true,
                'units'          => 'px',
                'fonts'          => $fonts,
                'default'        => array(
                    'google' => true ),
            ),

            array(
                'id'       => 'al_general_navigation_button_colors',
                'type'     => 'link_color',
                'title'    => __( 'Navigation Toggle: Colors', 'artless' ),
                'active'   => false,
                'visited'  => false,
            ),

			array(
				'id'    => 'al_general_widget_navigation_css',
				'type'  => 'ace_editor',
				'title' => __( 'Navigation Widgets Adjustments', 'artless' ),
				'mode'  => 'css',
				'theme' => 'chrome',
				'default' => '.al-widget-navigation-top,
.al-widget-navigation-bottom {
	width: 240px;
}

.al-widget-navigation-top {
	top: 50px;
	left: 10px;
}

.al-widget-navigation-bottom {
	bottom: 70px;
	left: 10px;
}'
			),

            array(
                'id'       => 'al_device_slider_autoplay',
                'type'     => 'switch',
                'title'    => __( 'Device-Slider: Autoplay', 'artless' ),
                'default'  => 0,
                'on'       => 'Enabled',
                'off'      => 'Disabled',
            ),

            array(
                'id'       => 'al_device_slider_timeout',
                'type'     => 'slider',
                'required' => array( 'al_device_slider_autoplay', '=', '1' ),
                'title'    => __( 'Device-Slider: Seconds to next Slide', 'artless' ),
                'default'  => '3',
                'min'      => '1',
                'step'     => '1',
                'max'      => '30',
            ),

			array(
				'id'       => 'al_quote_slider_autoplay',
				'type'     => 'switch',
				'title'    => __( 'Quote-Slider: Autoplay', 'artless' ),
				'default'  => 0,
				'on'       => 'Enabled',
				'off'      => 'Disabled',
			),

			array(
				'id'       => 'al_quote_slider_timeout',
				'type'     => 'slider',
				'required' => array( 'al_quote_slider_autoplay', '=', '1' ),
				'title'    => __( 'Quote-Slider: Seconds to next Slide', 'artless' ),
				'default'  => '3',
				'min'      => '1',
				'step'     => '1',
				'max'      => '30',
			),

			array(
				'id'       => 'al_general_tracking',
				'type'     => 'ace_editor',
				'title'    => __( 'Tracking Code', 'artless' ),
				'subtitle' => __( 'Paste your Google Analytics (or other) tracking code here. This will be added into the footer template of your theme.', 'artless' ),
				'mode' => 'plain_text',
                'theme' => 'chrome'
			),

			array(
				'id'    => 'al_general_footer_text',
				'type'  => 'editor',
				'title' => __( 'Footer Text', 'artless' ),
			),
		),
	)
) );