<?php
/**
 * @package    artless Flato
 * @author     Christian Glingener <glingener.christian@gmail.com>
 * @version    1.0.0
 * @copyright  2014 artlessthemes.com
 * @link       http://artlessthemes.com/
 */
$social_links_file = dirname( __FILE__ ) . '/social-links.php';

if ( file_exists( $social_links_file ) ) {
	$social_links = require( $social_links_file );
	ksort( $social_links );

	$social_options = array();

	foreach ( $social_links as $key => $social ) {
		$social_options[] = array(
			'id'    => 'al_social_' . $key,
			'type'  => 'text',
			'title' => $social['name'] . ' URL',
		);
	}
}


return ( array(

	// Sortorder ASC
	'sortorder' => 17,

	// Options
	'options'   => array(
		'title'  => __( 'Social Links', 'artless' ),
		'icon'   => 'el-icon-podcast',
		'fields' => $social_options,
	)
) );

