<?php
/**
 * @package    artless Flato
 * @author     Christian Glingener <glingener.christian@gmail.com>
 * @version    1.0.0
 * @copyright  2014 artlessthemes.com
 * @link       http://artlessthemes.com/
 */

return array(
	'facebook'   => array(
		'name'    => 'Facebook',
		'fa-icon' => 'fa-facebook',
	),

	// key should be 'twitter' but don't won't to mess up previous buyers
	'googleplus' => array(
		'name'    => 'Twitter',
		'fa-icon' => 'fa-twitter',
	),

	'googlep' => array(
		'name'    => 'Google+',
		'fa-icon' => 'fa-google-plus',
	),

	'behance' => array(
		'name'    => 'Behance',
		'fa-icon' => 'fa-behance',
	),

	'youtube'    => array(
		'name'    => 'Youtube',
		'fa-icon' => 'fa-youtube',
	),

	'linkedin'   => array(
		'name'    => 'Linkedin',
		'fa-icon' => 'fa-linkedin',
	),

	'instagram'  => array(
		'name'    => 'Instagram',
		'fa-icon' => 'fa-instagram',
	),

	'vimeo'      => array(
		'name'    => 'Vimeo',
		'fa-icon' => 'fa-vimeo-square',
	),

	'skype'      => array(
		'name'    => 'Skype',
		'fa-icon' => 'fa-skype',
	),

	'tumblr'     => array(
		'name'    => 'Tumblr',
		'fa-icon' => 'fa-tumblr',
	),

	'flickr'     => array(
		'name'    => 'Flickr',
		'fa-icon' => 'fa-flickr',
	),

	'foursquare' => array(
		'name'    => 'Foursquare',
		'fa-icon' => 'fa-foursquare',
	),

	'github'     => array(
		'name'    => 'Github',
		'fa-icon' => 'fa-github',
		'link'    => ''
	),

	'bitbucket'  => array(
		'name'    => 'Bitbucket',
		'fa-icon' => 'fa-bitbucket',
		'link'    => ''
	),

	'maxcdn'     => array(
		'name'    => 'Maxcdn',
		'fa-icon' => 'fa-maxcdn',
		'link'    => '',
	),

	'renren'     => array(
		'name'    => 'Renren',
		'fa-icon' => 'fa-renren',
		'link'    => '',
	),

	'xing'       => array(
		'name'    => 'Xing',
		'fa-icon' => 'fa-xing',
		'link'    => ''
	),

    'soundcloud' => array(
        'name'    => 'Soundcloud',
        'fa-icon' => 'fa-soundcloud',
        'link'    => ''
    ),

    'pinterest'     => array(
	    'name'    => 'Pinterest',
	    'fa-icon' => 'fa-pinterest',
	    'link'    => ''
    ),
);
