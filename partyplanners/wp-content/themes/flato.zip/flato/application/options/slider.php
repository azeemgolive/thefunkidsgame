<?php
/**
 * @package    artless Flato
 * @author     Christian Glingener <glingener.christian@gmail.com>
 * @version    1.0.0
 * @copyright  2014 artlessthemes.com
 * @link       http://artlessthemes.com/
 */

// Home Section
return ( array(

	// Sortorder ASC
	'sortorder' => 15,

	// Options
	'options'   => array(
		'title'  => __( 'Slider Blog / Portfolio', 'artless' ),
		'icon'   => 'el-icon-picture',
		'fields' => array(

			array(
				'id'       => 'al_slider_full_image',
				'type'     => 'switch',
				'title'    => __( 'Show Full Image', 'artless' ),
				"default"  => 0,
				'on'       => 'Enabled',
				'off'      => 'Disabled',
			),

			/*
			array(
				'id'       => 'al_slider_button_frame',
				'type'     => 'image_select',
				'title'    => __( 'Buttons Frame', 'artless' ),
				'options'  => array(
					'1'      => array(
						'alt'   => 'Full-Width',
						'img'   => AL_PUBLIC .'/img/options/al_slider_button_frame_1.png'
					),
					'2'      => array(
						'alt'   => '1200px',
						'img'   => AL_PUBLIC .'/img/options/al_slider_button_frame_2.png'
					),
					'3'      => array(
						'alt'   => '900px',
						'img'   => AL_PUBLIC .'/img/options/al_slider_button_frame_3.png'
					)
				),
				'default'  => '2'
			),
			*/
			array(
				'id'       => 'al_slider_button_close',
				'type'     => 'image_select',
				'title'    => __( 'Close Button Position', 'artless' ),
				'options'  => array(
					'top-center'      => array(
						'alt'   => 'Center',
						'img'   => AL_PUBLIC .'/img/options/al_slider_button_close_1.png'
					),
					/*'bottom-center'      => array(
						'alt'   => 'Center',
						'img'   => AL_PUBLIC .'/img/options/al_slider_button_close_5.png'
					),*/
					'top-left'      => array(
						'alt'   => 'Left',
						'img'   => AL_PUBLIC .'/img/options/al_slider_button_close_2.png'
					),
					'top-right'      => array(
						'alt'   => 'Right',
						'img'   => AL_PUBLIC .'/img/options/al_slider_button_close_3.png'
					),
					'none'      => array(
						'alt'   => 'No Close Button',
						'img'   => AL_PUBLIC .'/img/options/al_slider_button_close_4.png'
					)
				),
				'default'  => 'top-center'
			),

			array(
				'id'       => 'al_slider_button_next_prev',
				'type'     => 'image_select',
				'title'    => __( 'Next / Previous Buttons Position', 'artless' ),
				'options'  => array(
					'vertical-center' => array(
						'alt'   => 'Vertical Center',
						'img'   => AL_PUBLIC .'/img/options/al_slider_button_next_prev_1.png'
					),
					'vertical-bottom' => array(
						'alt'   => 'Vertical Bottom',
						'img'   => AL_PUBLIC .'/img/options/al_slider_button_next_prev_2.png'
					),
					'bottom-center'      => array(
						'alt'   => 'Bottom Center',
						'img'   => AL_PUBLIC .'/img/options/al_slider_button_next_prev_6.png'
					),
					'bottom-left'      => array(
						'alt'   => 'Bottom Left',
						'img'   => AL_PUBLIC .'/img/options/al_slider_button_next_prev_3.png'
					),
					'bottom-right'      => array(
						'alt'   => 'Bottom Right',
						'img'   => AL_PUBLIC .'/img/options/al_slider_button_next_prev_4.png'
					),
					'none'      => array(
						'alt'   => 'No Next / Prev Buttons',
						'img'   => AL_PUBLIC .'/img/options/al_slider_button_next_prev_5.png'
					)
				),
				'default'  => 'vertical-center'
			),

			array(
				'id'       => 'al_slider_pagination',
				'type'     => 'switch',
				'title'    => __( 'Show Slide Dots', 'artless' ),
				'default'  => 1,
				'on'       => 'Enabled',
				'off'      => 'Disabled',
			),

			array(
				'id'       => 'al_slider_autoplay',
				'type'     => 'switch',
				'title'    => __( 'Autoplay', 'artless' ),
				'default'  => 0,
				'on'       => 'Enabled',
				'off'      => 'Disabled',
			),

			array(
				'id'       => 'al_slider_timeout',
				'type'     => 'slider',
				'required' => array( 'al_slider_autoplay', '=', '1' ),
				'title'    => __( 'Seconds to next Slide', 'artless' ),
				'default'  => '3',
				'min'      => '1',
				'step'     => '1',
				'max'      => '30',
			),

			array(
				'id'       => 'al_slider_transition',
				'type'     => 'select',
				'required' => array( 'al_home_show_slider', '=', '1' ),
				'title'    => __( 'Slide Effect', 'artless' ),
				'subtitle' => __( 'Only working in modern browsers.<br />Mouse / Touch dragging will always have the scroll effect.' ),
				//Must provide key => value pairs for select options
				'options'  => array(
					'default'     => 'Scroll',
					'fade'        => 'Fade',
					//'backSlide'   => 'Back Slide',
					'goDown'      => 'Go Down',
					//'scaleUp'     => 'Scale Up'
				),
				'default'  => 'false'
			),

			array(
				'id'       => 'al_slider_dragging',
				'type'     => 'select',
				'required' => array( 'al_home_show_slider', '=', '1' ),
				'title'    => __( 'Mouse / Touch Dragging', 'artless' ),
				'subtitle' => __( 'Dragging will always have the scroll effect.' ),
				//Must provide key => value pairs for select options
				'options'  => array(
					'default'     => 'On',
					'false'       => 'Off',
					'onTouch'     => 'Touch On / Mouse off',
					'onMouse'     => 'Touch Off / Mouse on'
				),
				'default'  => 'true'
			),

			array(
				'id'       => 'al_slider_lazyload',
				'type'     => 'switch',
				'title'    => __( 'Lazy Load', 'artless' ),
				'subtitle' => __( 'Will just load the image of the current slide and not all at once.', 'artless' ),
				'default'  => 0,
				'on'       => 'Enabled',
				'off'      => 'Disabled',
			),
		),
	)
) );