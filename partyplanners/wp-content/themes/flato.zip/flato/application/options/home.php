<?php
/**
 * @package    artless Flato
 * @author     Christian Glingener <glingener.christian@gmail.com>
 * @version    1.0.0
 * @copyright  2014 artlessthemes.com
 * @link       http://artlessthemes.com/
 */

// Home Section
return ( array(

	// Sortorder ASC
	'sortorder' => 2,

	// Options
	'options'   => array(
		'title'  => __( 'Home', 'artless' ),
		'icon'   => 'el-icon-home',
		'fields' => array(

			array(
				'id'       => 'al_home_show_logo',
				'type'     => 'switch',
				'title'    => __( 'Show Logo on Home Section', 'artless' ),
				'subtitle' => __( 'Set Logo in "General Settings"', 'artless' ),
				"default"  => 0,
				'on'       => 'Enabled',
				'off'      => 'Disabled',
			),

			array(
				'id'       => 'al_home_logo_width',
				'type'     => 'text',
				'required' => array( 'al_home_show_logo', '=', '1' ),
				'title'    => __( 'Adjust Logo Width', 'artless' ),
				'subtitle' => __( 'Leave empty for auto adjustment.', 'artless' ),
				'desc'     => __( 'i.e. 100px or 90%', 'artless' ),
			),

			array(
				'id'       => 'al_home_logo_height',
				'type'     => 'text',
				'required' => array( 'al_home_show_logo', '=', '1' ),
				'title'    => __( 'Adjust Logo Height', 'artless' ),
				'subtitle' => __( 'Leave empty for auto adjustment.', 'artless' ),
				'desc'     => __( 'i.e. 100px or 90%.', 'artless' ),
			),


			array(
				'id'       => 'al_home_show_jumper',
				'type'     => 'switch',
				'title'    => __( 'Show the "Jumping Circle"', 'artless' ),
				'subtitle' => __( 'Link to the next section', 'artless' ),
				"default"  => 0,
				'on'       => 'Enabled',
				'off'      => 'Disabled',
			),

			array(
				'id'       => 'al_home_show_slider',
				'type'     => 'switch',
				'title'    => __( 'Show Slider', 'artless' ),
				'subtitle' => __( 'Instead of Parallax Background', 'artless' ),
				"default"  => 0,
				'on'       => 'Enabled',
				'off'      => 'Disabled',
			),

			array(
				'id'          => 'al_home_slides',
				'type'        => 'slides',
				'required'    => array( 'al_home_show_slider', '=', '1' ),
				'title'       => __( 'Slides', 'artless' ),
				'subtitle'    => __( 'Unlimited slides with drag and drop sortings.', 'artless' )
					. '<br /><br />' . __( '<b>Content Examples</b>', 'artless' )
					. '<br /><a id="al-home-slide-example1" href="javascript:void(0);">'
                    . __( 'Headline + Subline + Buttons', 'artless' ) . '</a>',
				'placeholder' => array(
					'title'       => __( 'Slide Title (just for organization)', 'artless' ),
					'description' => __( 'Slide Content ( HTML and Shortcodes allowed )', 'artless' ),
					'url'         => __( 'Link', 'artless' ),
				),
			),

			array(
				'id'       => 'al_home_slider_transition',
				'type'     => 'select',
				'required' => array( 'al_home_show_slider', '=', '1' ),
				'title'    => __( 'Slide Effect', 'artless' ),
				//Must provide key => value pairs for select options
				'options'  => array(
					'fade'        => 'Fade',
					'scrollLeft'  => 'Scroll Left',
					'scrollRight' => 'Scroll Right',
					'scrollDown'  => 'Scroll Down',
					'scrollUp'    => 'Scroll Up'
				),
				'default'  => 'fade'
			),

			array(
				'id'       => 'al_home_slider_timeout',
				'type'     => 'slider',
				'required' => array( 'al_home_show_slider', '=', '1' ),
				'title'    => __( 'Seconds to next Slide', 'artless' ),
				"default"  => "3",
				"min"      => "1",
				"step"     => "1",
				"max"      => "30",
			),

			array(
				'id'       => 'al_home_slider_pause_on_mousehover',
				'type'     => 'switch',
				'required' => array( 'al_home_show_slider', '=', '1' ),
				'title'    => __( 'Pause on Mousehover', 'artless' ),
				"default"  => 0,
				'on'       => 'Enabled',
				'off'      => 'Disabled',
			),

			array(
				'id'       => 'al-home-slider-css',
				'type'     => 'ace_editor',
				'required' => array( 'al_home_show_slider', '=', '1' ),
				'title'    => __( 'CSS', 'artless' ),
				'subtitle' => __( 'Paste your CSS code here.', 'artless' ),
				'mode'     => 'css',
				'theme'    => 'chrome',
				'default'  => "/* CONTROLS */\n\n.maximage-prev {\n  right: 100px;\n}\n\n.maximage-next {\n  right: 40px;\n}\n\n.maximage-prev,\n.maximage-next {\n  position: absolute;\n  bottom: 50px;\n  width: 50px;\n  height: 50px;\n  z-index: 9999;\n  border: 2px solid #dadada;\n  -moz-border-radius: 50px;\n  -webkit-border-radius: 50px;\n  border-radius: 50px;\n  -webkit-transition: all 0.2s;\n  -moz-transition:    all 0.2s;\n  -o-transition:      all 0.2s;\n  transition:         all 0.2s;\n}\n\n@media screen and (max-width: 979px) {\n  .maximage-prev,\n  .maximage-next {\n    bottom: 20px;\n  }\n}"
			),
		),
	)
) );