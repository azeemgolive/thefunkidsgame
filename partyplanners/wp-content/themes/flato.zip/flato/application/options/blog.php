<?php
/**
 * @package    artless Flato
 * @author     Christian Glingener <glingener.christian@gmail.com>
 * @version    1.0.0
 * @copyright  2014 artlessthemes.com
 * @link       http://artlessthemes.com/
 */

$days =
	'Monday
	Tuesday
	Wednesday
	Thursday
	Friday
	Saturday
	Sunday';

$months =
	'January
	February
	March
	April
	May
	June
	July
	August
	September
	October
	November
	December';

// Blog Section
return ( array(

	// Sortorder ASC
	'sortorder' => 12,

	// Options
	'options'   => array(
		'title'  => __( 'Blog', 'artless' ),
		'icon'   => 'el-icon-edit',
		'fields' => array(

			array(
				'id'       => 'al_blog_filter',
				'type'     => 'switch',
				'title'    => __( 'Filter-By-Category-Bar', 'artless' ),
				'subtitle' => __( 'Filter posts by category.', 'artless' ),
				"default"  => 0,
				'on'       => 'Enabled',
				'off'      => 'Disabled',
			),

			array(
				'id'       => 'al_blog_load_more',
				'type'     => 'switch',
				'title'    => __( 'Load-More Button', 'artless' ),
				'subtitle' => __( 'Change Number of Posts:', 'artless' ) . '<br /><a href="' . admin_url( 'options-reading.php', 'http' ) . '">Settings -> Reading</a>',
				"default"  => 0,
				'on'       => 'Enabled',
				'off'      => 'Disabled',
			),

			array(
				'id'      => 'al_blog_show_comments',
				'type'    => 'switch',
				'title'   => __( 'Comments on One-Page', 'artless' ),
				"default" => 0,
				'on'      => 'Enabled',
				'off'     => 'Disabled',
			),

			array(
				'id'          => 'al_blog_sidebar',
				'type'        => 'select',
				'title'       => __( 'Layout Single Post Page', 'artless' ),
				'subtitle'    => __( 'Does not affect posts layout on the One-Page', 'artless' ),
				'options'     => array(
					'none'  => 'Post',
					'right' => 'Post / Sidebar',
					'left'  => 'Sidebar / Post'
				),
				'default'     => 1,
				'placeholder' => 'Post'
			),

			array(
				'id'          => 'al_blog_sidebar_onepage',
				'type'        => 'select',
				'title'       => __( 'Layout Single Post on One-Page', 'artless' ),
				'subtitle'    => __( 'Does not affect posts layout on the Single Post Page', 'artless' ),
				'options'     => array(
					'none'  => 'Post',
					'right' => 'Post / Sidebar',
					'left'  => 'Sidebar / Post'
				),
				'default'     => 1,
				'placeholder' => 'Post'
			),

			array(
				'id'          => 'al_blog_term_show_article',
				'type'        => 'text',
				'title'       => __( 'Change Term "Show Article"', 'artless' ),
				'subtitle'    => __( 'Term for the Show-Article-Button', 'artless' ),
				"placeholder" => 'Show Article',
			),

			array(
				'id'          => 'al_blog_term_category',
				'type'        => 'text',
				'title'       => __( 'Change Term "Category / [category-name]"', 'artless' ),
				'subtitle'    => __( 'Default:', 'artless' ) . ' CATEGORY / &lt;i>[category-name]&lt;/i>' ,
				'desc'        => __( 'Available Placeholder:', 'artless' ) . ' <b>[category-name]</b>',
				"placeholder" => 'CATEGORY / <i>[category-name]</i>',
			),

            array(
                'id'          => 'al_blog_term_tags',
                'type'        => 'text',
                'title'       => __( 'Change Term "Tags / [tags]"', 'artless' ),
                'subtitle'    => __( 'Default:', 'artless' ) . ' TAGS / &lt;i>[tags]&lt;/i>' ,
                'desc'        => __( 'Available Placeholder:', 'artless' ) . ' <b>[tags]</b>',
                "placeholder" => 'TAGS / <i>[tags]</i>',
            ),

			array(
				'id'          => 'al_blog_term_author',
				'type'        => 'text',
				'title'       => __( 'Change Term "Author / [author-name]"', 'artless' ),
				'subtitle'    => __( 'Default:', 'artless' ) . ' AUTHOR / &lt;i>[author-name]&lt;/i>',
				'desc'        => __( 'Available Placeholder:', 'artless' ) . ' <b>[author-name]</b>',
				"placeholder" => 'AUTHOR / <i>[author-name]</i>',
			),

			array(
				'id'          => 'al_blog_term_date',
				'type'        => 'text',
				'title'       => __( 'Change Term "Date / [date]"', 'artless' ),
				'subtitle'    => __( 'Default:', 'artless' ) . ' DATE / &lt;i>[date]&lt;/i>',
				'desc'        => __( 'Available Placeholder:', 'artless' ) . ' <b>[date]</b>',
				"placeholder" => 'DATE / <i>[date]</i>',
			),

			array(
				'id'          => 'al_blog_term_filter_all',
				'type'        => 'text',
				'title'       => __( 'Change Term "All"', 'artless' ),
				'subtitle'    => __( 'Term for "all categories" in the filter-bar', 'artless' ),
				"placeholder" => 'All',
			),

			array(
				'id'          => 'al_blog_term_load_more',
				'type'        => 'text',
				'title'       => __( 'Change Term "Load More"', 'artless' ),
				'subtitle'    => __( 'Term for the Load-More-Button', 'artless' ),
				"placeholder" => 'Load More',
			),

			array(
				'id'          => 'al_blog_term_comments',
				'type'        => 'text',
				'title'       => __( 'Change Term "Comments"', 'artless' ),
				'subtitle'    => __( 'Term for the Comments-Button', 'artless' ),
				"placeholder" => 'Comments',
			),

		),
	)
) );