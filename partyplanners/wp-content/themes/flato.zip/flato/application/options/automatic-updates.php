<?php
/**
 * @package    artless Flato
 * @author     Christian Glingener <glingener.christian@gmail.com>
 * @version    1.0.0
 * @copyright  2014 artlessthemes.com
 * @link       http://artlessthemes.com/
 */

// General Settings
// Icons http://shoestrap.org/downloads/elusive-icons-webfont/
return ( array(

	// Sortorder ASC
	'sortorder' => 500,

	// Options
	'options'   => array(
		'title'  => __( 'Automatic Updates', 'artless' ),
		'icon'   => 'el-icon-download',
		'fields' => array(
			array(
				'id'       => 'al_updates_username',
				'type'     => 'text',
				'title'    => __( 'Your Themeforest Account Name', 'artless' ),
			),

			array(
				'id'       => 'al_updates_api_key',
				'type'     => 'text',
				'title'    => __( 'Your Themeforest Api Key', 'artless' ),
			),
		),
	)
) );