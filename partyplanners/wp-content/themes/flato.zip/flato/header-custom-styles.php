<?php
/**
 * @package    artless Flato
 * @author     Christian Glingener <glingener.christian@gmail.com>
 * @version    1.0.0
 * @copyright  2014 artlessthemes.com
 * @link       http://artlessthemes.com/
 */

function al_css_print_font( $id, $elements, $additionals = array() ) {
	global $al_theme_options;

	$style = '';

	/**
	 * FONT FAMILY
	 */
	$option = $al_theme_options->getOption( $id, 'font-family' );

	$font_family = ( isset( $option ) and ! empty( $option ) and $option != 'inherit' ) ? $option : false;

	if ( $font_family == 'flato-default' ) {
		wp_enqueue_style( 'googlefont-open-sans' );
		$font_family = "'Open Sans', sans-serif";
	}

	$option      = $al_theme_options->getOption( $id, 'font-backup' );
	$font_backup = ( isset( $option ) and ! empty( $option ) and $option != 'inherit' ) ? $option : false;

	if ( $font_family and $font_backup ) {
		$style .= 'font-family:' . $font_family . ',' . $font_backup . ';';
	} elseif ( $font_family ) {
		$style .= 'font-family:' . $font_family . ';';
	}

	/**
	 * FONT WEIGHT
	 */
	$option = $al_theme_options->getOption( $id, 'font-weight' );

	$font_weight = ( isset( $option ) and ! empty( $option ) ) ? $option : false;

	if ( $font_weight and preg_match( '#[0-9]#', $font_weight ) ) {
		$style .= 'font-weight:' . $font_weight . ';';
	}

	/**
	 * FONT SIZE
	 */
	$option = $al_theme_options->getOption( $id, 'font-size' );

	$font_size = ( isset( $option ) and ! empty( $option ) ) ? $option : false;

	if ( $font_size and preg_match( '#[0-9]#', $font_size ) ) {
		$style .= 'font-size:' . $font_size . ';';
	}

	/**
	 * LINE HEIGHT
	 */
	$option = $al_theme_options->getOption( $id, 'line-height' );

	$line_height = ( isset( $option ) and ! empty( $option ) ) ? $option : false;

	if ( $line_height and preg_match( '#[0-9]#', $line_height ) ) {
		$style .= 'line-height:' . $line_height . ';';
	}

	/**
	 * LETTER SPACING
	 */
	$option = $al_theme_options->getOption( $id, 'letter-spacing' );

	$letter_spacing = ( isset( $option ) and ! empty( $option ) ) ? $option : false;

	if ( $letter_spacing and preg_match( '#[0-9]#', $letter_spacing ) ) {
		$style .= 'letter-spacing:' . $letter_spacing . ';';
	}

	/**
	 * COLOR
	 */
	$option = $al_theme_options->getOption( $id, 'color' );

	$color = ( isset( $option ) and ! empty( $option ) ) ? $option : false;

	if ( $color ) {
		$style .= 'color:' . $color . ';';
	}

	/**
	 * TEXT TRANSFORM
	 */
	$option = $al_theme_options->getOption( $id, 'text-transform' );

	$text_transform = ( isset( $option ) and ! empty( $option ) ) ? $option : false;

	if ( $text_transform ) {
		$style .= 'text-transform:' . $text_transform . ';';
	}

	/**
	 * ADDTIONALS
	 */
	if ( ! empty( $additionals ) ) {
		foreach ( $additionals as $field => $id_value ) {

			$option = $al_theme_options->getOption( $id_value );

			$value = ( isset( $option ) and ! empty( $option ) ) ? $option : false;

			if ( $value ) {
				$style .= $field . ':' . $value . ';';
			}
		}
	}

	if ( $style != '' ) {
		echo $elements . '{' . $style . '}';
	}
}

// Custom Styles
add_action( 'wp_head', 'al_custom_styles' );

function al_custom_styles() {

	// Theme Options
	global $al_theme_options;

	$body_font_color = $al_theme_options->getOption( 'al_typo_body', 'color' );

    ob_start();
	?>
	<style type="text/css" media="all">
	<?php al_css_print_font( 'al_typo_body', 'body,a.al-fa-circle' ); ?>
	.al-fa-circle {
		line-height: 100% !important;
	}

	<?php
	al_css_print_font( 'al_typo_paragraphs', 'p,.toggle .content' );
	al_css_print_font( 'al_typo_headlines', 'h1,h2,h3,h4,h5,h6, .al-home-banner .subheadline' );
	al_css_print_font( 'al_typo_home_h1', '.al-home-banner h1' );
	al_css_print_font( 'al_typo_home_subheadline', '.al-home-banner .subheadline' );
	al_css_print_font( 'al_typo_h1', 'h1' );
	al_css_print_font( 'al_typo_h2', 'h2' );
	al_css_print_font( 'al_typo_h3', 'h3' );
	al_css_print_font( 'al_typo_h4', 'h4' );
	al_css_print_font( 'al_typo_h5', 'h5' );
	al_css_print_font( 'al_typo_h6', 'h6' );
	al_css_print_font( 'al_typo_subheadlines', 'p.undertitle' );
	?>

	<?php if( $al_theme_options->getOption( 'al_general_typo', 'text-align' ) ) { ?>
	p {
	 	text-align: <?php $al_theme_options->printOption( 'al_general_typo', 'text-align' ); ?>;
	}
	<?php } ?>

	<?php if( $al_theme_options->getOption( 'al_typo_paragraphs', 'color' ) ) { ?>
	a.al-icon-circle {
		color: <?php $al_theme_options->printOption( 'al_typo_paragraphs', 'color' ); ?>;
	}
	<?php } ?>


	/* --------------------------------------------------------------------- */
	/* COLOR PRIMARY
	/* --------------------------------------------------------------------- */
	a,
	.social-links a:hover,
	#main-navigation li a:hover,
	#main-navigation li a.active,
	.highlighted,
	.button.border:hover,
	.icon-box:hover i,
	.comment-reply-title small a:hover,
	.comment-author a:hover,
	.comment-list .pingback a:hover,
	.comment-list .trackback a:hover,
	.comment-metadata a:hover,
	.comment-reply-link:hover {
		color: <?php $al_theme_options->printOption( 'al_style_color_primary' ); ?>;
	}

	.wrapper.color-bg,
	.headline-wrapper,
	.al-tabs li a:hover,
	.al-tabs li.active a,
	#al-blog-preview li:hover,
	#al-blog-wrapper #close-blog-wrapper:hover,
	.button,
	input.submit,
	.social-icons a:hover,
	.pricing-table.best-price .header,
	#al-blog-load-content .toggle .header:hover,
	#al-blog-load-content .toggle .header.active,
	#al-pf-load-content .toggle .header:hover,
	#al-pf-load-content .toggle .header.active,
	.toggle .header:hover,
	.toggle .header.active,
	.percent-bar .percent-bg,
	.al-home-banner .scroll-down a:hover,
	.bx-wrapper .bx-pager.bx-default-pager a:hover,
	.bx-wrapper .bx-pager.bx-default-pager a.active,
	.bx-wrapper .bx-controls-direction a:hover,
	.owl-theme .owl-controls .owl-page.active span,
	.owl-theme .owl-controls.clickable .owl-page:hover span,
	.comment-respond #submit,
	.al-close-back:hover,
	#al-pf-wrapper-close:hover,
	a.al-icon-circle:hover,
    .maximage-prev:hover,
    .maximage-next:hover,
	.owl-theme .owl-controls.clickable .owl-buttons a:hover {
		background-color: <?php $al_theme_options->printOption( 'al_style_color_primary' ); ?>;
	}

	.button,
	.button.border:hover,
	input.submit,
	a.al-fa-circle:hover,
	.al-tabs li a:hover,
	.al-tabs li.active a,
	#al-blog-wrapper #close-blog-wrapper:hover,
	.social-icons a:hover,
	.pricing-table.best-price .header,
	.tab-content-navi a.active,
	.tab-content-navi a:hover,
	#al-blog-load-content .tab-content-navi a.active,
	#al-blog-load-content .tab-content-navi a:hover,
	#al-pf-load-content .tab-content-navi a.active,
	#al-pf-load-content .tab-content-navi a:hover,
	.al-home-banner .scroll-down a:hover,
	.bx-wrapper .bx-controls-direction a:hover,
	.comment-respond #submit,
	.comment-reply-link:hover,
	.al-close-back:hover,
	#al-pf-wrapper-close:hover,
	.widget ul li a:hover,
	a.al-icon-circle:hover,
    .maximage-prev:hover,
    .maximage-next:hover,
	.owl-theme .owl-controls.clickable .owl-buttons a:hover,
	.sticky,
	.widget ul li a:hover,
	#al-blog-load-content .widget ul li a:hover,
	#al-pf-load-content .widget ul li a:hover,
	.callout-box,
	p.blockquote, blockquote, q {
		border-color: <?php $al_theme_options->printOption( 'al_style_color_primary' ); ?>;
	}

	::selection {
		background: <?php $al_theme_options->printOption( 'al_style_color_primary' ); ?>;
	}

	::-moz-selection {
		background: <?php $al_theme_options->printOption( 'al_style_color_primary' ); ?>;
	}

	#al-pf-preview .layer {
		background: <?php $al_theme_options->printRGBA( 'al_style_color_primary', 0.85 ); ?>;
	}

	/* --------------------------------------------------------------------- */
	/* COLOR PRIMARY LIGHTEN
	/* --------------------------------------------------------------------- */
	#open-nav:hover {
		color: <?php $al_theme_options->printOption( 'al_style_color_primary_lighten' ); ?>;
	}

	.button:hover,
	input.submit:hover,
	.comment-respond #submit:hover {
		background-color: <?php $al_theme_options->printOption( 'al_style_color_primary_lighten' ); ?>;
	}

	.button:hover,
	input.submit:hover,
	.comment-respond #submit:hover {
		border-color: <?php $al_theme_options->printOption( 'al_style_color_primary_lighten' ); ?>;
	}

	<?php
	$body_font_color = $al_theme_options->getOption( 'al_typo_body', 'color');
	if( $body_font_color ) {
	?>

	.social-links a,
	#open-nav,
	#main-navigation li a,
	.al-tabs li a,
	.al-tabs li a:hover,
	.al-tabs li.active a,
	.button,
	input.submit,
	.social-icons a,
	.toggle .header,
	.tab-content-navi li a,
	.comment-reply-title small a
	.comment-respond #submit,
	.comment-author a,
	.button.border,
	.comment-reply-link,
	#al-blog-preview .text a,
	.al-blog-article .info a,
	.al-blog-article .info-last a {
		color: <?php echo $body_font_color; ?>
	}

	::selection {
		color: <?php echo $body_font_color; ?>
	}

	::-moz-selection {
		color: <?php echo $body_font_color; ?>
	}

	.al-tabs li a,
	.button.border,
	.social-icons a,
	#close-blog-wrapper,
	.al-close-back,
	.comment-reply-link {
		border-color: <?php echo $body_font_color; ?>
	}

	<?php } ?>

	/* --------------------------------------------------------------------- */
	/* COLOR BACKGROUND
	/* --------------------------------------------------------------------- */
	.team-member,
	#al-blog-preview li,
	.pricing-table,
	.toggle .header,
	.toggle .content,
	.percent-bar,
	.tab-content-navi li a,
	#al-page-preloader,
	#al-blog-wrapper,
	.al-team-member,
	#al-pf-wrapper,
    .bx-wrapper .bx-loading,
	.comment-list article,
	.comment-list .pingback,
	.comment-list .trackback,
	.callout-box,
	.alert-box,
	.widget ul li a,
	iframe,
	.al-pf-empty-preview, .al-pf-empty-preview,
	.al-blog-media-container,
	#al-blog-load-content .tab-content-navi a.active,
	#al-blog-load-content .tab-content-navi a:hover,
	#al-pf-load-content .tab-content-navi a.active,
	#al-pf-load-content .tab-content-navi a:hover {
		background-color: <?php $al_theme_options->printOption( 'al_style_bg_color_lighten' ); ?>;
	}

	.tab-content-navi,
	.tab-content-navi li a,
	.widget ul li a {
		border-color: <?php $al_theme_options->printOption( 'al_style_bg_color_lighten' ); ?>;
	}

	/** COLOR #2d3943 **/
	body,
	#al-blog-load-content .comment-list article,
	#al-blog-load-content .comment-list .pingback,
	#al-blog-load-content .comment-list .trackback,
	#al-blog-load-content .toggle .header,
	#al-blog-load-content .toggle .content,
	#al-pf-load-content .toggle .header,
	#al-pf-load-content .toggle .content,
	#al-blog-load-content .callout-box,
	#al-pf-load-content .callout-box,
	#al-blog-load-content .alert-box,
	#al-pf-load-content .alert-box,
	#al-blog-load-content .percent-bar,
	#al-pf-load-content .percent-bar,
	#al-blog-load-content .pricing-table,
	#al-pf-load-content .pricing-table,
	#al-blog-load-content .tab-content-navi li a,
	#al-pf-load-content .tab-content-navi li a,
	#al-blog-load-content .widget ul li a,
	#al-pf-load-content .widget ul li a,
	.bx-wrapper .bx-pager.bx-default-pager a,
	.owl-theme .owl-controls .owl-page span {
		background-color: <?php $al_theme_options->printOption( 'al_style_bg_color' ); ?>;
	}

	#al-blog-load-content .tab-content-navi li a,
	#al-pf-load-content .tab-content-navi li a,
	#al-blog-load-content .widget ul li a,
	#al-pf-load-content .widget ul li a{
		border-color: <?php $al_theme_options->printOption( 'al_style_bg_color' ); ?>;
	}

	/** FOOTER / HEADER **/
	#header,
	.bottom-box,
    .al-blog-empty-preview {
		background-color: <?php $al_theme_options->printOption( 'al_style_bg_color_footer' ); ?>;
	}

	p.blockquote,
	.bottom-box,
	.comment-notes,
	.comment-awaiting-moderation,
	.logged-in-as,
	.no-comments,
	.form-allowed-tags,
	.form-allowed-tags code,
	.comment-list article,
	.comment-list .pingback,
	.comment-list .trackback {
		color: rgba(255, 255, 255, 0.4);
	}

	<?php $input_color =
	( $al_theme_options->getOption( 'al_sc_contact_input_color' ) )
		? $al_theme_options->getOption( 'al_sc_contact_input_color' )
		: 'rgba(255, 255, 255, 0.5)' ?>

	input.text,
	input.button,
	textarea {
		color: <?php echo $input_color; ?>;
	}

	::-webkit-input-placeholder {
		color: <?php echo $input_color; ?>;
	}

	:-moz-placeholder {
		color: <?php echo $input_color; ?>;
	}

	::-moz-placeholder {
		color: <?php echo $input_color; ?>;
	}

	:-ms-input-placeholder {
		color: <?php echo $input_color; ?>;
	}

	/** BACKGROUND **/
	input.text,
	textarea {
		background-color: <?php echo ( $al_theme_options->getOption( 'al_sc_contact_input_background_color' ) )
		? $al_theme_options->getOption( 'al_sc_contact_input_background_color' )
		: 'rgba(0,0,0,0.12)' ?>;
	}

	.button.border,
	.al-tabs li a {
		background: none;
	}

	<?php

	$headline_underline = $al_theme_options->getOption( 'al_style_headline_underline', 'url' )
		? $al_theme_options->getOption( 'al_style_headline_underline', 'url' )
		: false;

	if( $headline_underline ) { ?>
	.underline {
		background-image: url('<?php echo $headline_underline; ?>');
	}

	<?php
	}
		$al_preloader = ( $al_theme_options->getOption( 'al_style_preloader', 'url' ) )
			? $al_theme_options->getOption( 'al_style_preloader', 'url' )
			: AL_PUBLIC . '/img/color_loader.gif';
	?>
	#al-pf-preview-loader,
    .bx-wrapper .bx-loading,
	.owl-item.loading {
		background-image: url('<?php echo $al_preloader; ?>');
	}

	<?php
		$regular = $al_theme_options->getOption('al_style_link_color', 'regular' );
		$hover = $al_theme_options->getOption('al_style_link_color', 'hover' );
		$active = $al_theme_options->getOption('al_style_link_color', 'active' );
		$visited = $al_theme_options->getOption('al_style_link_color', 'visited' );

		if( $regular ) {
			echo 'a:not(.button) {color:' . $regular . ' !important;}';
		}

		if( $hover ) {
			echo 'a:not(.button):hover {color:' . $hover . ' !important;}';
		}

		if( $active ) {
			echo 'a:not(.button):active {color:' . $active . ' !important;}';
		} else {if( $hover ) {
			echo 'a:not(.button):active {color:' . $hover . ' !important;}';
		}
}

		if( $visited ) {
			echo 'a:not(.button):visited {color:' . $visited . ' !important;}';
		} else {if ( $regular ) {
			echo 'a:not(.button):visited {color:' . $regular . ' !important;}';
		}
}

		// Slider
		if( $al_theme_options->getOption( 'al_home_show_slider' ) ) {
			$al_theme_options->printOption( 'al-home-slider-css' );

			// Transition
			$slider_transition = $al_theme_options->getOption( 'al_home_slider_transition' );

			switch( $slider_transition ) {
				case 'fade':
					$transition_style = 'opacity';
					break;
				case 'scrollLeft':
				case 'scrollRight':
					$transition_style = 'left';
					break;
				case 'scrollUp':
				case 'scrollDown':
					$transition_style = 'top';
					break;
				default:
					$transition_style = 'bottom';
			}

?>
	div.mc-image {
		-webkit-transition: <?php echo $transition_style; ?> 1s ease-in-out;
		-moz-transition: <?php echo $transition_style; ?>    1s ease-in-out;
		-o-transition: <?php echo $transition_style; ?>      1s ease-in-out;
		transition: <?php echo $transition_style; ?>         1s ease-in-out;
	}

	<?php
		}

    // Navigation
    al_css_print_font( 'al_general_navigation_button_typo', '#open-nav' );

    $regular = $al_theme_options->getOption( 'al_general_navigation_button_colors', 'regular' );
	$hover = $al_theme_options->getOption( 'al_general_navigation_button_colors', 'hover' );

    if( $regular ) {
        echo '#open-nav {color:' . $regular . ' !important;}';
    }

    if( $hover ) {
        echo '#open-nav:hover {color:' . $hover . ' !important;}';
    }

	// Portfolio highlight active item
	if( $al_theme_options->getOption( 'al_portfolio_highlight_active_item' ) ) { ?>
    a.al-pf-item-active div.layer {
        top: 0 !important;
        left: 0 !important;
        bottom: 0 !important;
        right: 0 !important;
    }
<?php }

// Blog Portfolio Slider
$slider_full_image 	 	 = $al_theme_options->getOption( 'al_slider_full_image' );
$slider_button_next_prev = $al_theme_options->getOption( 'al_slider_button_next_prev' );
$slider_button_close 	 = $al_theme_options->getOption( 'al_slider_button_close' );
$slider_pagination 	 	 = ( $al_theme_options->getOption( 'al_slider_pagination' ) ) ? true : false;

// Full Image
if( $slider_full_image ) { ?>
	.al-pf-slider img,
	.blog-slider img {
		display: block;
		max-width: 100% !important;
		width: auto !important;
		height: auto !important;
		margin: 0 auto;
	}

	.owl-wrapper-outer div,
	.owl-wrapper-outer .owl-item img {
		max-height: inherit !important;
	}
<?php
}

// Bottons Next / Prev
if( $slider_button_next_prev != 'none' and $slider_button_next_prev != 'vertical-center' ) {
	switch( $slider_button_next_prev ) {
		case 'vertical-bottom': ?>
			.owl-controls .owl-buttons a {
				top: auto;
				bottom: 10px;
			}
			<?php break;
		case 'bottom-left': ?>
			.owl-controls .owl-buttons a {
				top: auto;
				bottom: 10px;
			}
			.al-slider-next {
				right: auto;
				left: 72px;
			}
			<?php break;
		case 'bottom-right': ?>
			.owl-controls .owl-buttons a {
				top: auto;
				bottom: 10px;
			}
			.al-slider-prev {
				right: 72px;
				left: auto;
			}
			<?php break;
		case 'bottom-center':
			$width = ( $slider_button_close == 'bottom-center' ) ? '200px' : '140px';
			if( $slider_pagination ) { ?>
				.owl-buttons {
					width:  <?php echo $width; ?>;
					position:  relative;
					margin:  0 auto;
					bottom:  78px;
				}
			<?php
			} else { ?>
				.owl-buttons {
					width:  <?php echo $width; ?>;
					position:  relative;
					margin:  0 auto;
					bottom:  50px;
				}

	  		<?php
	  		}
	  		break;
	}
}

if( $slider_button_next_prev == 'vertical-center' ) { ?>
	.al-slider-prev {
		left: 45px;
	}
<?php
}

// Button Close
if( $slider_button_close != 'top-center' ) {

	switch( $slider_button_close ) {
		case 'bottom-center': ?>
			#al-blog-wrapper .close, .close-blog-wrapper, #al-pf-wrapper .close {
				top: auto;
				bottom: 6px;
			}
	<?php break;
		case 'top-left': ?>
			#close-blog-wrapper, .close-blog-wrapper, .al-close-back, #al-pf-wrapper-close {
				position: absolute;
				left: 10px;
			}
	<?php break;
		case 'top-right': ?>
			#close-blog-wrapper, .close-blog-wrapper, .al-close-back, #al-pf-wrapper-close {
				position: absolute;
				right: 10px;
			}
	<?php break;
		case 'none': ?>
			#close-blog-wrapper, .close-blog-wrapper, .al-close-back, #al-pf-wrapper-close {
				display: none;
			}
	<?php break;
	}
}

// Pagination
if( $slider_pagination and ( $slider_button_next_prev == 'bottom-center' or $slider_button_close == 'bottom-center' ) ) { ?>
	.al-blog-article .owl-pagination, .al-pf-article .owl-pagination {
		bottom: 100px;
	}
<?php
}

$al_theme_options->printOption( 'al_general_widget_navigation_css' );
$al_theme_options->printOption( 'al_style_user_css' ); ?>
	</style>
<?php

    $css_output = ob_get_contents();
    $css_output = preg_replace('!/\*[^*]*\*+([^/][^*]*\*+)*/!', '', $css_output);
    $css_output = str_replace(array("\r\n", "\r", "\n", "\t", '  ', '    ', '    '), '', $css_output);

    ob_end_clean();

    echo $css_output;
}